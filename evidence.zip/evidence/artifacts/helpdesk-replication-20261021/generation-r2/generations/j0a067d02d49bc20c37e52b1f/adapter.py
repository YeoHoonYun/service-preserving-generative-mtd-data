def upstream(operation):
    paths = {
        'ticket_list': '/api/tickets/',
        'ticket_create': '/api/tickets/',
        'ticket_detail_one': '/api/tickets/1/',
        'my_tickets': '/api/user_tickets/',
        'followup_list': '/api/followups/',
        'followup_detail_one': '/api/followups/1/'
    }
    return paths[operation] if operation in paths else None
