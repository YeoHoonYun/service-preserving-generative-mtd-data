def resolve(method, path):
    if method == 'GET':
        if path == '/api/tickets/':
            return 'ticket_list'
        if path == '/api/tickets/1/':
            return 'ticket_detail_one'
        if path == '/api/user_tickets/':
            return 'my_tickets'
        if path == '/api/followups/':
            return 'followup_list'
        if path == '/api/followups/1/':
            return 'followup_detail_one'
    else:
        if method == 'POST':
            if path == '/api/tickets/':
                return 'ticket_create'
    return None