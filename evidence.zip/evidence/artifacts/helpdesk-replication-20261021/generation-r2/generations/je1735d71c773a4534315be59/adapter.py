def upstream(operation):
    if operation in ('ticket_list', 'ticket_create', 'ticket_detail_one'):
        if operation == 'ticket_detail_one':
            return '/api/tickets/1/'
        else:
            return '/api/tickets/'
    if operation in ('followup_list', 'followup_detail_one'):
        if operation == 'followup_detail_one':
            return '/api/followups/1/'
        else:
            return '/api/followups/'
    if operation == 'my_tickets':
        return '/api/user_tickets/'
    return None