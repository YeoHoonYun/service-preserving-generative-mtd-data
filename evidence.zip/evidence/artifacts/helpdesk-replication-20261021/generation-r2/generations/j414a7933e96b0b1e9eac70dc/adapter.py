def upstream(operation):
    if operation in ('ticket_list', 'ticket_create'):
        return '/api/tickets/'
    if operation == 'ticket_detail_one':
        return '/api/tickets/1/'
    if operation == 'my_tickets':
        return '/api/user_tickets/'
    if operation == 'followup_list':
        return '/api/followups/'
    if operation == 'followup_detail_one':
        return '/api/followups/1/'
    return None
