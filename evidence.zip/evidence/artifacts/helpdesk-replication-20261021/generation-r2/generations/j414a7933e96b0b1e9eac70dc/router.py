def resolve(method, path):
    if method == 'GET' and path == '/api/tickets/':
        return 'ticket_list'
    if method == 'POST' and path == '/api/tickets/':
        return 'ticket_create'
    if method == 'GET' and path == '/api/tickets/1/':
        return 'ticket_detail_one'
    if method == 'GET' and path == '/api/user_tickets/':
        return 'my_tickets'
    if method == 'GET' and path == '/api/followups/':
        return 'followup_list'
    if method == 'GET' and path == '/api/followups/1/':
        return 'followup_detail_one'
    return None
