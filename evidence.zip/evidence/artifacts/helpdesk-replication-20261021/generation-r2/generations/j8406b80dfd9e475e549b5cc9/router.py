def resolve(method, path):
    routes = {
        ('GET', '/api/tickets/'): 'ticket_list',
        ('POST', '/api/tickets/'): 'ticket_create',
        ('GET', '/api/tickets/1/'): 'ticket_detail_one',
        ('GET', '/api/user_tickets/'): 'my_tickets',
        ('GET', '/api/followups/'): 'followup_list',
        ('GET', '/api/followups/1/'): 'followup_detail_one',
    }
    key = (method, path)
    return routes[key] if key in routes else None
