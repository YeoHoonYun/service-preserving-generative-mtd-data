def resolve(method, path):
    return 'search' if (method, path) == ('GET', '/rest/products/search') else ('login' if (method, path) == ('POST', '/rest/user/login') else None)
