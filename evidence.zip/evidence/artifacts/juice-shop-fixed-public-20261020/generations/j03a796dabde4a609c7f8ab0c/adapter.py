def upstream(operation):
    return '/rest/products/search' if (operation,) == ('search',) else ('/rest/user/login' if (operation,) == ('login',) else None)
