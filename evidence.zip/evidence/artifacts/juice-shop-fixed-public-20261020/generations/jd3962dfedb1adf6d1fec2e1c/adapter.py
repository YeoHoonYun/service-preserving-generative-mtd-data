def upstream(operation):
    if operation == 'login':
        return '/rest/user/login'
    if operation == 'search':
        return '/rest/products/search'
    return None
