def resolve(method, path):
    if method == 'POST' and path == '/rest/user/login':
        return 'login'
    if method == 'GET' and path == '/rest/products/search':
        return 'search'
    return None
