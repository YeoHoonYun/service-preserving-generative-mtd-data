def resolve(method, path):
    if method == 'GET':
        if path == '/rest/products/search':
            return 'search'
    else:
        if method == 'POST':
            if path == '/rest/user/login':
                return 'login'
    return None
