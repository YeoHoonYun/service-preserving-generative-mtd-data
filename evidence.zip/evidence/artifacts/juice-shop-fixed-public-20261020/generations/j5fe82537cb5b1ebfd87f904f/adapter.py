def upstream(operation):
    if operation in ('search', 'login'):
        if operation == 'search':
            return '/rest/products/search'
        else:
            return '/rest/user/login'
    return None
