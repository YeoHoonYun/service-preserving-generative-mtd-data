(function(){const generation=(()=>"j3a42f2dc2ae7004608d37bfd")();window.__researchGeneration=generation;
      function selected(input) {
        const url = new URL(input, window.location.href);
        return url.origin === window.location.origin &&
          (url.pathname === '/rest/products/search' || url.pathname === '/rest/user/login');
      }
      const open = XMLHttpRequest.prototype.open;
      const send = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        this.__researchSelected = selected(url);
        return open.call(this, method, url, ...rest);
      };
      XMLHttpRequest.prototype.send = function(...args) {
        if (this.__researchSelected) this.setRequestHeader('X-Research-Client', generation);
        return send.apply(this, args);
      };
      const fetchOriginal = window.fetch;
      window.fetch = function(input, init) {
        const url = input instanceof Request ? input.url : input;
        if (!selected(url)) return fetchOriginal.call(this, input, init);
        const request = new Request(input, init);
        const headers = new Headers(request.headers);
        headers.set('X-Research-Client', generation);
        return fetchOriginal.call(this, new Request(request, {headers}));
      };
    })();