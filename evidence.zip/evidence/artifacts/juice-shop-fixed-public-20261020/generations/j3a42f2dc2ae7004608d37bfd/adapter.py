def upstream(operation):
    paths = {'search': '/rest/products/search', 'login': '/rest/user/login'}
    return paths[operation] if operation in paths else None
