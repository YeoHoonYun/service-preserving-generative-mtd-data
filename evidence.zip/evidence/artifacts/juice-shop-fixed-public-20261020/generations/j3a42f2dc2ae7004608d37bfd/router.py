def resolve(method, path):
    routes = {'/rest/products/search': ('GET', 'search'), '/rest/user/login': ('POST', 'login')}
    if path in routes:
        route = routes[path]
        if method == route[0]:
            return route[1]
    return None
