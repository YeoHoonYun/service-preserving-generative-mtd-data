'use strict';
const generation = "j97c60a9a1c6585d8e50c51a8";
const routes = {"login": "/g/edab7426dda28f7e/login", "basket_add": "/g/dc4b38ff079efb9d/basket_add"};
let products = [], token = null, basketId = null;
const list = document.querySelector('#products');
const status = document.querySelector('#status');
window.__researchGeneration = generation;
function render(rows) {
    list.replaceChildren();
    const nodes = rows.map(product => {
      const li = document.createElement('li');
      li.appendChild(document.createTextNode(product.name + ' - ' + product.price));
      return li;
    });
    list.replaceChildren(...nodes);
}
async function catalog() {
    const response = await fetch('/study/catalog');
    if (!response.ok) throw Error('catalog HTTP ' + response.status);
    products = (await response.json()).data;
    render(products);
}
document.querySelector('#search').addEventListener('click', () => {
    const query = document.querySelector('#query').value.toLowerCase();
    render(products.filter(product => product.name.toLowerCase().includes(query)));
});
document.querySelector('#login').addEventListener('click', async () => {
    const response = await fetch(routes.login, {method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({email:document.querySelector('#email').value,
                           password:document.querySelector('#password').value})});
    const result = await response.json();
    if (!response.ok || !result.authentication) { status.textContent='Login failed'; return; }
    token = result.authentication.token;
    basketId = result.authentication.bid;
    status.textContent='Signed in';
});
document.querySelector('#add').addEventListener('click', async () => {
    if (!token) { status.textContent='Login required'; return; }
    const apple = products.find(product => product.name === 'Apple Juice (1000ml)');
    if (!apple) { status.textContent='Product unavailable'; return; }
    const response = await fetch(routes.basket_add, {method:'POST',
      headers:{'Content-Type':'application/json', 'Authorization':'Bearer ' + token},
      body:JSON.stringify({ProductId:apple.id, BasketId:basketId, quantity:1})});
    status.textContent = response.ok ? 'Added to basket' : 'Basket failed';
});
catalog().catch(error => {status.textContent=error.message;});
