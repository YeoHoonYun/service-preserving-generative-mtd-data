def project(rows):
    return list(map(lambda row: {'id': row['id'], 'name': row['name'], 'price': row['price']}, rows[:12]))
