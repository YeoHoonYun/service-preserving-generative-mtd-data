def project(rows):
    return [{'id': row['id'], 'name': row['name'], 'price': row['price']} for row in rows[:12]]
