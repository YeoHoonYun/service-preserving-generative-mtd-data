def project(rows):
    result = []
    for row in rows[:12]:
        result.append(dict((key, row[key]) for key in ('id', 'name', 'price')))
    return result
