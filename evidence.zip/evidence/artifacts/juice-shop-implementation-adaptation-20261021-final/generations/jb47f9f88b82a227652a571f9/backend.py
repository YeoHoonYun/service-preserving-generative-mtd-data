def project(rows):
    result = []
    index = 0
    while index < min(12, len(rows)):
        row = rows[index]
        result.append({'id': row['id'], 'name': row['name'], 'price': row['price']})
        index += 1
    return result
