'use strict';
const generation = "jb47f9f88b82a227652a571f9";
const routes = {"login": "/g/3dfbbc9f05aac52d/login", "basket_add": "/g/8b6820c55150d180/basket_add"};
let products = [], token = null, basketId = null;
const list = document.querySelector('#products');
const status = document.querySelector('#status');
window.__researchGeneration = generation;
function render(rows) {
    list.replaceChildren();
    let index = 0;
    while (index < rows.length) {
      const product = rows[index++];
      const li = document.createElement('li');
      li.textContent = [product.name, product.price].join(' - ');
      list.append(li);
    }
}
async function catalog() {
    const response = await fetch('/study/catalog');
    if (!response.ok) throw Error('catalog HTTP ' + response.status);
    products = (await response.json()).data;
    render(products);
}
document.querySelector('#search').addEventListener('click', () => {
    const query = document.querySelector('#query').value.toLowerCase();
    render(products.filter(product => product.name.toLowerCase().includes(query)));
});
document.querySelector('#login').addEventListener('click', async () => {
    const response = await fetch(routes.login, {method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({email:document.querySelector('#email').value,
                           password:document.querySelector('#password').value})});
    const result = await response.json();
    if (!response.ok || !result.authentication) { status.textContent='Login failed'; return; }
    token = result.authentication.token;
    basketId = result.authentication.bid;
    status.textContent='Signed in';
});
document.querySelector('#add').addEventListener('click', async () => {
    if (!token) { status.textContent='Login required'; return; }
    const apple = products.find(product => product.name === 'Apple Juice (1000ml)');
    if (!apple) { status.textContent='Product unavailable'; return; }
    const response = await fetch(routes.basket_add, {method:'POST',
      headers:{'Content-Type':'application/json', 'Authorization':'Bearer ' + token},
      body:JSON.stringify({ProductId:apple.id, BasketId:basketId, quantity:1})});
    status.textContent = response.ok ? 'Added to basket' : 'Basket failed';
});
catalog().catch(error => {status.textContent=error.message;});
