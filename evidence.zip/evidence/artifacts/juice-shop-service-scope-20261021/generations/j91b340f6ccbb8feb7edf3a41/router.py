def resolve(method, path):
    entries = {
        ('GET', '/api/Products'): 'catalog',
        ('GET', '/rest/products/search'): 'search',
        ('POST', '/api/Users'): 'signup',
        ('POST', '/rest/user/login'): 'login',
        ('GET', '/rest/user/whoami'): 'whoami',
        ('POST', '/api/BasketItems/'): 'basket_add',
        ('GET', '/api/Deliverys'): 'deliveries',
        ('GET', '/api/Addresss'): 'addresses',
        ('GET', '/api/Cards'): 'payment_methods',
        ('GET', '/rest/order-history'): 'history'
    }
    route_key = (method, path)
    if route_key in entries:
        return entries[route_key]
    return None
