(function(){
      'use strict';
      const table={"/api/Products":"/g/ad779541d68bdca9/catalog","/rest/products/search":"/g/babc47090b8b2b5d/search","/api/Users":"/g/077b44d66ec91951/signup","/rest/user/login":"/g/31fea479091f33d1/login","/rest/user/whoami":"/g/2139394f6688da2b/whoami","/api/BasketItems/":"/g/981b728a68836128/basket_add","/api/Deliverys":"/g/3e6ac6820acff34b/deliveries","/api/Addresss":"/g/b5acfcb3f2cf880c/addresses","/api/Cards":"/g/41e4aeb4422f65af/payment_methods","/rest/order-history":"/g/1045f473a94a2293/history"};
      const generation="j91b340f6ccbb8feb7edf3a41";
      window.__researchGeneration=generation;
      function rewrite(input){
        if(typeof input!=='string') return input;
        const url=new URL(input,window.location.href);
        if(url.origin!==window.location.origin) return input;
        const pair = Object.entries(table).find(pair => pair[0] === url.pathname); const match = pair && pair[1];
        if(!match) return input;
        url.pathname=match;
        return input.startsWith('http') ? url.href : url.pathname+url.search+url.hash;
      }
      const originalOpen=XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open=function(method,url,...rest){
        return originalOpen.call(this,method,rewrite(url),...rest);
      };
      const originalFetch=window.fetch;
      window.fetch=function(input,init){
        if(input instanceof Request) return originalFetch.call(this,new Request(rewrite(input.url),input),init);
        return originalFetch.call(this,rewrite(input),init);
      };
    })();