def upstream(operation):
    entries = {
        ('catalog',): '/api/Products',
        ('search',): '/rest/products/search',
        ('signup',): '/api/Users',
        ('login',): '/rest/user/login',
        ('whoami',): '/rest/user/whoami',
        ('basket_add',): '/api/BasketItems/',
        ('deliveries',): '/api/Deliverys',
        ('addresses',): '/api/Addresss',
        ('payment_methods',): '/api/Cards',
        ('history',): '/rest/order-history'
    }
    operation_key = (operation,)
    return entries[operation_key] if operation_key in entries else None
