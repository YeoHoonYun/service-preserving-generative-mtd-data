(function(){
      'use strict';
      const table={"/api/Products":"/g/525930b1e3f7e4b7/catalog","/rest/products/search":"/g/97090619e9c48629/search","/api/Users":"/g/84260eaeea26263b/signup","/rest/user/login":"/g/df9fbb8ddb35b8fa/login","/rest/user/whoami":"/g/24065f91a8be6c58/whoami","/api/BasketItems/":"/g/c09cfe69e51a3c6a/basket_add","/api/Deliverys":"/g/14990dba0ca184d7/deliveries","/api/Addresss":"/g/ff209f3a89d9323a/addresses","/api/Cards":"/g/6fe0a9d8ec4db951/payment_methods","/rest/order-history":"/g/75aa8997883fbd1c/history"};
      const generation="j6b8745256a1b9a8e8496bcdd";
      window.__researchGeneration=generation;
      function rewrite(input){
        if(typeof input!=='string') return input;
        const url=new URL(input,window.location.href);
        if(url.origin!==window.location.origin) return input;
        const match = table[url.pathname];
        if(!match) return input;
        url.pathname=match;
        return input.startsWith('http') ? url.href : url.pathname+url.search+url.hash;
      }
      const originalOpen=XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open=function(method,url,...rest){
        return originalOpen.call(this,method,rewrite(url),...rest);
      };
      const originalFetch=window.fetch;
      window.fetch=function(input,init){
        if(input instanceof Request) return originalFetch.call(this,new Request(rewrite(input.url),input),init);
        return originalFetch.call(this,rewrite(input),init);
      };
    })();