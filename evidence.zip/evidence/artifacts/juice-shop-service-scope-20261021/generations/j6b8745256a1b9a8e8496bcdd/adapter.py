def upstream(operation):
    if operation in ('catalog', 'search', 'whoami'):
        if operation == 'catalog':
            return '/api/Products'
        elif operation == 'search':
            return '/rest/products/search'
        else:
            return '/rest/user/whoami'
    elif operation in ('signup', 'login', 'basket_add'):
        if operation == 'signup':
            return '/api/Users'
        elif operation == 'login':
            return '/rest/user/login'
        else:
            return '/api/BasketItems/'
    elif operation in ('deliveries', 'addresses', 'payment_methods', 'history'):
        if operation == 'deliveries':
            return '/api/Deliverys'
        elif operation == 'addresses':
            return '/api/Addresss'
        elif operation == 'payment_methods':
            return '/api/Cards'
        else:
            return '/rest/order-history'
    return None
