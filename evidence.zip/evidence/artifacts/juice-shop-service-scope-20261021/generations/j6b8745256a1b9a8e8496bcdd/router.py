def resolve(method, path):
    if method == 'GET':
        if path == '/api/Products':
            return 'catalog'
        elif path == '/rest/products/search':
            return 'search'
        elif path == '/rest/user/whoami':
            return 'whoami'
        elif path == '/api/Deliverys':
            return 'deliveries'
        elif path == '/api/Addresss':
            return 'addresses'
        elif path == '/api/Cards':
            return 'payment_methods'
        elif path == '/rest/order-history':
            return 'history'
    elif method == 'POST':
        if path == '/api/Users':
            return 'signup'
        elif path == '/rest/user/login':
            return 'login'
        elif path == '/api/BasketItems/':
            return 'basket_add'
    return None
