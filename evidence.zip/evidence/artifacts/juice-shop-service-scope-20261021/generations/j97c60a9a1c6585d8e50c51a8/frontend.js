(function(){
      'use strict';
      const table={"/api/Products":"/g/33b588b16c278366/catalog","/rest/products/search":"/g/6e93395d27b0e469/search","/api/Users":"/g/608adb93fd4844af/signup","/rest/user/login":"/g/edab7426dda28f7e/login","/rest/user/whoami":"/g/3c6c5fc35c2a2c89/whoami","/api/BasketItems/":"/g/dc4b38ff079efb9d/basket_add","/api/Deliverys":"/g/533b466b89ccb5ac/deliveries","/api/Addresss":"/g/fd2e55cb530b4c1d/addresses","/api/Cards":"/g/3aaa3d667ad87a26/payment_methods","/rest/order-history":"/g/9303a67409a11507/history"};
      const generation="j97c60a9a1c6585d8e50c51a8";
      window.__researchGeneration=generation;
      function rewrite(input){
        if(typeof input!=='string') return input;
        const url=new URL(input,window.location.href);
        if(url.origin!==window.location.origin) return input;
        const match = new Map(Object.entries(table)).get(url.pathname);
        if(!match) return input;
        url.pathname=match;
        return input.startsWith('http') ? url.href : url.pathname+url.search+url.hash;
      }
      const originalOpen=XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open=function(method,url,...rest){
        return originalOpen.call(this,method,rewrite(url),...rest);
      };
      const originalFetch=window.fetch;
      window.fetch=function(input,init){
        if(input instanceof Request) return originalFetch.call(this,new Request(rewrite(input.url),input),init);
        return originalFetch.call(this,rewrite(input),init);
      };
    })();