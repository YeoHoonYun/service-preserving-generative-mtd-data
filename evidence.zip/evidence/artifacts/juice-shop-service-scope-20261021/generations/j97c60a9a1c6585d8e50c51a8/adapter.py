def upstream(operation):
    if operation == 'catalog':
        return '/api/Products'
    if operation == 'search':
        return '/rest/products/search'
    if operation == 'signup':
        return '/api/Users'
    if operation == 'login':
        return '/rest/user/login'
    if operation == 'whoami':
        return '/rest/user/whoami'
    if operation == 'basket_add':
        return '/api/BasketItems/'
    if operation == 'deliveries':
        return '/api/Deliverys'
    if operation == 'addresses':
        return '/api/Addresss'
    if operation == 'payment_methods':
        return '/api/Cards'
    if operation == 'history':
        return '/rest/order-history'
    return None
