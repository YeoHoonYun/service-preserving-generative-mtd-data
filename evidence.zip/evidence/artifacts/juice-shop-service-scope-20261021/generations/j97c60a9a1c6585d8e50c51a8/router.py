def resolve(method, path):
    if path == '/api/Products' and method == 'GET':
        return 'catalog'
    if path == '/rest/products/search' and method == 'GET':
        return 'search'
    if path == '/api/Users' and method == 'POST':
        return 'signup'
    if path == '/rest/user/login' and method == 'POST':
        return 'login'
    if path == '/rest/user/whoami' and method == 'GET':
        return 'whoami'
    if path == '/api/BasketItems/' and method == 'POST':
        return 'basket_add'
    if path == '/api/Deliverys' and method == 'GET':
        return 'deliveries'
    if path == '/api/Addresss' and method == 'GET':
        return 'addresses'
    if path == '/api/Cards' and method == 'GET':
        return 'payment_methods'
    if path == '/rest/order-history' and method == 'GET':
        return 'history'
    return None
