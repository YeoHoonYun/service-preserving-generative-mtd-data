def upstream(operation):
    return (
        '/rest/order-history' if operation in ('history',) else
        '/api/Cards' if operation in ('payment_methods',) else
        '/api/Addresss' if operation in ('addresses',) else
        '/api/Deliverys' if operation in ('deliveries',) else
        '/api/BasketItems/' if operation in ('basket_add',) else
        '/rest/user/whoami' if operation in ('whoami',) else
        '/rest/user/login' if operation in ('login',) else
        '/api/Users' if operation in ('signup',) else
        '/rest/products/search' if operation in ('search',) else
        '/api/Products' if operation in ('catalog',) else
        None
    )