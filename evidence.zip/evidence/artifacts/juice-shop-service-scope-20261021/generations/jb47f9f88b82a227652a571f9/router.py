def resolve(method, path):
    route = (method, path)
    return (
        'catalog' if route in (('GET', '/api/Products'),) else
        'search' if route in (('GET', '/rest/products/search'),) else
        'signup' if route in (('POST', '/api/Users'),) else
        'login' if route in (('POST', '/rest/user/login'),) else
        'whoami' if route in (('GET', '/rest/user/whoami'),) else
        'basket_add' if route in (('POST', '/api/BasketItems/'),) else
        'deliveries' if route in (('GET', '/api/Deliverys'),) else
        'addresses' if route in (('GET', '/api/Addresss'),) else
        'payment_methods' if route in (('GET', '/api/Cards'),) else
        'history' if route in (('GET', '/rest/order-history'),) else
        None
    )