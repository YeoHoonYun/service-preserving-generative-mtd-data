(function(){
      'use strict';
      const table={"/api/Products":"/g/0fabf46033d8e4f4/catalog","/rest/products/search":"/g/d4983681f03c873c/search","/api/Users":"/g/822376c1a1f1c116/signup","/rest/user/login":"/g/3dfbbc9f05aac52d/login","/rest/user/whoami":"/g/987e6c2aa28f0c98/whoami","/api/BasketItems/":"/g/8b6820c55150d180/basket_add","/api/Deliverys":"/g/09cc84e59a2b496f/deliveries","/api/Addresss":"/g/d28b548965bc325f/addresses","/api/Cards":"/g/925712cf76b7c3c3/payment_methods","/rest/order-history":"/g/aaa1cf4de4737926/history"};
      const generation="jb47f9f88b82a227652a571f9";
      window.__researchGeneration=generation;
      function rewrite(input){
        if(typeof input!=='string') return input;
        const url=new URL(input,window.location.href);
        if(url.origin!==window.location.origin) return input;
        let match; for (const key of Object.keys(table)) { if (key === url.pathname) { match = table[key]; break; } }
        if(!match) return input;
        url.pathname=match;
        return input.startsWith('http') ? url.href : url.pathname+url.search+url.hash;
      }
      const originalOpen=XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open=function(method,url,...rest){
        return originalOpen.call(this,method,rewrite(url),...rest);
      };
      const originalFetch=window.fetch;
      window.fetch=function(input,init){
        if(input instanceof Request) return originalFetch.call(this,new Request(rewrite(input.url),input),init);
        return originalFetch.call(this,rewrite(input),init);
      };
    })();