# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x03c5897295ae1fc0ca534018', 'fields': ['password', 'username'], 'aliases': {'password': 'x3b416c9315d3ff4b2069138f', 'username': 'x17cf0c451c91fbd1d18f2fc8'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x27d3e51844de5aa03eca3ff1', 'response_box': 'x3aa7b25a9c7c8d41f491b85c', 'result_key': 'x5bd9032b68f88184b7dbb9cc'}, 'logout': {'route': '/x10582a48654caff0f8be89de', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'object', 'request_box': 'xf73b83fb77bea7ab9ba79c20', 'response_box': 'x26589e92226c0949050aa83e', 'result_key': 'x5f5f901e51aeffe2ebdccb5a'}, 'catalog': {'route': '/xe95b1733a02c25fb8fda64a9', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'x4f5fe83f96800e4ff981b188', 'response_box': 'xc632cea69dfa54f03256d62b', 'result_key': 'x3bb4d71944f427f4fada6be8'}, 'create_order': {'route': '/x9569ffebaa4cbd8560c5208a', 'fields': ['product_id', 'request_id', 'quantity'], 'aliases': {'product_id': 'xc0fe2c6e96b08fee374400bc', 'request_id': 'x567ada3d263e49125f36d05c', 'quantity': 'x116d80e5499b280735345811'}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'x551c6b8db3a4fb3a5c29cbcf', 'response_box': 'x6effd48e51a1c7e9eca7c494', 'result_key': 'xdfa9516d711b9ffc2d3ad886'}, 'order': {'route': '/x72f7b98df4ace2cb928ebd75', 'fields': ['order_id'], 'aliases': {'order_id': 'x8bf0b2b23b091dbcf95c51da'}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'x770cf13b996b762e25f377e6', 'response_box': 'x72c5baed49967ebeb05631ec', 'result_key': 'xc887d37b89c5ef8a3c4b2e6a'}, 'orders': {'route': '/xb4b5ccb54d5c247c3bede456', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'xa95e4514b3f0aee10d5b935c', 'response_box': 'x01eb3d7388b44679b3c2ec84', 'result_key': 'x2e9ead36416b1498c0cbdabd'}, 'update_product': {'route': '/x1af1d9f5dff5d200a8b836e4', 'fields': ['price', 'stock', 'product_id'], 'aliases': {'price': 'x9eff10f05a09916241ef7fa6', 'stock': 'xd25d2e8b6285965bbea93c3d', 'product_id': 'x0d0632bdeec4b68e70135f67'}, 'request_shape': 'positional', 'response_shape': 'wrapped', 'request_box': 'xeef780dd97764ee4d2e3e9db', 'response_box': 'x20b042e19eb35c28fd7a2eb7', 'result_key': 'xdf928b910e70ed3aa26c5d18'}}
HANDLERS = {'login': 'xca0fbe6423299a057e611749', 'logout': 'x37626aec98803104113cc459', 'catalog': 'x2c2e3a8d2150f6d78b4ba089', 'create_order': 'xdf6bb69e20063e2b36781059', 'order': 'x61892b0b5c21610f58448d76', 'orders': 'xf9ae1605919e4b25d4a659db', 'update_product': 'xe607920762a4b928ed8330c2'}
BACKEND_GRAPH = {'xca0fbe6423299a057e611749': {'operation': 'login', 'target': 'x178c0e51e493c7b58988304f', 'kind': 'adapter'}, 'x178c0e51e493c7b58988304f': {'operation': 'login', 'target': 'x78a443bd6d3bb27a580a6ee4', 'kind': 'adapter'}, 'x78a443bd6d3bb27a580a6ee4': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x37626aec98803104113cc459': {'operation': 'logout', 'target': 'xee71b7d37596fb848c8789c4', 'kind': 'adapter'}, 'xee71b7d37596fb848c8789c4': {'operation': 'logout', 'target': 'xe6ae6e261a0c3e87035bb5f6', 'kind': 'adapter'}, 'xe6ae6e261a0c3e87035bb5f6': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x2c2e3a8d2150f6d78b4ba089': {'operation': 'catalog', 'target': 'xcb88bd349b1038dfc9872cd6', 'kind': 'adapter'}, 'xcb88bd349b1038dfc9872cd6': {'operation': 'catalog', 'target': 'x01c3e256a52408e02ec181cc', 'kind': 'adapter'}, 'x01c3e256a52408e02ec181cc': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'xdf6bb69e20063e2b36781059': {'operation': 'create_order', 'target': 'x79866dfa7ae7192694ad8cae', 'kind': 'adapter'}, 'x79866dfa7ae7192694ad8cae': {'operation': 'create_order', 'target': 'x825d4ded77dd1b3c2fa46479', 'kind': 'adapter'}, 'x825d4ded77dd1b3c2fa46479': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x61892b0b5c21610f58448d76': {'operation': 'order', 'target': 'x6ae0cdf230fb4e11e08b88c8', 'kind': 'adapter'}, 'x6ae0cdf230fb4e11e08b88c8': {'operation': 'order', 'target': 'x623b85e8126490b18cf510a0', 'kind': 'adapter'}, 'x623b85e8126490b18cf510a0': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'xf9ae1605919e4b25d4a659db': {'operation': 'orders', 'target': 'x71a709213d13500f4d526b82', 'kind': 'adapter'}, 'x71a709213d13500f4d526b82': {'operation': 'orders', 'target': 'x0a5438df06a1cb7a17f90c95', 'kind': 'adapter'}, 'x0a5438df06a1cb7a17f90c95': {'operation': 'orders', 'target': 'x0e036c7fb943bb06ba3ae43c', 'kind': 'adapter'}, 'x0e036c7fb943bb06ba3ae43c': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'xe607920762a4b928ed8330c2': {'operation': 'update_product', 'target': 'xb59f5421e86c8f74aa7dacc0', 'kind': 'adapter'}, 'xb59f5421e86c8f74aa7dacc0': {'operation': 'update_product', 'target': 'x5801f229d29c1f9e81656ec0', 'kind': 'adapter'}, 'x5801f229d29c1f9e81656ec0': {'operation': 'update_product', 'target': 'x5173d797bdd0db1e128760d6', 'kind': 'adapter'}, 'x5173d797bdd0db1e128760d6': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xca0fbe6423299a057e611749(core, operation, data, session, actor, trace):
    trace.append('xca0fbe6423299a057e611749')
    return x178c0e51e493c7b58988304f(core, operation, data, session, actor, trace)

def x178c0e51e493c7b58988304f(core, operation, data, session, actor, trace):
    trace.append('x178c0e51e493c7b58988304f')
    return x78a443bd6d3bb27a580a6ee4(core, operation, data, session, actor, trace)

def x78a443bd6d3bb27a580a6ee4(core, operation, data, session, actor, trace):
    trace.append('x78a443bd6d3bb27a580a6ee4')
    return core.execute(operation, data, session, actor)

def x37626aec98803104113cc459(core, operation, data, session, actor, trace):
    trace.append('x37626aec98803104113cc459')
    return xee71b7d37596fb848c8789c4(core, operation, data, session, actor, trace)

def xee71b7d37596fb848c8789c4(core, operation, data, session, actor, trace):
    trace.append('xee71b7d37596fb848c8789c4')
    return xe6ae6e261a0c3e87035bb5f6(core, operation, data, session, actor, trace)

def xe6ae6e261a0c3e87035bb5f6(core, operation, data, session, actor, trace):
    trace.append('xe6ae6e261a0c3e87035bb5f6')
    return core.execute(operation, data, session, actor)

def x2c2e3a8d2150f6d78b4ba089(core, operation, data, session, actor, trace):
    trace.append('x2c2e3a8d2150f6d78b4ba089')
    return xcb88bd349b1038dfc9872cd6(core, operation, data, session, actor, trace)

def xcb88bd349b1038dfc9872cd6(core, operation, data, session, actor, trace):
    trace.append('xcb88bd349b1038dfc9872cd6')
    return x01c3e256a52408e02ec181cc(core, operation, data, session, actor, trace)

def x01c3e256a52408e02ec181cc(core, operation, data, session, actor, trace):
    trace.append('x01c3e256a52408e02ec181cc')
    return core.execute(operation, data, session, actor)

def xdf6bb69e20063e2b36781059(core, operation, data, session, actor, trace):
    trace.append('xdf6bb69e20063e2b36781059')
    return x79866dfa7ae7192694ad8cae(core, operation, data, session, actor, trace)

def x79866dfa7ae7192694ad8cae(core, operation, data, session, actor, trace):
    trace.append('x79866dfa7ae7192694ad8cae')
    return x825d4ded77dd1b3c2fa46479(core, operation, data, session, actor, trace)

def x825d4ded77dd1b3c2fa46479(core, operation, data, session, actor, trace):
    trace.append('x825d4ded77dd1b3c2fa46479')
    return core.execute(operation, data, session, actor)

def x61892b0b5c21610f58448d76(core, operation, data, session, actor, trace):
    trace.append('x61892b0b5c21610f58448d76')
    return x6ae0cdf230fb4e11e08b88c8(core, operation, data, session, actor, trace)

def x6ae0cdf230fb4e11e08b88c8(core, operation, data, session, actor, trace):
    trace.append('x6ae0cdf230fb4e11e08b88c8')
    return x623b85e8126490b18cf510a0(core, operation, data, session, actor, trace)

def x623b85e8126490b18cf510a0(core, operation, data, session, actor, trace):
    trace.append('x623b85e8126490b18cf510a0')
    return core.execute(operation, data, session, actor)

def xf9ae1605919e4b25d4a659db(core, operation, data, session, actor, trace):
    trace.append('xf9ae1605919e4b25d4a659db')
    return x71a709213d13500f4d526b82(core, operation, data, session, actor, trace)

def x71a709213d13500f4d526b82(core, operation, data, session, actor, trace):
    trace.append('x71a709213d13500f4d526b82')
    return x0a5438df06a1cb7a17f90c95(core, operation, data, session, actor, trace)

def x0a5438df06a1cb7a17f90c95(core, operation, data, session, actor, trace):
    trace.append('x0a5438df06a1cb7a17f90c95')
    return x0e036c7fb943bb06ba3ae43c(core, operation, data, session, actor, trace)

def x0e036c7fb943bb06ba3ae43c(core, operation, data, session, actor, trace):
    trace.append('x0e036c7fb943bb06ba3ae43c')
    return core.execute(operation, data, session, actor)

def xe607920762a4b928ed8330c2(core, operation, data, session, actor, trace):
    trace.append('xe607920762a4b928ed8330c2')
    return xb59f5421e86c8f74aa7dacc0(core, operation, data, session, actor, trace)

def xb59f5421e86c8f74aa7dacc0(core, operation, data, session, actor, trace):
    trace.append('xb59f5421e86c8f74aa7dacc0')
    return x5801f229d29c1f9e81656ec0(core, operation, data, session, actor, trace)

def x5801f229d29c1f9e81656ec0(core, operation, data, session, actor, trace):
    trace.append('x5801f229d29c1f9e81656ec0')
    return x5173d797bdd0db1e128760d6(core, operation, data, session, actor, trace)

def x5173d797bdd0db1e128760d6(core, operation, data, session, actor, trace):
    trace.append('x5173d797bdd0db1e128760d6')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def adapter_slot(name, size):
    return int(name[-2:], 16) % size

def locate_adapter(handler_name):
    entries = (
        ('xca0fbe6423299a057e611749', xca0fbe6423299a057e611749),
        ('x37626aec98803104113cc459', x37626aec98803104113cc459),
        ('x2c2e3a8d2150f6d78b4ba089', x2c2e3a8d2150f6d78b4ba089),
        ('xdf6bb69e20063e2b36781059', xdf6bb69e20063e2b36781059),
        ('x61892b0b5c21610f58448d76', x61892b0b5c21610f58448d76),
        ('xf9ae1605919e4b25d4a659db', xf9ae1605919e4b25d4a659db),
        ('xe607920762a4b928ed8330c2', xe607920762a4b928ed8330c2)
    )
    slots = [None] * 11
    for entry in entries:
        position = adapter_slot(entry[0], len(slots))
        while slots[position] is not None:
            position = (position + 1) % len(slots)
        slots[position] = entry
    position = adapter_slot(handler_name, len(slots))
    while slots[position] is not None:
        name, adapter = slots[position]
        if name == handler_name:
            return adapter
        position = (position + 1) % len(slots)
    raise KeyError(handler_name)

def execute_adapter(adapter, core, operation, data, session, actor):
    trace = []
    status, result, cookie = adapter(core, operation, data, session, actor, trace)
    return status, result, cookie, trace

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    adapter = locate_adapter(handler_name)
    return execute_adapter(adapter, core, operation, data, session, actor)

