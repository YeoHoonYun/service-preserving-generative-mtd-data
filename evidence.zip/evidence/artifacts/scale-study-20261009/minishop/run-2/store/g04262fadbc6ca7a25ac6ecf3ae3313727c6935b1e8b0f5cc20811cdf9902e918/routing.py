GRAPH = {'x20d16c8d7bdaa70a5d1f62f4': {'kind': 'router', 'edges': {'/x7294e4841c5e369d77bd9557': {'target': 'x4e19ad12a354b345d8c99827', 'next_key': 'x44bb2a0166e41b7d82e962e8'}, '/x60844813f82683cb84356f1e': {'target': 'x4e19ad12a354b345d8c99827', 'next_key': 'x05544db631fdc85c030043bd'}, '/xab6e9a227023847cf24bee05': {'target': 'x4e19ad12a354b345d8c99827', 'next_key': 'xf12fb163091a897f5689802a'}, '/x4844782d39731bd7ab5259bb': {'target': 'x4e19ad12a354b345d8c99827', 'next_key': 'x90c904d354c6b4734b695a17'}, '/xe622dbd88b68b604b469b453': {'target': 'x4e19ad12a354b345d8c99827', 'next_key': 'xd4f047d0403504c9f2fb2ae8'}, '/x94c39f4baa9fc48a9a4e83f5': {'target': 'x4e19ad12a354b345d8c99827', 'next_key': 'x8c6858a619614b8f8b8e6495'}, '/x6e9e6eacbc4a29f6677bf6fa': {'target': 'x4e19ad12a354b345d8c99827', 'next_key': 'x3e6a6111fb99f32f9b7b17ca'}}}, 'x4e19ad12a354b345d8c99827': {'kind': 'router', 'edges': {'x44bb2a0166e41b7d82e962e8': {'target': 'x0770fef87dced672975444a0', 'next_key': 'x79ad6ee84dd17405eb127a15'}, 'x05544db631fdc85c030043bd': {'target': 'x300eb60bf7c2db89d661f5f7', 'next_key': 'xb664498c49aa086f45bd42e0'}, 'xf12fb163091a897f5689802a': {'target': 'x0770fef87dced672975444a0', 'next_key': 'xa6a5af42de019e8abfea3f04'}, 'x90c904d354c6b4734b695a17': {'target': 'x300eb60bf7c2db89d661f5f7', 'next_key': 'x5900e8049c475f95e9ae95cc'}, 'xd4f047d0403504c9f2fb2ae8': {'target': 'x0770fef87dced672975444a0', 'next_key': 'xdea695f1af57c67a5b1a3034'}, 'x8c6858a619614b8f8b8e6495': {'target': 'x300eb60bf7c2db89d661f5f7', 'next_key': 'xa7342c6e98678c5d0a59e7a7'}, 'x3e6a6111fb99f32f9b7b17ca': {'target': 'x0770fef87dced672975444a0', 'next_key': 'xd6f442cb825340de2e4c7cea'}}}, 'x300eb60bf7c2db89d661f5f7': {'kind': 'router', 'edges': {'xb664498c49aa086f45bd42e0': {'target': 'x1b54a946d3f4a255af3d271a', 'next_key': None}, 'x5900e8049c475f95e9ae95cc': {'target': 'xa1c6473ba4f4e63a20d583f3', 'next_key': None}, 'xa7342c6e98678c5d0a59e7a7': {'target': 'xc04ba546ef641d1495553a57', 'next_key': None}}}, 'x0770fef87dced672975444a0': {'kind': 'router', 'edges': {'x79ad6ee84dd17405eb127a15': {'target': 'x5540a5063612790cebd3c5de', 'next_key': None}, 'xa6a5af42de019e8abfea3f04': {'target': 'x9902b66225295c44a573050e', 'next_key': None}, 'xdea695f1af57c67a5b1a3034': {'target': 'x5ec49a1e962cfc0ea933189c', 'next_key': None}, 'xd6f442cb825340de2e4c7cea': {'target': 'x0e40601059d2e2eff8314628', 'next_key': None}}}, 'x5540a5063612790cebd3c5de': {'kind': 'service', 'operation': 'login', 'handler': 'xf07791a536a6ceb776323e5c'}, 'x1b54a946d3f4a255af3d271a': {'kind': 'service', 'operation': 'logout', 'handler': 'x5ef05e8db437bc185fdf4eae'}, 'x9902b66225295c44a573050e': {'kind': 'service', 'operation': 'catalog', 'handler': 'x1e45ea6de011de745e3c2463'}, 'xa1c6473ba4f4e63a20d583f3': {'kind': 'service', 'operation': 'create_order', 'handler': 'x6b7d337de1b3b983f8bb91ee'}, 'x5ec49a1e962cfc0ea933189c': {'kind': 'service', 'operation': 'order', 'handler': 'xd0cfdc964de1e4e85f1a28dd'}, 'xc04ba546ef641d1495553a57': {'kind': 'service', 'operation': 'orders', 'handler': 'x5c46b647f3b5fa57346e7879'}, 'x0e40601059d2e2eff8314628': {'kind': 'service', 'operation': 'update_product', 'handler': 'x03a7b261904ee6ed82f493b4'}}
ENTRY = 'x20d16c8d7bdaa70a5d1f62f4'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def route_walk(graph, entry, key):
    node = entry
    trace = []
    seen = set()
    while True:
        if node in seen:
            raise ValueError('routing cycle')
        seen.add(node)
        trace.append(node)
        item = graph[node]
        if item['kind'] == 'service':
            return node, item, trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    paths = sorted(graph[entry]['edges'])
    root = 'route_entry'
    while root in graph:
        root += '_'
    rebuilt = {root: {'kind': 'router', 'edges': {}}}
    for start in range(0, len(paths), 3):
        branch = 'route_partition_' + str(start // 3)
        while branch in graph or branch in rebuilt:
            branch += '_'
        rebuilt[branch] = {'kind': 'router', 'edges': {}}
        for path in paths[start:start + 3]:
            leaf, service, trace = route_walk(graph, entry, path)
            rebuilt[leaf] = dict(service)
            rebuilt[root]['edges'][path] = {'target': branch, 'next_key': path}
            rebuilt[branch]['edges'][path] = {'target': leaf, 'next_key': None}
    return rebuilt, root

def resolve(path):
    node, service, trace = route_walk(GRAPH, ENTRY, path)
    return service['operation'], service['handler'], trace

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
