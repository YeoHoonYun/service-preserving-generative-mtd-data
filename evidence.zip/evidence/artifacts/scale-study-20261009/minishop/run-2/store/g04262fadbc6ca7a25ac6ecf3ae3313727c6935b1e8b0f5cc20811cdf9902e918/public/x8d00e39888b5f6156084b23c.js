import {xc488b3f6b03d8164f9f553f3,x8a793b5d61d73da728b00ff5,x16d151ee21e15fb34b35d030,x6a55c8d83db02aec65febe6c} from './xf5f2d41756d82cc264c6748e.js';
import {xeffc2b3fd6b7bafb3a21115d,xb059bba866ad0adab514a22f,x14ac0987711bcf2cbb5b5b57} from './xe0f1b6ead3c78da17b212b34.js';

let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('xe29f7c24db8f1a544fdfa325');
const endpoints={login:xc488b3f6b03d8164f9f553f3,logout:xeffc2b3fd6b7bafb3a21115d,catalog:x8a793b5d61d73da728b00ff5,create_order:xb059bba866ad0adab514a22f,order:x16d151ee21e15fb34b35d030,orders:x14ac0987711bcf2cbb5b5b57,update_product:x6a55c8d83db02aec65febe6c};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('x5d236d3a136948515ef072ae').textContent=boot.user?boot.user.id:'방문자';}
function run(promise){promise.catch(error=>message.textContent=error.message);}

const views={
 catalog:{id:'xb9151f769fad1fc18478106f',label:p=>p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock},
 orders:{id:'x834fa76e7feb4deaed018198',label:order=>order.id+' · '+order.total+'원'}
};
async function renderList(operation){
 const view=views[operation];
 const list=document.getElementById(view.id);
 list.replaceChildren();
 for(const item of await api(operation)){
  const li=document.createElement('li');
  li.textContent=view.label(item);
  list.append(li);
 }
 if(operation==='catalog')document.body.dataset.ready='yes';
}

const fields=[
 ['username','x6b8dfbdd8e42e550492fca6a'],
 ['password','x53e284ae68bc73fba96282e4'],
 ['product_id','xd7723de705d59fe022caa908'],
 ['quantity','x4644c6fbf5e95f0399a3c714'],
 ['price','x02e72a9227643feeb857f759'],
 ['stock','x9b4f790eb35783f6b5508a0d']
];
function readForm(form){
 const raw=Object.fromEntries(new FormData(form));
 return Object.fromEntries(fields.map(([name,key])=>[name,raw[key]]));
}
const actions=new Map([
 ['x366d5926e1101fbe90c960b1',async data=>{
  boot=await api('login',data);
  identity();
  message.textContent='로그인되었습니다.';
 }],
 ['x2e70af29845fe61cf4e5ad97',async data=>{
  const order=await api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()});
  message.textContent='주문 '+order.id+' · '+order.total+'원';
  await renderList('catalog');
  await renderList('orders');
 }],
 ['x70fc4d620616ea3732e46186',async data=>{
  await api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)});
  message.textContent='상품을 수정했습니다.';
  await renderList('catalog');
 }]
]);
async function submitForm(form){
 const data=readForm(form);
 const action=actions.get(form.dataset.action);
 if(action)await action(data);
}
function connect(){
 document.addEventListener('submit',event=>{
  event.preventDefault();
  run(submitForm(event.target));
 });
 document.getElementById('xaabbe61491d3574240aada7a').onclick=()=>run(api('logout').then(()=>location.reload()));
 document.getElementById('x2012237dc2de0e08f690373e').onclick=()=>run(renderList('orders'));
 identity();
 run(renderList('catalog'));
}
connect();
