import {send} from './xf9c8593fa03d3203480b74b2.js';
export async function xeffc2b3fd6b7bafb3a21115d(data,csrf){const wire={"x6d23e9a13ecb403add6d5a4a":[]};const value=await send("/x60844813f82683cb84356f1e",wire,csrf);return value["x78db2ea1ed9c4fb11fe87fe7"];}
export async function xb059bba866ad0adab514a22f(data,csrf){const wire=[data["product_id"],data["request_id"],data["quantity"]];const value=await send("/x4844782d39731bd7ab5259bb",wire,csrf);return value["x7059c1e56264dfd2c2d8ba04"];}
export async function x14ac0987711bcf2cbb5b5b57(data,csrf){const wire=[];const value=await send("/x94c39f4baa9fc48a9a4e83f5",wire,csrf);return value["xc856dd2d28f70a53c3bc0bab"];}
