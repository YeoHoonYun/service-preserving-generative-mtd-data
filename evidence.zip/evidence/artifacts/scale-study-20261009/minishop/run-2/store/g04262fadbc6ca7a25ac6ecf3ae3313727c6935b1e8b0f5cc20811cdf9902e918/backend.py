# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x7294e4841c5e369d77bd9557', 'fields': ['username', 'password'], 'aliases': {'username': 'x69117dead4964468843ed2a7', 'password': 'x179058a7c7f05ee740ec638e'}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'xf4edebaf972db01b70594e8f', 'response_box': 'x7cc2e5024d9afc07531295d3', 'result_key': 'xa0fb2ca62d7719283775c86e'}, 'logout': {'route': '/x60844813f82683cb84356f1e', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'x6d23e9a13ecb403add6d5a4a', 'response_box': 'x74a70e73b932c4a2ef2e820c', 'result_key': 'x78db2ea1ed9c4fb11fe87fe7'}, 'catalog': {'route': '/xab6e9a227023847cf24bee05', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'x3b71e539fccab0420ddac023', 'response_box': 'xa49fd23b60aef844efdd8800', 'result_key': 'xb7265e4cea00a5594e64c504'}, 'create_order': {'route': '/x4844782d39731bd7ab5259bb', 'fields': ['product_id', 'request_id', 'quantity'], 'aliases': {'product_id': 'xed2c88ecefa1c308cba70ecf', 'request_id': 'x9a8e7c42f1b93f35fc4920e5', 'quantity': 'x4841e89f0cef79f237a80866'}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'x4f5a13737b12652b2b7a395b', 'response_box': 'xce72a86bfde015dc66c4eb2a', 'result_key': 'x7059c1e56264dfd2c2d8ba04'}, 'order': {'route': '/xe622dbd88b68b604b469b453', 'fields': ['order_id'], 'aliases': {'order_id': 'xe92406cc2ecfe05e1c488624'}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'x97417764ba36c594b78199e5', 'response_box': 'x276f6d59243ff8d31238d3d0', 'result_key': 'x2c04afc47316ce9d8d39fc45'}, 'orders': {'route': '/x94c39f4baa9fc48a9a4e83f5', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'xac37dcf32134848b1bed6d35', 'response_box': 'x7288ebe741f7a1021629d758', 'result_key': 'xc856dd2d28f70a53c3bc0bab'}, 'update_product': {'route': '/x6e9e6eacbc4a29f6677bf6fa', 'fields': ['product_id', 'stock', 'price'], 'aliases': {'product_id': 'xc93d2b4fd735515600c44a2b', 'stock': 'x52f5618132050c026603b690', 'price': 'xb3e4ca9511c7959498c78c0f'}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x68324fc9409b9c781a472581', 'response_box': 'x909ae155ad5d1daa97baa408', 'result_key': 'xfaaa4d4ec7c455b8633de966'}}
HANDLERS = {'login': 'xf07791a536a6ceb776323e5c', 'logout': 'x5ef05e8db437bc185fdf4eae', 'catalog': 'x1e45ea6de011de745e3c2463', 'create_order': 'x6b7d337de1b3b983f8bb91ee', 'order': 'xd0cfdc964de1e4e85f1a28dd', 'orders': 'x5c46b647f3b5fa57346e7879', 'update_product': 'x03a7b261904ee6ed82f493b4'}
BACKEND_GRAPH = {'xf07791a536a6ceb776323e5c': {'operation': 'login', 'target': 'x6e48e8f825fa11868c38f636', 'kind': 'adapter'}, 'x6e48e8f825fa11868c38f636': {'operation': 'login', 'target': 'xd21912023a0911716e19b9f9', 'kind': 'adapter'}, 'xd21912023a0911716e19b9f9': {'operation': 'login', 'target': 'x6a6734f5942c23f518884fd0', 'kind': 'adapter'}, 'x6a6734f5942c23f518884fd0': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x5ef05e8db437bc185fdf4eae': {'operation': 'logout', 'target': 'x835f33ef976ec237606dd4fa', 'kind': 'adapter'}, 'x835f33ef976ec237606dd4fa': {'operation': 'logout', 'target': 'xdc85f1fae287dee5b49fda46', 'kind': 'adapter'}, 'xdc85f1fae287dee5b49fda46': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x1e45ea6de011de745e3c2463': {'operation': 'catalog', 'target': 'x6d3bb64152ad4ce6549939d9', 'kind': 'adapter'}, 'x6d3bb64152ad4ce6549939d9': {'operation': 'catalog', 'target': 'x600daa7af95f785ceeacbc04', 'kind': 'adapter'}, 'x600daa7af95f785ceeacbc04': {'operation': 'catalog', 'target': 'x4f6e8f9936c78537dbdc8bad', 'kind': 'adapter'}, 'x4f6e8f9936c78537dbdc8bad': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x6b7d337de1b3b983f8bb91ee': {'operation': 'create_order', 'target': 'x86b58ac0477adcdc984b462f', 'kind': 'adapter'}, 'x86b58ac0477adcdc984b462f': {'operation': 'create_order', 'target': 'x9a60309848350282ed40cad0', 'kind': 'adapter'}, 'x9a60309848350282ed40cad0': {'operation': 'create_order', 'target': 'x0477c653eefc8ee0fbcb980c', 'kind': 'adapter'}, 'x0477c653eefc8ee0fbcb980c': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'xd0cfdc964de1e4e85f1a28dd': {'operation': 'order', 'target': 'x8c081f7086073a24e0c79cb2', 'kind': 'adapter'}, 'x8c081f7086073a24e0c79cb2': {'operation': 'order', 'target': 'x3b1a86a5fde21d4edd70e03e', 'kind': 'adapter'}, 'x3b1a86a5fde21d4edd70e03e': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x5c46b647f3b5fa57346e7879': {'operation': 'orders', 'target': 'x3c7610c664ff7c962415c063', 'kind': 'adapter'}, 'x3c7610c664ff7c962415c063': {'operation': 'orders', 'target': 'x2d35cf14fdb9dd08d864a9c3', 'kind': 'adapter'}, 'x2d35cf14fdb9dd08d864a9c3': {'operation': 'orders', 'target': 'x6a51967c8923d3ee740f1b1e', 'kind': 'adapter'}, 'x6a51967c8923d3ee740f1b1e': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x03a7b261904ee6ed82f493b4': {'operation': 'update_product', 'target': 'x3f7ec7fb42270ac000edd2a3', 'kind': 'adapter'}, 'x3f7ec7fb42270ac000edd2a3': {'operation': 'update_product', 'target': 'x24efdc117735aabe7992e3da', 'kind': 'adapter'}, 'x24efdc117735aabe7992e3da': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xf07791a536a6ceb776323e5c(core, operation, data, session, actor, trace):
    trace.append('xf07791a536a6ceb776323e5c')
    return x6e48e8f825fa11868c38f636(core, operation, data, session, actor, trace)

def x6e48e8f825fa11868c38f636(core, operation, data, session, actor, trace):
    trace.append('x6e48e8f825fa11868c38f636')
    return xd21912023a0911716e19b9f9(core, operation, data, session, actor, trace)

def xd21912023a0911716e19b9f9(core, operation, data, session, actor, trace):
    trace.append('xd21912023a0911716e19b9f9')
    return x6a6734f5942c23f518884fd0(core, operation, data, session, actor, trace)

def x6a6734f5942c23f518884fd0(core, operation, data, session, actor, trace):
    trace.append('x6a6734f5942c23f518884fd0')
    return core.execute(operation, data, session, actor)

def x5ef05e8db437bc185fdf4eae(core, operation, data, session, actor, trace):
    trace.append('x5ef05e8db437bc185fdf4eae')
    return x835f33ef976ec237606dd4fa(core, operation, data, session, actor, trace)

def x835f33ef976ec237606dd4fa(core, operation, data, session, actor, trace):
    trace.append('x835f33ef976ec237606dd4fa')
    return xdc85f1fae287dee5b49fda46(core, operation, data, session, actor, trace)

def xdc85f1fae287dee5b49fda46(core, operation, data, session, actor, trace):
    trace.append('xdc85f1fae287dee5b49fda46')
    return core.execute(operation, data, session, actor)

def x1e45ea6de011de745e3c2463(core, operation, data, session, actor, trace):
    trace.append('x1e45ea6de011de745e3c2463')
    return x6d3bb64152ad4ce6549939d9(core, operation, data, session, actor, trace)

def x6d3bb64152ad4ce6549939d9(core, operation, data, session, actor, trace):
    trace.append('x6d3bb64152ad4ce6549939d9')
    return x600daa7af95f785ceeacbc04(core, operation, data, session, actor, trace)

def x600daa7af95f785ceeacbc04(core, operation, data, session, actor, trace):
    trace.append('x600daa7af95f785ceeacbc04')
    return x4f6e8f9936c78537dbdc8bad(core, operation, data, session, actor, trace)

def x4f6e8f9936c78537dbdc8bad(core, operation, data, session, actor, trace):
    trace.append('x4f6e8f9936c78537dbdc8bad')
    return core.execute(operation, data, session, actor)

def x6b7d337de1b3b983f8bb91ee(core, operation, data, session, actor, trace):
    trace.append('x6b7d337de1b3b983f8bb91ee')
    return x86b58ac0477adcdc984b462f(core, operation, data, session, actor, trace)

def x86b58ac0477adcdc984b462f(core, operation, data, session, actor, trace):
    trace.append('x86b58ac0477adcdc984b462f')
    return x9a60309848350282ed40cad0(core, operation, data, session, actor, trace)

def x9a60309848350282ed40cad0(core, operation, data, session, actor, trace):
    trace.append('x9a60309848350282ed40cad0')
    return x0477c653eefc8ee0fbcb980c(core, operation, data, session, actor, trace)

def x0477c653eefc8ee0fbcb980c(core, operation, data, session, actor, trace):
    trace.append('x0477c653eefc8ee0fbcb980c')
    return core.execute(operation, data, session, actor)

def xd0cfdc964de1e4e85f1a28dd(core, operation, data, session, actor, trace):
    trace.append('xd0cfdc964de1e4e85f1a28dd')
    return x8c081f7086073a24e0c79cb2(core, operation, data, session, actor, trace)

def x8c081f7086073a24e0c79cb2(core, operation, data, session, actor, trace):
    trace.append('x8c081f7086073a24e0c79cb2')
    return x3b1a86a5fde21d4edd70e03e(core, operation, data, session, actor, trace)

def x3b1a86a5fde21d4edd70e03e(core, operation, data, session, actor, trace):
    trace.append('x3b1a86a5fde21d4edd70e03e')
    return core.execute(operation, data, session, actor)

def x5c46b647f3b5fa57346e7879(core, operation, data, session, actor, trace):
    trace.append('x5c46b647f3b5fa57346e7879')
    return x3c7610c664ff7c962415c063(core, operation, data, session, actor, trace)

def x3c7610c664ff7c962415c063(core, operation, data, session, actor, trace):
    trace.append('x3c7610c664ff7c962415c063')
    return x2d35cf14fdb9dd08d864a9c3(core, operation, data, session, actor, trace)

def x2d35cf14fdb9dd08d864a9c3(core, operation, data, session, actor, trace):
    trace.append('x2d35cf14fdb9dd08d864a9c3')
    return x6a51967c8923d3ee740f1b1e(core, operation, data, session, actor, trace)

def x6a51967c8923d3ee740f1b1e(core, operation, data, session, actor, trace):
    trace.append('x6a51967c8923d3ee740f1b1e')
    return core.execute(operation, data, session, actor)

def x03a7b261904ee6ed82f493b4(core, operation, data, session, actor, trace):
    trace.append('x03a7b261904ee6ed82f493b4')
    return x3f7ec7fb42270ac000edd2a3(core, operation, data, session, actor, trace)

def x3f7ec7fb42270ac000edd2a3(core, operation, data, session, actor, trace):
    trace.append('x3f7ec7fb42270ac000edd2a3')
    return x24efdc117735aabe7992e3da(core, operation, data, session, actor, trace)

def x24efdc117735aabe7992e3da(core, operation, data, session, actor, trace):
    trace.append('x24efdc117735aabe7992e3da')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

ADAPTER_ENTRIES = {
    'xf07791a536a6ceb776323e5c': xf07791a536a6ceb776323e5c,
    'x5ef05e8db437bc185fdf4eae': x5ef05e8db437bc185fdf4eae,
    'x1e45ea6de011de745e3c2463': x1e45ea6de011de745e3c2463,
    'x6b7d337de1b3b983f8bb91ee': x6b7d337de1b3b983f8bb91ee,
    'xd0cfdc964de1e4e85f1a28dd': xd0cfdc964de1e4e85f1a28dd,
    'x5c46b647f3b5fa57346e7879': x5c46b647f3b5fa57346e7879,
    'x03a7b261904ee6ed82f493b4': x03a7b261904ee6ed82f493b4
}

def select_adapter(handler_name, operation):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    return ADAPTER_ENTRIES[handler_name]

def dispatch_adapter(adapter, core, operation, data, session, actor):
    trace = []
    status, result, cookie = adapter(core, operation, data, session, actor, trace)
    return status, result, cookie, trace

def invoke(handler_name, core, operation, data, session, actor):
    adapter = select_adapter(handler_name, operation)
    return dispatch_adapter(adapter, core, operation, data, session, actor)

