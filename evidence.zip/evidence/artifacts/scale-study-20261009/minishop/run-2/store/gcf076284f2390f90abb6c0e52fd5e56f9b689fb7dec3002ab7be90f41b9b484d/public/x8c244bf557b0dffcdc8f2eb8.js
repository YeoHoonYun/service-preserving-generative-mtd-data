import {x120b43708a81d13c45d4d092,xe362e7304f7fb8e83b29a7c1,x8b070e1584bfeb286f092158,x5b961b0ff3af2d3f00c0dc71} from './x5ac47fc24ca64adf1d16d25c.js';
import {x71f8f7262c75ef8e8eaf4fc7,x29295fe968859016e8937154,x5f3274b023c9e6af9d301e13} from './x0e5dbb1e49fb7ac4ba85d6bd.js';

let boot = JSON.parse(document.querySelector('meta[name=boot]').content);
const message = document.getElementById('x7d3cd5d06ae2a8b99b0de9ae');
const endpoints = {
  login: x120b43708a81d13c45d4d092,
  logout: x71f8f7262c75ef8e8eaf4fc7,
  catalog: xe362e7304f7fb8e83b29a7c1,
  create_order: x29295fe968859016e8937154,
  order: x8b070e1584bfeb286f092158,
  orders: x5f3274b023c9e6af9d301e13,
  update_product: x5b961b0ff3af2d3f00c0dc71
};
async function api(operation, data = {}) {
  return endpoints[operation](data, boot.csrf);
}
function identity() {
  document.getElementById('x5ac8b036aa4c60ed4e234b92').textContent = boot.user ? boot.user.id : '방문자';
}
function run(promise) {
  promise.catch(error => message.textContent = error.message);
}
async function catalog() {
  const list = document.getElementById('x3b6a7ce0e7cefb344ccce08a');
  list.replaceChildren();
  for (const p of await api('catalog')) {
    const li = document.createElement('li');
    li.textContent = p.id + ' · ' + p.name + ' · ' + p.price + '원 · 재고 ' + p.stock;
    list.append(li);
  }
  document.body.dataset.ready = 'yes';
}
async function orders() {
  const list = document.getElementById('x06244857dc76a04361c1b5d9');
  list.replaceChildren();
  for (const order of await api('orders')) {
    const li = document.createElement('li');
    li.textContent = order.id + ' · ' + order.total + '원';
    list.append(li);
  }
}

async function transition(state, context) {
  while (state !== 'done') {
    switch (state) {
      case 'form': {
        const raw = Object.fromEntries(new FormData(context.form));
        context.data = {
          username: raw['x499879dae7d3f60e62ebd5f8'],
          password: raw['x7881c115e4d025eee16729ca'],
          product_id: raw['x6022c877793f70c06a9fd6d5'],
          quantity: raw['x543a5f5eb851ccd7a7dbed09'],
          price: raw['x1e67c74c98a9337bb98c3068'],
          stock: raw['xa9c26c8a87ed04e4de7ec820']
        };
        state = 'login';
        break;
      }
      case 'login':
        if (context.form.dataset.action === 'xcce1162c80ca29e0face6ba4') {
          boot = await api('login', context.data);
          identity();
          message.textContent = '로그인되었습니다.';
        }
        state = 'purchase';
        break;
      case 'purchase':
        if (context.form.dataset.action === 'x5caf014dcbc180f0b1a65761') {
          const order = await api('create_order', {
            product_id: context.data.product_id,
            quantity: Number(context.data.quantity),
            request_id: crypto.randomUUID()
          });
          message.textContent = '주문 ' + order.id + ' · ' + order.total + '원';
          state = 'purchaseCatalog';
        } else {
          state = 'edit';
        }
        break;
      case 'purchaseCatalog':
        await catalog();
        state = 'purchaseOrders';
        break;
      case 'purchaseOrders':
        await orders();
        state = 'edit';
        break;
      case 'edit':
        if (context.form.dataset.action === 'x8ff4f79427532d3a2d6c475e') {
          await api('update_product', {
            product_id: 'p1',
            price: Number(context.data.price),
            stock: Number(context.data.stock)
          });
          message.textContent = '상품을 수정했습니다.';
          state = 'catalog';
        } else {
          state = 'done';
        }
        break;
      case 'catalog':
        await catalog();
        state = 'done';
        break;
      case 'orders':
        await orders();
        state = 'done';
        break;
      case 'logout':
        await api('logout');
        location.reload();
        state = 'done';
        break;
    }
  }
}

document.addEventListener('submit', event => {
  event.preventDefault();
  run(transition('form', {form: event.target}));
});
document.getElementById('x2e4309b758cc136ad4806bc8').onclick = () => run(transition('logout', {}));
document.getElementById('x8f0367811bd6d022235a5b92').onclick = () => run(transition('orders', {}));
identity();
run(transition('catalog', {}));
