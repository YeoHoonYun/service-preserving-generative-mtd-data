import {send} from './x8299b60116cbfb40c31fa5f4.js';
export async function x120b43708a81d13c45d4d092(data,csrf){const wire=[data["username"],data["password"]];const value=await send("/x7576325d0c6d49129ae857ec",wire,csrf);return value["xfc4b749efabeb85224afe237"];}
export async function xe362e7304f7fb8e83b29a7c1(data,csrf){const wire={};const value=await send("/x54b4b24135b746c1e5de2639",wire,csrf);return value[0];}
export async function x8b070e1584bfeb286f092158(data,csrf){const wire={"xb72c786cbd20c3e6752f1bd6":data["order_id"]};const value=await send("/xfe12ab96fceb19d89fd886fb",wire,csrf);return value["xb7abf40960f05c5b06148d74"];}
export async function x5b961b0ff3af2d3f00c0dc71(data,csrf){const wire={"x4f5a7fe5410298fa42a758ba":{"x0eb18288fe18ea0415b32f3a":data["product_id"],"xded531abb99a24848b8e4578":data["price"],"x157b0002bc541ba886978385":data["stock"]}};const value=await send("/x117f5eff0e9cefc985e44a75",wire,csrf);return value[0];}
