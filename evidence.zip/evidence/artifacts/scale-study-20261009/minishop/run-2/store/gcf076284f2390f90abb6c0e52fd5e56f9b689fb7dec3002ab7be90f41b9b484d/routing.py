GRAPH = {'xa2334dd002a96ade1755fe62': {'kind': 'router', 'edges': {'/x7576325d0c6d49129ae857ec': {'target': 'x3cb45f7d2a8a7aa5921ec64a', 'next_key': 'x3a94f532f2b4b58e4287fffd'}, '/xaaee54d32f2f344aeb0f28fd': {'target': 'xfac6c70c184016114ce2f56d', 'next_key': 'x1be607873e03481597f2fb61'}, '/x54b4b24135b746c1e5de2639': {'target': 'x3cb45f7d2a8a7aa5921ec64a', 'next_key': 'x2e15e86e8a9ecb7cbb96b162'}, '/x173a793990baea3d299e9020': {'target': 'xfac6c70c184016114ce2f56d', 'next_key': 'xba98791647409f9823c2647c'}, '/xfe12ab96fceb19d89fd886fb': {'target': 'x3cb45f7d2a8a7aa5921ec64a', 'next_key': 'x4109c0320591011c76e2ca89'}, '/x901fe7fc4219a5e8e12f71e2': {'target': 'xfac6c70c184016114ce2f56d', 'next_key': 'x42020fc4da112844f4b6cc06'}, '/x117f5eff0e9cefc985e44a75': {'target': 'x3cb45f7d2a8a7aa5921ec64a', 'next_key': 'xbdb41835cf92646bc30dcae4'}}}, 'xfac6c70c184016114ce2f56d': {'kind': 'router', 'edges': {'x1be607873e03481597f2fb61': {'target': 'xd4407da7bf339df4b786e0c0', 'next_key': 'xb06b94f1e678bbb0a107b1b7'}, 'xba98791647409f9823c2647c': {'target': 'xd4407da7bf339df4b786e0c0', 'next_key': 'xc67a2be7467a6c2c76c6467c'}, 'x42020fc4da112844f4b6cc06': {'target': 'xd4407da7bf339df4b786e0c0', 'next_key': 'x9e7f7c5e80222f3d0734782d'}}}, 'x3cb45f7d2a8a7aa5921ec64a': {'kind': 'router', 'edges': {'x3a94f532f2b4b58e4287fffd': {'target': 'x1c08e9ab094a0cce2bc02da9', 'next_key': 'x2c4b8e44257a2c30274620b3'}, 'x2e15e86e8a9ecb7cbb96b162': {'target': 'x1c08e9ab094a0cce2bc02da9', 'next_key': 'x25a15c0535893247af2260fe'}, 'x4109c0320591011c76e2ca89': {'target': 'x1c08e9ab094a0cce2bc02da9', 'next_key': 'xa0fc7139d78ac9d4d2fc7f71'}, 'xbdb41835cf92646bc30dcae4': {'target': 'x1c08e9ab094a0cce2bc02da9', 'next_key': 'x6733f47d1cd220e3db7a90fb'}}}, 'x1c08e9ab094a0cce2bc02da9': {'kind': 'router', 'edges': {'x2c4b8e44257a2c30274620b3': {'target': 'x450e38d24b9818435fb5bfc5', 'next_key': None}, 'x25a15c0535893247af2260fe': {'target': 'x5fe6da8744e9cd370d1490a5', 'next_key': None}, 'xa0fc7139d78ac9d4d2fc7f71': {'target': 'x522d544289a8516959957a6b', 'next_key': None}, 'x6733f47d1cd220e3db7a90fb': {'target': 'x0b7040b0d07b7ffa12dbee25', 'next_key': None}}}, 'xd4407da7bf339df4b786e0c0': {'kind': 'router', 'edges': {'xb06b94f1e678bbb0a107b1b7': {'target': 'x346549ba3d3cfb9d73241d91', 'next_key': None}, 'xc67a2be7467a6c2c76c6467c': {'target': 'x86ece5af498a183ca0d9d628', 'next_key': None}, 'x9e7f7c5e80222f3d0734782d': {'target': 'xf0ef684bb5ab68a80944f3fa', 'next_key': None}}}, 'x450e38d24b9818435fb5bfc5': {'kind': 'service', 'operation': 'login', 'handler': 'x630e4d3bc47d92088de80052'}, 'x346549ba3d3cfb9d73241d91': {'kind': 'service', 'operation': 'logout', 'handler': 'x29c13d0ffd0710dc4017d8d8'}, 'x5fe6da8744e9cd370d1490a5': {'kind': 'service', 'operation': 'catalog', 'handler': 'x6224f90e5ef307fd0b1a51a3'}, 'x86ece5af498a183ca0d9d628': {'kind': 'service', 'operation': 'create_order', 'handler': 'xeb20bc82d2418400891af74c'}, 'x522d544289a8516959957a6b': {'kind': 'service', 'operation': 'order', 'handler': 'xc6d62e361842718ee93d03ac'}, 'xf0ef684bb5ab68a80944f3fa': {'kind': 'service', 'operation': 'orders', 'handler': 'x68c9fc6a8eea6e0c2e6fd4c2'}, 'x0b7040b0d07b7ffa12dbee25': {'kind': 'service', 'operation': 'update_product', 'handler': 'xb5f8af5bd0b312add6e5676e'}}
ENTRY = 'xa2334dd002a96ade1755fe62'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    bindings = []
    for path, first in graph[entry]['edges'].items():
        node, key = first['target'], first['next_key']
        seen = {entry}
        while True:
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            item = graph[node]
            if item['kind'] == 'service':
                bindings.append((path, node))
                break
            edge = item['edges'][key]
            node, key = edge['target'], edge['next_key']
    root = 'mesh.entry'
    rebuilt = {root: {'kind': 'router', 'edges': {}}}
    leaves = {}
    for index, binding in enumerate(bindings):
        path, old_leaf = binding
        block = 'mesh.block.' + str(index // 3)
        lane = 'mesh.lane.' + str(index % 3)
        if old_leaf not in leaves:
            leaf = 'mesh.service.' + str(len(leaves))
            leaves[old_leaf] = leaf
            rebuilt[leaf] = dict(graph[old_leaf])
        leaf = leaves[old_leaf]
        for router in (block, lane):
            if router not in rebuilt:
                rebuilt[router] = {'kind': 'router', 'edges': {}}
        rebuilt[root]['edges'][path] = {'target': block, 'next_key': path}
        rebuilt[block]['edges'][path] = {'target': lane, 'next_key': leaf}
        rebuilt[lane]['edges'][leaf] = {'target': leaf, 'next_key': None}
    return rebuilt, root

def resolve(path):
    node, key = ENTRY, path
    visited, trace = set(), []
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
