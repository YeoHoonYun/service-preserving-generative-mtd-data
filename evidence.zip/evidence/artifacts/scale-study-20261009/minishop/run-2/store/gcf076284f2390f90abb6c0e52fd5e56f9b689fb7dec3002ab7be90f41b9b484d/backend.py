# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x7576325d0c6d49129ae857ec', 'fields': ['username', 'password'], 'aliases': {'username': 'xdbaf432d4166f47bea4a1834', 'password': 'x9b0e52d4c60b7cd8d0122c7b'}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'x5b5e3dee0a3c221a9e580429', 'response_box': 'x1b48e053e58140ae57e72c40', 'result_key': 'xfc4b749efabeb85224afe237'}, 'logout': {'route': '/xaaee54d32f2f344aeb0f28fd', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'xfe5d29a13831c30d55728533', 'response_box': 'xf93568dc44395539516d82a4', 'result_key': 'x1373ff3a63c6c51f7d3f7d07'}, 'catalog': {'route': '/x54b4b24135b746c1e5de2639', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'xa9bdb066ab7a3715a3c85ff3', 'response_box': 'x3d6725ebd47aeea3181aa32d', 'result_key': 'xa19a04c635debf43f25cb41e'}, 'create_order': {'route': '/x173a793990baea3d299e9020', 'fields': ['product_id', 'quantity', 'request_id'], 'aliases': {'product_id': 'x9f1a5d056e4f7b0c459b0e61', 'quantity': 'x0162ebd3555a836344a1d350', 'request_id': 'xb2c83c354fa7f7eb97af0481'}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'xf6c6fe6b328103a07a79b03d', 'response_box': 'x9ca6460d0d597ed53d200308', 'result_key': 'x7755d46918d6b531caff6023'}, 'order': {'route': '/xfe12ab96fceb19d89fd886fb', 'fields': ['order_id'], 'aliases': {'order_id': 'xb72c786cbd20c3e6752f1bd6'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x146b84a2808958411d01bba7', 'response_box': 'x7448bdb4eae2430c52c5f371', 'result_key': 'xb7abf40960f05c5b06148d74'}, 'orders': {'route': '/x901fe7fc4219a5e8e12f71e2', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'x2ca2b4812f6776582ff1bcd5', 'response_box': 'x0072aeb960fbca15db7feff0', 'result_key': 'xb549c1b43b06f2ae7fc87d83'}, 'update_product': {'route': '/x117f5eff0e9cefc985e44a75', 'fields': ['product_id', 'price', 'stock'], 'aliases': {'product_id': 'x0eb18288fe18ea0415b32f3a', 'price': 'xded531abb99a24848b8e4578', 'stock': 'x157b0002bc541ba886978385'}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x4f5a7fe5410298fa42a758ba', 'response_box': 'x9aff2899458e8cc33f007670', 'result_key': 'x3be3d8312174901af3266878'}}
HANDLERS = {'login': 'x630e4d3bc47d92088de80052', 'logout': 'x29c13d0ffd0710dc4017d8d8', 'catalog': 'x6224f90e5ef307fd0b1a51a3', 'create_order': 'xeb20bc82d2418400891af74c', 'order': 'xc6d62e361842718ee93d03ac', 'orders': 'x68c9fc6a8eea6e0c2e6fd4c2', 'update_product': 'xb5f8af5bd0b312add6e5676e'}
BACKEND_GRAPH = {'x630e4d3bc47d92088de80052': {'operation': 'login', 'target': 'x5ce77f2ec14fcec86c2381f1', 'kind': 'adapter'}, 'x5ce77f2ec14fcec86c2381f1': {'operation': 'login', 'target': 'x0a72a207443f2f6cc4aa29e9', 'kind': 'adapter'}, 'x0a72a207443f2f6cc4aa29e9': {'operation': 'login', 'target': 'xbecd9980bd91e3265d22fd58', 'kind': 'adapter'}, 'xbecd9980bd91e3265d22fd58': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x29c13d0ffd0710dc4017d8d8': {'operation': 'logout', 'target': 'x63e1ec6f258c6ad11a21193c', 'kind': 'adapter'}, 'x63e1ec6f258c6ad11a21193c': {'operation': 'logout', 'target': 'xe062d872bd5df53257fac2b3', 'kind': 'adapter'}, 'xe062d872bd5df53257fac2b3': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x6224f90e5ef307fd0b1a51a3': {'operation': 'catalog', 'target': 'xb9d4713214cd1879783c87a2', 'kind': 'adapter'}, 'xb9d4713214cd1879783c87a2': {'operation': 'catalog', 'target': 'xeb46149e5c9d5ad036a35d4c', 'kind': 'adapter'}, 'xeb46149e5c9d5ad036a35d4c': {'operation': 'catalog', 'target': 'x844a4258e46fb7a7a93b8491', 'kind': 'adapter'}, 'x844a4258e46fb7a7a93b8491': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'xeb20bc82d2418400891af74c': {'operation': 'create_order', 'target': 'x27bc97d2209bccccb04f157f', 'kind': 'adapter'}, 'x27bc97d2209bccccb04f157f': {'operation': 'create_order', 'target': 'xa29543a751c1fb2af2615ebe', 'kind': 'adapter'}, 'xa29543a751c1fb2af2615ebe': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'xc6d62e361842718ee93d03ac': {'operation': 'order', 'target': 'xfcfa1cccb488e584acde41c2', 'kind': 'adapter'}, 'xfcfa1cccb488e584acde41c2': {'operation': 'order', 'target': 'x49728e6fa1f3e962f0b7efe1', 'kind': 'adapter'}, 'x49728e6fa1f3e962f0b7efe1': {'operation': 'order', 'target': 'x5a7e15cd233e782dc3825d77', 'kind': 'adapter'}, 'x5a7e15cd233e782dc3825d77': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x68c9fc6a8eea6e0c2e6fd4c2': {'operation': 'orders', 'target': 'xe9b99a80705825bbb3d3f5b7', 'kind': 'adapter'}, 'xe9b99a80705825bbb3d3f5b7': {'operation': 'orders', 'target': 'x0d696a0a0c4009cfefc7c2ba', 'kind': 'adapter'}, 'x0d696a0a0c4009cfefc7c2ba': {'operation': 'orders', 'target': 'xe3845c9f2f58c872ae3c20f1', 'kind': 'adapter'}, 'xe3845c9f2f58c872ae3c20f1': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'xb5f8af5bd0b312add6e5676e': {'operation': 'update_product', 'target': 'xc7679b434fd2cc4eaa0eb149', 'kind': 'adapter'}, 'xc7679b434fd2cc4eaa0eb149': {'operation': 'update_product', 'target': 'x19936bbe887ef30a7b58e52f', 'kind': 'adapter'}, 'x19936bbe887ef30a7b58e52f': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def x630e4d3bc47d92088de80052(core, operation, data, session, actor, trace):
    trace.append('x630e4d3bc47d92088de80052')
    return x5ce77f2ec14fcec86c2381f1(core, operation, data, session, actor, trace)

def x5ce77f2ec14fcec86c2381f1(core, operation, data, session, actor, trace):
    trace.append('x5ce77f2ec14fcec86c2381f1')
    return x0a72a207443f2f6cc4aa29e9(core, operation, data, session, actor, trace)

def x0a72a207443f2f6cc4aa29e9(core, operation, data, session, actor, trace):
    trace.append('x0a72a207443f2f6cc4aa29e9')
    return xbecd9980bd91e3265d22fd58(core, operation, data, session, actor, trace)

def xbecd9980bd91e3265d22fd58(core, operation, data, session, actor, trace):
    trace.append('xbecd9980bd91e3265d22fd58')
    return core.execute(operation, data, session, actor)

def x29c13d0ffd0710dc4017d8d8(core, operation, data, session, actor, trace):
    trace.append('x29c13d0ffd0710dc4017d8d8')
    return x63e1ec6f258c6ad11a21193c(core, operation, data, session, actor, trace)

def x63e1ec6f258c6ad11a21193c(core, operation, data, session, actor, trace):
    trace.append('x63e1ec6f258c6ad11a21193c')
    return xe062d872bd5df53257fac2b3(core, operation, data, session, actor, trace)

def xe062d872bd5df53257fac2b3(core, operation, data, session, actor, trace):
    trace.append('xe062d872bd5df53257fac2b3')
    return core.execute(operation, data, session, actor)

def x6224f90e5ef307fd0b1a51a3(core, operation, data, session, actor, trace):
    trace.append('x6224f90e5ef307fd0b1a51a3')
    return xb9d4713214cd1879783c87a2(core, operation, data, session, actor, trace)

def xb9d4713214cd1879783c87a2(core, operation, data, session, actor, trace):
    trace.append('xb9d4713214cd1879783c87a2')
    return xeb46149e5c9d5ad036a35d4c(core, operation, data, session, actor, trace)

def xeb46149e5c9d5ad036a35d4c(core, operation, data, session, actor, trace):
    trace.append('xeb46149e5c9d5ad036a35d4c')
    return x844a4258e46fb7a7a93b8491(core, operation, data, session, actor, trace)

def x844a4258e46fb7a7a93b8491(core, operation, data, session, actor, trace):
    trace.append('x844a4258e46fb7a7a93b8491')
    return core.execute(operation, data, session, actor)

def xeb20bc82d2418400891af74c(core, operation, data, session, actor, trace):
    trace.append('xeb20bc82d2418400891af74c')
    return x27bc97d2209bccccb04f157f(core, operation, data, session, actor, trace)

def x27bc97d2209bccccb04f157f(core, operation, data, session, actor, trace):
    trace.append('x27bc97d2209bccccb04f157f')
    return xa29543a751c1fb2af2615ebe(core, operation, data, session, actor, trace)

def xa29543a751c1fb2af2615ebe(core, operation, data, session, actor, trace):
    trace.append('xa29543a751c1fb2af2615ebe')
    return core.execute(operation, data, session, actor)

def xc6d62e361842718ee93d03ac(core, operation, data, session, actor, trace):
    trace.append('xc6d62e361842718ee93d03ac')
    return xfcfa1cccb488e584acde41c2(core, operation, data, session, actor, trace)

def xfcfa1cccb488e584acde41c2(core, operation, data, session, actor, trace):
    trace.append('xfcfa1cccb488e584acde41c2')
    return x49728e6fa1f3e962f0b7efe1(core, operation, data, session, actor, trace)

def x49728e6fa1f3e962f0b7efe1(core, operation, data, session, actor, trace):
    trace.append('x49728e6fa1f3e962f0b7efe1')
    return x5a7e15cd233e782dc3825d77(core, operation, data, session, actor, trace)

def x5a7e15cd233e782dc3825d77(core, operation, data, session, actor, trace):
    trace.append('x5a7e15cd233e782dc3825d77')
    return core.execute(operation, data, session, actor)

def x68c9fc6a8eea6e0c2e6fd4c2(core, operation, data, session, actor, trace):
    trace.append('x68c9fc6a8eea6e0c2e6fd4c2')
    return xe9b99a80705825bbb3d3f5b7(core, operation, data, session, actor, trace)

def xe9b99a80705825bbb3d3f5b7(core, operation, data, session, actor, trace):
    trace.append('xe9b99a80705825bbb3d3f5b7')
    return x0d696a0a0c4009cfefc7c2ba(core, operation, data, session, actor, trace)

def x0d696a0a0c4009cfefc7c2ba(core, operation, data, session, actor, trace):
    trace.append('x0d696a0a0c4009cfefc7c2ba')
    return xe3845c9f2f58c872ae3c20f1(core, operation, data, session, actor, trace)

def xe3845c9f2f58c872ae3c20f1(core, operation, data, session, actor, trace):
    trace.append('xe3845c9f2f58c872ae3c20f1')
    return core.execute(operation, data, session, actor)

def xb5f8af5bd0b312add6e5676e(core, operation, data, session, actor, trace):
    trace.append('xb5f8af5bd0b312add6e5676e')
    return xc7679b434fd2cc4eaa0eb149(core, operation, data, session, actor, trace)

def xc7679b434fd2cc4eaa0eb149(core, operation, data, session, actor, trace):
    trace.append('xc7679b434fd2cc4eaa0eb149')
    return x19936bbe887ef30a7b58e52f(core, operation, data, session, actor, trace)

def x19936bbe887ef30a7b58e52f(core, operation, data, session, actor, trace):
    trace.append('x19936bbe887ef30a7b58e52f')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

ADAPTER_INDEX = (
    ('catalog', x6224f90e5ef307fd0b1a51a3),
    ('create_order', xeb20bc82d2418400891af74c),
    ('login', x630e4d3bc47d92088de80052),
    ('logout', x29c13d0ffd0710dc4017d8d8),
    ('order', xc6d62e361842718ee93d03ac),
    ('orders', x68c9fc6a8eea6e0c2e6fd4c2),
    ('update_product', xb5f8af5bd0b312add6e5676e),
)

def dispatch_interval(low, high, handler_name, core, operation, data, session, actor):
    if low >= high:
        raise KeyError(handler_name)
    middle = (low + high) // 2
    name, adapter = ADAPTER_INDEX[middle]
    if operation == name:
        trace = []
        status, result, cookie = adapter(core, operation, data, session, actor, trace)
        return status, result, cookie, trace
    if operation < name:
        return dispatch_interval(low, middle, handler_name, core, operation, data, session, actor)
    return dispatch_interval(middle + 1, high, handler_name, core, operation, data, session, actor)

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    if operation not in HANDLERS:
        raise KeyError(handler_name)
    return dispatch_interval(0, len(ADAPTER_INDEX), handler_name, core, operation, data, session, actor)

def unpack_request(contract, wire):
    shape = contract['request_shape']
    if shape in ('wrapped', 'pairs'):
        box = contract['request_box']
        if not isinstance(wire, dict) or len(wire) != 1 or box not in wire:
            raise ValueError('box')
        wire = wire[box]
    if shape == 'pairs':
        if not isinstance(wire, list):
            raise ValueError('pairs')
        collected = {}
        for pair in wire:
            if not isinstance(pair, list) or len(pair) != 2:
                raise ValueError('pair')
            alias, value = pair
            if not isinstance(alias, str) or alias in collected:
                raise ValueError('pair')
            collected[alias] = value
        return collected
    return wire

def consume_fields(contract, wire):
    if not isinstance(wire, dict):
        raise ValueError('fields')
    pending, result = dict(wire), {}
    for field in contract['fields']:
        alias = contract['aliases'][field]
        if alias not in pending:
            raise ValueError('fields')
        result[field] = pending.pop(alias)
    if pending:
        raise ValueError('fields')
    return result

def decode(operation, wire):
    contract = CONTRACT[operation]
    payload = unpack_request(contract, wire)
    if contract['request_shape'] == 'positional':
        if not isinstance(payload, list) or len(payload) != len(contract['fields']):
            raise ValueError('arity')
        return dict(zip(contract['fields'], payload))
    return consume_fields(contract, payload)

