import {send} from './x8a6d52fc40788cfaab661a08.js';
export async function x3c8c342086ef5b6afb1a306f(data,csrf){const wire={};const value=await send("/xcd938d1d363c2aec41d4d90b",wire,csrf);return value["xc9e0e7b1d72dbddc013dc9df"];}
export async function xa3d8229234b0e04d2aa7c3d0(data,csrf){const wire=[];const value=await send("/x7263736fa0e4e5ef8db1ea8f",wire,csrf);return value["x502ddc3103d2478f4e80280a"];}
