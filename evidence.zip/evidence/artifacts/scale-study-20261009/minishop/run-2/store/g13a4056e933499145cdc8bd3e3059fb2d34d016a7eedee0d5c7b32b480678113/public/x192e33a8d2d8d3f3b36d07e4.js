import {send} from './x8a6d52fc40788cfaab661a08.js';
export async function x0b88a74c6050173a65681d2a(data,csrf){const wire={"xa0e6cec885843ac60a176236":data["product_id"],"x5075d506dc33fe9006da2fb6":data["request_id"],"xf754a9741f8374eb82b987cd":data["quantity"]};const value=await send("/x5add64d5b64359d4bcf7e24e",wire,csrf);return value["x86e050546e0b18febd94b586"];}
