import {xb3b45184a6226acce3c7abb4,x512f4d866ac3588eda56d36c} from './x0bedbb3ba2bd54c397e2ab30.js';
import {x3c8c342086ef5b6afb1a306f,xa3d8229234b0e04d2aa7c3d0} from './x0dfac634869d75f5f7c7cb2b.js';
import {x4487f55ea7b03c4c12c1941e,xcea6039e0925a893d8449b4d} from './x8cee8ea23767eb0ffd00c8ef.js';
import {x0b88a74c6050173a65681d2a} from './x192e33a8d2d8d3f3b36d07e4.js';

const endpoints={login:xb3b45184a6226acce3c7abb4,logout:x3c8c342086ef5b6afb1a306f,catalog:x4487f55ea7b03c4c12c1941e,create_order:x0b88a74c6050173a65681d2a,order:x512f4d866ac3588eda56d36c,orders:xa3d8229234b0e04d2aa7c3d0,update_product:xcea6039e0925a893d8449b4d};

class ShopController {
  constructor(){
    this.boot=JSON.parse(document.querySelector('meta[name=boot]').content);
    this.message=document.getElementById('x46d8f8caab27ec7fc6ff3f14');
  }
  async api(operation,data={}){
    return endpoints[operation](data,this.boot.csrf);
  }
  identity(){
    document.getElementById('x710817a0044c8b304cadfc14').textContent=this.boot.user?this.boot.user.id:'방문자';
  }
  watch(promise){
    promise.catch(error=>this.message.textContent=error.message);
  }
  async catalog(){
    const list=document.getElementById('xbf74381c6dd3b3af93b7534c');
    list.replaceChildren();
    for(const product of await this.api('catalog')){
      const item=document.createElement('li');
      item.textContent=product.id+' · '+product.name+' · '+product.price+'원 · 재고 '+product.stock;
      list.append(item);
    }
    document.body.dataset.ready='yes';
  }
  async orders(){
    const list=document.getElementById('x71517a6a9e85b60dfb46087e');
    list.replaceChildren();
    for(const order of await this.api('orders')){
      const item=document.createElement('li');
      item.textContent=order.id+' · '+order.total+'원';
      list.append(item);
    }
  }
  readForm(form){
    const raw=Object.fromEntries(new FormData(form));
    return {username:raw['x0094814412f6cd1bb9fd859f'],password:raw['x42f2322b1ebba493edfb390b'],product_id:raw['x8603c9a2a6ec2aa0dc07b58a'],quantity:raw['x6bebacbe4a3c8f6983be6eb9'],price:raw['x9f900b648396f83dd2615aa9'],stock:raw['xa12de52a69f7eaa1ac5f57c6']};
  }
  async login(data){
    this.boot=await this.api('login',data);
    this.identity();
    this.message.textContent='로그인되었습니다.';
  }
  async purchase(data){
    const order=await this.api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()});
    this.message.textContent='주문 '+order.id+' · '+order.total+'원';
    await this.catalog();
    await this.orders();
  }
  async update(data){
    await this.api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)});
    this.message.textContent='상품을 수정했습니다.';
    await this.catalog();
  }
  async submit(form){
    const data=this.readForm(form);
    if(form.dataset.action==='xe5bd832db28d9a48a15a7d50') await this.login(data);
    if(form.dataset.action==='x1afc5f9df82c614e3e5c3a13') await this.purchase(data);
    if(form.dataset.action==='x5069c3e58dbb7c84a12c967f') await this.update(data);
  }
  start(){
    document.addEventListener('submit',event=>{
      event.preventDefault();
      this.watch(this.submit(event.target));
    });
    document.getElementById('x7aa21771c68b718a5d2d2b98').onclick=()=>this.watch(this.api('logout').then(()=>location.reload()));
    document.getElementById('x5ddd5c0f6fb8d90d20a8e090').onclick=()=>this.watch(this.orders());
    this.identity();
    this.watch(this.catalog());
  }
}
new ShopController().start();
