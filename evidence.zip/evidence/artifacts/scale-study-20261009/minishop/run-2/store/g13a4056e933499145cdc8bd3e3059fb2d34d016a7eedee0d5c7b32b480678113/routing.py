GRAPH = {'xafdd9b59a043903dffecb3df': {'kind': 'router', 'edges': {'/xb0f908566d894a71a65bdce7': {'target': 'x0474082a87fdf6153e952f39', 'next_key': 'xce57e1ea75162a479250653b'}, '/xcd938d1d363c2aec41d4d90b': {'target': 'xa63d73ca908375405fbd82a6', 'next_key': 'x372c4d8bec603e559f64814f'}, '/x8ec503eb21a3178b7e7a6132': {'target': 'x0474082a87fdf6153e952f39', 'next_key': 'x2fdba903f7cb9c776c4f8f2e'}, '/x5add64d5b64359d4bcf7e24e': {'target': 'xa63d73ca908375405fbd82a6', 'next_key': 'xea4f2d0a0db6fceda782a543'}, '/xfb67d37d579404660f523385': {'target': 'x0474082a87fdf6153e952f39', 'next_key': 'xae5b0c43a93ba7e09f8dcebe'}, '/x7263736fa0e4e5ef8db1ea8f': {'target': 'xa63d73ca908375405fbd82a6', 'next_key': 'x797bfabdb2b6f876d373682d'}, '/xe9711e924ccd2c181d1ca9a4': {'target': 'x0474082a87fdf6153e952f39', 'next_key': 'x6193d83513876a413edc0743'}}}, 'x0474082a87fdf6153e952f39': {'kind': 'router', 'edges': {'xce57e1ea75162a479250653b': {'target': 'xe5f4b0598288eb1b7fbd9d49', 'next_key': 'x261234d010ab0f2d82c68fc9'}, 'x2fdba903f7cb9c776c4f8f2e': {'target': 'xe5f4b0598288eb1b7fbd9d49', 'next_key': 'x8e9db696bcb158bfac2c20b5'}, 'xae5b0c43a93ba7e09f8dcebe': {'target': 'xe5f4b0598288eb1b7fbd9d49', 'next_key': 'xfb343fb4737fda264d9d87ff'}, 'x6193d83513876a413edc0743': {'target': 'xe5f4b0598288eb1b7fbd9d49', 'next_key': 'xddb97fae97791224abf64bc1'}}}, 'xa63d73ca908375405fbd82a6': {'kind': 'router', 'edges': {'x372c4d8bec603e559f64814f': {'target': 'xe168dd68ff4a91659d922442', 'next_key': 'x5a9a36a02e9c0a6706f26c8e'}, 'xea4f2d0a0db6fceda782a543': {'target': 'xe168dd68ff4a91659d922442', 'next_key': 'x368e6225529cfabd5568e8f2'}, 'x797bfabdb2b6f876d373682d': {'target': 'xe168dd68ff4a91659d922442', 'next_key': 'x5ed52710badd53f3764d804a'}}}, 'xe168dd68ff4a91659d922442': {'kind': 'router', 'edges': {'x5a9a36a02e9c0a6706f26c8e': {'target': 'x2e70fa1a7cd48afb716a55d6', 'next_key': 'x48d5cd7eec0c1e6dab3e3abc'}, 'x368e6225529cfabd5568e8f2': {'target': 'x2e70fa1a7cd48afb716a55d6', 'next_key': 'xd792d74400ddc45e1cb67c02'}, 'x5ed52710badd53f3764d804a': {'target': 'x2e70fa1a7cd48afb716a55d6', 'next_key': 'x33b8815f73386cccee01e3f3'}}}, 'xe5f4b0598288eb1b7fbd9d49': {'kind': 'router', 'edges': {'x261234d010ab0f2d82c68fc9': {'target': 'x2e70fa1a7cd48afb716a55d6', 'next_key': 'x509e87ccb7c11c343e1eac98'}, 'x8e9db696bcb158bfac2c20b5': {'target': 'x2e70fa1a7cd48afb716a55d6', 'next_key': 'xde3b1f9d74803415df335b30'}, 'xfb343fb4737fda264d9d87ff': {'target': 'x2e70fa1a7cd48afb716a55d6', 'next_key': 'xe8149333fe4fb044c1eb114d'}, 'xddb97fae97791224abf64bc1': {'target': 'x2e70fa1a7cd48afb716a55d6', 'next_key': 'x37f124d2a39dc590218221e5'}}}, 'x2e70fa1a7cd48afb716a55d6': {'kind': 'router', 'edges': {'x509e87ccb7c11c343e1eac98': {'target': 'xeb3abcb48f28cba2ebdca382', 'next_key': 'xa0beb45a0c0c90aa86855d52'}, 'x48d5cd7eec0c1e6dab3e3abc': {'target': 'xffe783111698f8ed585e83e6', 'next_key': 'xe0465ec898bbed6cf0d657c8'}, 'xde3b1f9d74803415df335b30': {'target': 'xeb3abcb48f28cba2ebdca382', 'next_key': 'x782bbea883b7618f8cb1750a'}, 'xd792d74400ddc45e1cb67c02': {'target': 'xffe783111698f8ed585e83e6', 'next_key': 'x8281379bab94519ceb359d5f'}, 'xe8149333fe4fb044c1eb114d': {'target': 'xeb3abcb48f28cba2ebdca382', 'next_key': 'x4b7925c18db241dbe0d90f6b'}, 'x33b8815f73386cccee01e3f3': {'target': 'xffe783111698f8ed585e83e6', 'next_key': 'xdd4c370ebb66d6a31c8ae00e'}, 'x37f124d2a39dc590218221e5': {'target': 'xeb3abcb48f28cba2ebdca382', 'next_key': 'x88126f62a5460231979da5cd'}}}, 'xffe783111698f8ed585e83e6': {'kind': 'router', 'edges': {'xe0465ec898bbed6cf0d657c8': {'target': 'xa39679d656e34f3625cabefe', 'next_key': None}, 'x8281379bab94519ceb359d5f': {'target': 'x6df6b388ee7603fd567290de', 'next_key': None}, 'xdd4c370ebb66d6a31c8ae00e': {'target': 'x2e7ae274bf2ef8b9d16435cf', 'next_key': None}}}, 'xeb3abcb48f28cba2ebdca382': {'kind': 'router', 'edges': {'xa0beb45a0c0c90aa86855d52': {'target': 'xae7ea972fa810255200b5c47', 'next_key': None}, 'x782bbea883b7618f8cb1750a': {'target': 'xc66dba178e749ee61e9f4bf3', 'next_key': None}, 'x4b7925c18db241dbe0d90f6b': {'target': 'x855276b08e22d06422336e6c', 'next_key': None}, 'x88126f62a5460231979da5cd': {'target': 'x020b4883322397417e8b475b', 'next_key': None}}}, 'xae7ea972fa810255200b5c47': {'kind': 'service', 'operation': 'login', 'handler': 'x6b53424da185bf5c31ff5e89'}, 'xa39679d656e34f3625cabefe': {'kind': 'service', 'operation': 'logout', 'handler': 'xb8156fd3ea618a91b7cc74de'}, 'xc66dba178e749ee61e9f4bf3': {'kind': 'service', 'operation': 'catalog', 'handler': 'xd5abb49f9edf16b831783f80'}, 'x6df6b388ee7603fd567290de': {'kind': 'service', 'operation': 'create_order', 'handler': 'xd240f5a39a8cdd348c34d225'}, 'x855276b08e22d06422336e6c': {'kind': 'service', 'operation': 'order', 'handler': 'xf2ec441090ae37e40a51aafd'}, 'x2e7ae274bf2ef8b9d16435cf': {'kind': 'service', 'operation': 'orders', 'handler': 'x4f83c3eec7541aeabeaa65f5'}, 'x020b4883322397417e8b475b': {'kind': 'service', 'operation': 'update_product', 'handler': 'xc080bc9c2dd7c716ac80e441'}}
ENTRY = 'xafdd9b59a043903dffecb3df'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    bindings = []
    for path in graph[entry]['edges']:
        node, key, seen = entry, path, set()
        while graph[node]['kind'] != 'service':
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        bindings.append((path, node))
    prefix = 'rebuilt/'
    while any(name.startswith(prefix) for name in graph):
        prefix += '/'
    root = prefix + 'entry'
    rebuilt = {root: {'kind': 'router', 'edges': {}}}
    for path, leaf in bindings:
        service = graph[leaf]
        operation = service['operation']
        if operation in ('login', 'logout'):
            family = 'account'
        elif operation in ('catalog', 'update_product'):
            family = 'inventory'
        else:
            family = 'orders'
        mode = 'write' if operation in ('login', 'logout', 'create_order', 'update_product') else 'read'
        branch = prefix + family
        dispatch = branch + '/' + mode
        for name in (branch, dispatch):
            if name not in rebuilt:
                rebuilt[name] = {'kind': 'router', 'edges': {}}
        rebuilt[root]['edges'][path] = {'target': branch, 'next_key': path}
        rebuilt[branch]['edges'][path] = {'target': dispatch, 'next_key': path}
        rebuilt[dispatch]['edges'][path] = {'target': leaf, 'next_key': None}
        rebuilt[leaf] = dict(service)
    return rebuilt, root

def resolve(path):
    node, key = ENTRY, path
    visited, trace = set(), []
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
