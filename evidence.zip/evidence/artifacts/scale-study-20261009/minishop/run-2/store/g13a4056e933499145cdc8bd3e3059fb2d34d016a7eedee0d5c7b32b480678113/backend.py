# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/xb0f908566d894a71a65bdce7', 'fields': ['username', 'password'], 'aliases': {'username': 'x3cda4f242a56d0e645a2b54a', 'password': 'x94352ddb3174e3d3ea53895b'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x9c3d21f7b806c3058edb4be0', 'response_box': 'xa5c4e8f7d04acc6bc181f909', 'result_key': 'x0bdaba95b25032169862bb78'}, 'logout': {'route': '/xcd938d1d363c2aec41d4d90b', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'xe0a4b2753c9c3549e02aa374', 'response_box': 'x71a5a9b7a4f1626f52bfe699', 'result_key': 'xc9e0e7b1d72dbddc013dc9df'}, 'catalog': {'route': '/x8ec503eb21a3178b7e7a6132', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'wrapped', 'request_box': 'x77cf96609077e6c08da7f345', 'response_box': 'xd164e68192f3453e60fd9675', 'result_key': 'xeed249b7b98045fc54027a8e'}, 'create_order': {'route': '/x5add64d5b64359d4bcf7e24e', 'fields': ['product_id', 'request_id', 'quantity'], 'aliases': {'product_id': 'xa0e6cec885843ac60a176236', 'request_id': 'x5075d506dc33fe9006da2fb6', 'quantity': 'xf754a9741f8374eb82b987cd'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'xb56dc79e113e31ce6b51a8e3', 'response_box': 'x7043e0273a711ae423c30326', 'result_key': 'x86e050546e0b18febd94b586'}, 'order': {'route': '/xfb67d37d579404660f523385', 'fields': ['order_id'], 'aliases': {'order_id': 'xd626cbfe4b50b6c015340d96'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'xd3a57fefa9c294ce9bdeeaeb', 'response_box': 'x3825f3d38570da4e87adceeb', 'result_key': 'x2b2ba9993013d4412440e88e'}, 'orders': {'route': '/x7263736fa0e4e5ef8db1ea8f', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'x90d133ca5c1b01ef3159d5a8', 'response_box': 'xa3c0d8313608cc08ce4652cf', 'result_key': 'x502ddc3103d2478f4e80280a'}, 'update_product': {'route': '/xe9711e924ccd2c181d1ca9a4', 'fields': ['stock', 'price', 'product_id'], 'aliases': {'stock': 'x2137638ddc3eb633bb9ae36d', 'price': 'x55013daafad4a3c5a4118d66', 'product_id': 'x59f4188647734cfaaabee53a'}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'x775e09bb4ed9729c99cf5d1b', 'response_box': 'x2690f9a5908c58dd98efd62c', 'result_key': 'x57589bb5873c5dd852fec9a5'}}
HANDLERS = {'login': 'x6b53424da185bf5c31ff5e89', 'logout': 'xb8156fd3ea618a91b7cc74de', 'catalog': 'xd5abb49f9edf16b831783f80', 'create_order': 'xd240f5a39a8cdd348c34d225', 'order': 'xf2ec441090ae37e40a51aafd', 'orders': 'x4f83c3eec7541aeabeaa65f5', 'update_product': 'xc080bc9c2dd7c716ac80e441'}
BACKEND_GRAPH = {'x6b53424da185bf5c31ff5e89': {'operation': 'login', 'target': 'x6f312aadcedeb15630576d62', 'kind': 'adapter'}, 'x6f312aadcedeb15630576d62': {'operation': 'login', 'target': 'xf2a29b156b343dfc9539a58d', 'kind': 'adapter'}, 'xf2a29b156b343dfc9539a58d': {'operation': 'login', 'target': 'x3bc129ea6d2886d522538827', 'kind': 'adapter'}, 'x3bc129ea6d2886d522538827': {'operation': 'login', 'target': 'x45734b0fbb3790759848face', 'kind': 'adapter'}, 'x45734b0fbb3790759848face': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'xb8156fd3ea618a91b7cc74de': {'operation': 'logout', 'target': 'x30e04f27fd8ad4b81a0fea6f', 'kind': 'adapter'}, 'x30e04f27fd8ad4b81a0fea6f': {'operation': 'logout', 'target': 'x0da8c3385a8801b865e4df41', 'kind': 'adapter'}, 'x0da8c3385a8801b865e4df41': {'operation': 'logout', 'target': 'x0c43f2301b58bdb6b1cbddc8', 'kind': 'adapter'}, 'x0c43f2301b58bdb6b1cbddc8': {'operation': 'logout', 'target': 'x597089f4159bb709d20362a1', 'kind': 'adapter'}, 'x597089f4159bb709d20362a1': {'operation': 'logout', 'target': 'x95bc06fc948ff4d21452e512', 'kind': 'adapter'}, 'x95bc06fc948ff4d21452e512': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'xd5abb49f9edf16b831783f80': {'operation': 'catalog', 'target': 'xbc05be3340088e718adde7dc', 'kind': 'adapter'}, 'xbc05be3340088e718adde7dc': {'operation': 'catalog', 'target': 'x541cc566b349a28a072654f4', 'kind': 'adapter'}, 'x541cc566b349a28a072654f4': {'operation': 'catalog', 'target': 'x3a798a7fb5f6775478e29444', 'kind': 'adapter'}, 'x3a798a7fb5f6775478e29444': {'operation': 'catalog', 'target': 'x870dde9cb9ecb5c157f03b94', 'kind': 'adapter'}, 'x870dde9cb9ecb5c157f03b94': {'operation': 'catalog', 'target': 'x6c89066d45d09a680b66b201', 'kind': 'adapter'}, 'x6c89066d45d09a680b66b201': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'xd240f5a39a8cdd348c34d225': {'operation': 'create_order', 'target': 'x6ffa407ba25d710ae8079e34', 'kind': 'adapter'}, 'x6ffa407ba25d710ae8079e34': {'operation': 'create_order', 'target': 'x53356f7ad6baf40076be4ae2', 'kind': 'adapter'}, 'x53356f7ad6baf40076be4ae2': {'operation': 'create_order', 'target': 'x682500b2ef9fb6ef63530dc6', 'kind': 'adapter'}, 'x682500b2ef9fb6ef63530dc6': {'operation': 'create_order', 'target': 'xb775e4ae4c36148b2a6a5f6f', 'kind': 'adapter'}, 'xb775e4ae4c36148b2a6a5f6f': {'operation': 'create_order', 'target': 'xc4c1a9dd6707b23e914fe69f', 'kind': 'adapter'}, 'xc4c1a9dd6707b23e914fe69f': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'xf2ec441090ae37e40a51aafd': {'operation': 'order', 'target': 'x9c82e5d10ac4746974a635c5', 'kind': 'adapter'}, 'x9c82e5d10ac4746974a635c5': {'operation': 'order', 'target': 'xd02bb48087c8325fccf2fe84', 'kind': 'adapter'}, 'xd02bb48087c8325fccf2fe84': {'operation': 'order', 'target': 'x9bdeaa61951fe9e4bc11e200', 'kind': 'adapter'}, 'x9bdeaa61951fe9e4bc11e200': {'operation': 'order', 'target': 'x9e6ac42f1c074227dbea5525', 'kind': 'adapter'}, 'x9e6ac42f1c074227dbea5525': {'operation': 'order', 'target': 'x2bab5f492c86615cea546214', 'kind': 'adapter'}, 'x2bab5f492c86615cea546214': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x4f83c3eec7541aeabeaa65f5': {'operation': 'orders', 'target': 'x3d6e371e20d2aabd86a2f3b9', 'kind': 'adapter'}, 'x3d6e371e20d2aabd86a2f3b9': {'operation': 'orders', 'target': 'xc5e2349954acd2331d5e8840', 'kind': 'adapter'}, 'xc5e2349954acd2331d5e8840': {'operation': 'orders', 'target': 'x6d15b9d2c336c618a1c9291a', 'kind': 'adapter'}, 'x6d15b9d2c336c618a1c9291a': {'operation': 'orders', 'target': 'xc8941070945fc26684d57fd2', 'kind': 'adapter'}, 'xc8941070945fc26684d57fd2': {'operation': 'orders', 'target': 'x08a6c6e0a0a356b35829cb2a', 'kind': 'adapter'}, 'x08a6c6e0a0a356b35829cb2a': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'xc080bc9c2dd7c716ac80e441': {'operation': 'update_product', 'target': 'xac456dec2275ed9f63efbf5a', 'kind': 'adapter'}, 'xac456dec2275ed9f63efbf5a': {'operation': 'update_product', 'target': 'xc80a553e104b842225d921eb', 'kind': 'adapter'}, 'xc80a553e104b842225d921eb': {'operation': 'update_product', 'target': 'x6fbfaf2d74d96932e2be222e', 'kind': 'adapter'}, 'x6fbfaf2d74d96932e2be222e': {'operation': 'update_product', 'target': 'xeedc864c01abb182ba8642d5', 'kind': 'adapter'}, 'xeedc864c01abb182ba8642d5': {'operation': 'update_product', 'target': 'x592ee9097a13b7d9c5240907', 'kind': 'adapter'}, 'x592ee9097a13b7d9c5240907': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def x6b53424da185bf5c31ff5e89(core, operation, data, session, actor, trace):
    trace.append('x6b53424da185bf5c31ff5e89')
    return x6f312aadcedeb15630576d62(core, operation, data, session, actor, trace)

def x6f312aadcedeb15630576d62(core, operation, data, session, actor, trace):
    trace.append('x6f312aadcedeb15630576d62')
    return xf2a29b156b343dfc9539a58d(core, operation, data, session, actor, trace)

def xf2a29b156b343dfc9539a58d(core, operation, data, session, actor, trace):
    trace.append('xf2a29b156b343dfc9539a58d')
    return x3bc129ea6d2886d522538827(core, operation, data, session, actor, trace)

def x3bc129ea6d2886d522538827(core, operation, data, session, actor, trace):
    trace.append('x3bc129ea6d2886d522538827')
    return x45734b0fbb3790759848face(core, operation, data, session, actor, trace)

def x45734b0fbb3790759848face(core, operation, data, session, actor, trace):
    trace.append('x45734b0fbb3790759848face')
    return core.execute(operation, data, session, actor)

def xb8156fd3ea618a91b7cc74de(core, operation, data, session, actor, trace):
    trace.append('xb8156fd3ea618a91b7cc74de')
    return x30e04f27fd8ad4b81a0fea6f(core, operation, data, session, actor, trace)

def x30e04f27fd8ad4b81a0fea6f(core, operation, data, session, actor, trace):
    trace.append('x30e04f27fd8ad4b81a0fea6f')
    return x0da8c3385a8801b865e4df41(core, operation, data, session, actor, trace)

def x0da8c3385a8801b865e4df41(core, operation, data, session, actor, trace):
    trace.append('x0da8c3385a8801b865e4df41')
    return x0c43f2301b58bdb6b1cbddc8(core, operation, data, session, actor, trace)

def x0c43f2301b58bdb6b1cbddc8(core, operation, data, session, actor, trace):
    trace.append('x0c43f2301b58bdb6b1cbddc8')
    return x597089f4159bb709d20362a1(core, operation, data, session, actor, trace)

def x597089f4159bb709d20362a1(core, operation, data, session, actor, trace):
    trace.append('x597089f4159bb709d20362a1')
    return x95bc06fc948ff4d21452e512(core, operation, data, session, actor, trace)

def x95bc06fc948ff4d21452e512(core, operation, data, session, actor, trace):
    trace.append('x95bc06fc948ff4d21452e512')
    return core.execute(operation, data, session, actor)

def xd5abb49f9edf16b831783f80(core, operation, data, session, actor, trace):
    trace.append('xd5abb49f9edf16b831783f80')
    return xbc05be3340088e718adde7dc(core, operation, data, session, actor, trace)

def xbc05be3340088e718adde7dc(core, operation, data, session, actor, trace):
    trace.append('xbc05be3340088e718adde7dc')
    return x541cc566b349a28a072654f4(core, operation, data, session, actor, trace)

def x541cc566b349a28a072654f4(core, operation, data, session, actor, trace):
    trace.append('x541cc566b349a28a072654f4')
    return x3a798a7fb5f6775478e29444(core, operation, data, session, actor, trace)

def x3a798a7fb5f6775478e29444(core, operation, data, session, actor, trace):
    trace.append('x3a798a7fb5f6775478e29444')
    return x870dde9cb9ecb5c157f03b94(core, operation, data, session, actor, trace)

def x870dde9cb9ecb5c157f03b94(core, operation, data, session, actor, trace):
    trace.append('x870dde9cb9ecb5c157f03b94')
    return x6c89066d45d09a680b66b201(core, operation, data, session, actor, trace)

def x6c89066d45d09a680b66b201(core, operation, data, session, actor, trace):
    trace.append('x6c89066d45d09a680b66b201')
    return core.execute(operation, data, session, actor)

def xd240f5a39a8cdd348c34d225(core, operation, data, session, actor, trace):
    trace.append('xd240f5a39a8cdd348c34d225')
    return x6ffa407ba25d710ae8079e34(core, operation, data, session, actor, trace)

def x6ffa407ba25d710ae8079e34(core, operation, data, session, actor, trace):
    trace.append('x6ffa407ba25d710ae8079e34')
    return x53356f7ad6baf40076be4ae2(core, operation, data, session, actor, trace)

def x53356f7ad6baf40076be4ae2(core, operation, data, session, actor, trace):
    trace.append('x53356f7ad6baf40076be4ae2')
    return x682500b2ef9fb6ef63530dc6(core, operation, data, session, actor, trace)

def x682500b2ef9fb6ef63530dc6(core, operation, data, session, actor, trace):
    trace.append('x682500b2ef9fb6ef63530dc6')
    return xb775e4ae4c36148b2a6a5f6f(core, operation, data, session, actor, trace)

def xb775e4ae4c36148b2a6a5f6f(core, operation, data, session, actor, trace):
    trace.append('xb775e4ae4c36148b2a6a5f6f')
    return xc4c1a9dd6707b23e914fe69f(core, operation, data, session, actor, trace)

def xc4c1a9dd6707b23e914fe69f(core, operation, data, session, actor, trace):
    trace.append('xc4c1a9dd6707b23e914fe69f')
    return core.execute(operation, data, session, actor)

def xf2ec441090ae37e40a51aafd(core, operation, data, session, actor, trace):
    trace.append('xf2ec441090ae37e40a51aafd')
    return x9c82e5d10ac4746974a635c5(core, operation, data, session, actor, trace)

def x9c82e5d10ac4746974a635c5(core, operation, data, session, actor, trace):
    trace.append('x9c82e5d10ac4746974a635c5')
    return xd02bb48087c8325fccf2fe84(core, operation, data, session, actor, trace)

def xd02bb48087c8325fccf2fe84(core, operation, data, session, actor, trace):
    trace.append('xd02bb48087c8325fccf2fe84')
    return x9bdeaa61951fe9e4bc11e200(core, operation, data, session, actor, trace)

def x9bdeaa61951fe9e4bc11e200(core, operation, data, session, actor, trace):
    trace.append('x9bdeaa61951fe9e4bc11e200')
    return x9e6ac42f1c074227dbea5525(core, operation, data, session, actor, trace)

def x9e6ac42f1c074227dbea5525(core, operation, data, session, actor, trace):
    trace.append('x9e6ac42f1c074227dbea5525')
    return x2bab5f492c86615cea546214(core, operation, data, session, actor, trace)

def x2bab5f492c86615cea546214(core, operation, data, session, actor, trace):
    trace.append('x2bab5f492c86615cea546214')
    return core.execute(operation, data, session, actor)

def x4f83c3eec7541aeabeaa65f5(core, operation, data, session, actor, trace):
    trace.append('x4f83c3eec7541aeabeaa65f5')
    return x3d6e371e20d2aabd86a2f3b9(core, operation, data, session, actor, trace)

def x3d6e371e20d2aabd86a2f3b9(core, operation, data, session, actor, trace):
    trace.append('x3d6e371e20d2aabd86a2f3b9')
    return xc5e2349954acd2331d5e8840(core, operation, data, session, actor, trace)

def xc5e2349954acd2331d5e8840(core, operation, data, session, actor, trace):
    trace.append('xc5e2349954acd2331d5e8840')
    return x6d15b9d2c336c618a1c9291a(core, operation, data, session, actor, trace)

def x6d15b9d2c336c618a1c9291a(core, operation, data, session, actor, trace):
    trace.append('x6d15b9d2c336c618a1c9291a')
    return xc8941070945fc26684d57fd2(core, operation, data, session, actor, trace)

def xc8941070945fc26684d57fd2(core, operation, data, session, actor, trace):
    trace.append('xc8941070945fc26684d57fd2')
    return x08a6c6e0a0a356b35829cb2a(core, operation, data, session, actor, trace)

def x08a6c6e0a0a356b35829cb2a(core, operation, data, session, actor, trace):
    trace.append('x08a6c6e0a0a356b35829cb2a')
    return core.execute(operation, data, session, actor)

def xc080bc9c2dd7c716ac80e441(core, operation, data, session, actor, trace):
    trace.append('xc080bc9c2dd7c716ac80e441')
    return xac456dec2275ed9f63efbf5a(core, operation, data, session, actor, trace)

def xac456dec2275ed9f63efbf5a(core, operation, data, session, actor, trace):
    trace.append('xac456dec2275ed9f63efbf5a')
    return xc80a553e104b842225d921eb(core, operation, data, session, actor, trace)

def xc80a553e104b842225d921eb(core, operation, data, session, actor, trace):
    trace.append('xc80a553e104b842225d921eb')
    return x6fbfaf2d74d96932e2be222e(core, operation, data, session, actor, trace)

def x6fbfaf2d74d96932e2be222e(core, operation, data, session, actor, trace):
    trace.append('x6fbfaf2d74d96932e2be222e')
    return xeedc864c01abb182ba8642d5(core, operation, data, session, actor, trace)

def xeedc864c01abb182ba8642d5(core, operation, data, session, actor, trace):
    trace.append('xeedc864c01abb182ba8642d5')
    return x592ee9097a13b7d9c5240907(core, operation, data, session, actor, trace)

def x592ee9097a13b7d9c5240907(core, operation, data, session, actor, trace):
    trace.append('x592ee9097a13b7d9c5240907')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def decode(operation, wire):
    contract = CONTRACT[operation]
    shape = contract['request_shape']
    if shape in ('wrapped', 'pairs'):
        box = contract['request_box']
        if not isinstance(wire, dict) or set(wire) != {box}:
            raise ValueError('box')
        wire = wire[box]
    if shape == 'positional':
        if not isinstance(wire, list) or len(wire) != len(contract['fields']):
            raise ValueError('arity')
        return dict(zip(contract['fields'], wire))
    if shape == 'pairs':
        if not isinstance(wire, list):
            raise ValueError('pairs')
        entries = wire
    else:
        if not isinstance(wire, dict):
            raise ValueError('fields')
        entries = wire.items()
    names = {alias: field for field, alias in contract['aliases'].items()}
    seen, translated = set(), {}
    for entry in entries:
        if shape == 'pairs':
            if not isinstance(entry, list) or len(entry) != 2 or not isinstance(entry[0], str) or entry[0] in seen:
                raise ValueError('pair')
        key, value = entry
        seen.add(key)
        if key in names:
            translated[names[key]] = value
    if seen != set(names):
        raise ValueError('fields')
    return {field: translated[field] for field in contract['fields']}

def dispatch_envelope(request):
    handler_name, core, operation, data, session, actor = request
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    return ORIGINAL_INVOKE(handler_name, core, operation, data, session, actor)

def invoke(handler_name, core, operation, data, session, actor):
    request = (handler_name, core, operation, data, session, actor)
    return dispatch_envelope(request)

