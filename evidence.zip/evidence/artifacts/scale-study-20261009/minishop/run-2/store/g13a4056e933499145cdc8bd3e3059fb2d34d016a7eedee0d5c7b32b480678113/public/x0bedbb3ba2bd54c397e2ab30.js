import {send} from './x8a6d52fc40788cfaab661a08.js';
export async function xb3b45184a6226acce3c7abb4(data,csrf){const wire={"x3cda4f242a56d0e645a2b54a":data["username"],"x94352ddb3174e3d3ea53895b":data["password"]};const value=await send("/xb0f908566d894a71a65bdce7",wire,csrf);return value["x0bdaba95b25032169862bb78"];}
export async function x512f4d866ac3588eda56d36c(data,csrf){const wire={"xd626cbfe4b50b6c015340d96":data["order_id"]};const value=await send("/xfb67d37d579404660f523385",wire,csrf);return value["x2b2ba9993013d4412440e88e"];}
