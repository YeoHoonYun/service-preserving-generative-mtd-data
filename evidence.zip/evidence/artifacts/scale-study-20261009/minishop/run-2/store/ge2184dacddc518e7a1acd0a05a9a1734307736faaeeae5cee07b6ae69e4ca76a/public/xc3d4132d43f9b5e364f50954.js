import {send} from './x3fffef3821510a75d1c2e697.js';
export async function xe45eb5c9af6938723b8ec09c(data,csrf){const wire={};const value=await send("/xfca95ec372e1f2d5c0c0cc3f",wire,csrf);return value[0];}
export async function x2057182788cb86c2cc226892(data,csrf){const wire={"xfc15e92a5e0600de96b9a862":{"xd952df5e958d716e90c138eb":data["product_id"],"xa11407f8140a5ece87c0b084":data["quantity"],"xedeceab68386a1a40975ec0a":data["request_id"]}};const value=await send("/xa7fa20fbd5a73f5807c253e4",wire,csrf);return value["x13d8a6ce4f7f803e9f9ebc5f"]["x2d7ba3faefa81037c4413e49"];}
export async function x2cfa2fd4002950c37f3e4b59(data,csrf){const wire=[];const value=await send("/xf141a08a4ad0e67030e88c1b",wire,csrf);return value["x230537a4c24ec5cc7391a7d1"]["x5c3e55b1a2fd06021b107955"];}
