import {x7742c5dae90487485ea37c3d,xf72467c3c4952d13be2693ad,x378b9a2006d38d258d96fe38,xae2b4eed41c999a1407c8f51} from './x3ec6187a670641184c28b75d.js';
import {xe45eb5c9af6938723b8ec09c,x2057182788cb86c2cc226892,x2cfa2fd4002950c37f3e4b59} from './xc3d4132d43f9b5e364f50954.js';
let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('xc7a9f7c420a1f96f60caa623');
const endpoints={login:x7742c5dae90487485ea37c3d,logout:xe45eb5c9af6938723b8ec09c,catalog:xf72467c3c4952d13be2693ad,create_order:x2057182788cb86c2cc226892,order:x378b9a2006d38d258d96fe38,orders:x2cfa2fd4002950c37f3e4b59,update_product:xae2b4eed41c999a1407c8f51};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('xd4660cf332ca31f5c8623f10').textContent=boot.user?boot.user.id:'방문자';}
async function observe(task){try{await task();}catch(error){message.textContent=error.message;}}
function collectionView(id,operation,format,complete){
 return async function(){
  const list=document.getElementById(id);
  list.replaceChildren();
  for(const item of await api(operation)){
   const row=document.createElement('li');
   row.textContent=format(item);
   list.append(row);
  }
  if(complete)complete();
 };
}
const catalog=collectionView('xeb846212fc7730bed0955553','catalog',p=>p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock,()=>{document.body.dataset.ready='yes';});
const orders=collectionView('xa05c82a31b0ddcf79dfbea9f','orders',order=>order.id+' · '+order.total+'원');
function formData(form){
 const raw=Object.fromEntries(new FormData(form));
 return {username:raw['x6fd901961dbeae3032bb0540'],password:raw['x9488192eada07857c400bfd8'],product_id:raw['xfd53913ec78b21573845c241'],quantity:raw['xd571a125efd688baa0cb23e3'],price:raw['xaacfb7c36e67d18548acb4c2'],stock:raw['x2fe0b20577b5588d4885aece']};
}
async function submitForm(form){
 const data=formData(form);
 if(form.dataset.action==='xcfaa8dbcb309caddc4d0ed99'){
  boot=await api('login',data);
  identity();
  message.textContent='로그인되었습니다.';
 }
 if(form.dataset.action==='x473a2fd43f948cdf1166ad2e'){
  const order=await api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()});
  message.textContent='주문 '+order.id+' · '+order.total+'원';
  await catalog();
  await orders();
 }
 if(form.dataset.action==='xec87f2ad7d97f8a9d886e7ae'){
  await api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)});
  message.textContent='상품을 수정했습니다.';
  await catalog();
 }
}
const ports={
 submit:{handleEvent(event){event.preventDefault();observe(()=>submitForm(event.target));}},
 logout:{handleEvent(){observe(()=>api('logout').then(()=>location.reload()));}},
 orders:{handleEvent(){observe(orders);}}
};
document.addEventListener('submit',ports.submit);
document.getElementById('xacf6f1459f216b36402ff028').onclick=ports.logout.handleEvent.bind(ports.logout);
document.getElementById('xd53e1757d79cd2996903dd4a').onclick=ports.orders.handleEvent.bind(ports.orders);
identity();
observe(catalog);
