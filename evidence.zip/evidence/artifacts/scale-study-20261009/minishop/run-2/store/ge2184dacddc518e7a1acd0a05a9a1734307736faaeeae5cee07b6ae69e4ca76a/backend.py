# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x557f5a76ec67f14381cd32eb', 'fields': ['username', 'password'], 'aliases': {'username': 'x8b5a05a094af0ecfe6078d98', 'password': 'x5d989deb2f70e9e0edbf139e'}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'x4ce49f95bc8799bd357cd7d6', 'response_box': 'x431c3f0ec555330c526a413c', 'result_key': 'xfd5887b20f945444a7113d1a'}, 'logout': {'route': '/xfca95ec372e1f2d5c0c0cc3f', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'x1e61f5a52725efc653e8426e', 'response_box': 'x2117ab9307744f7287a71603', 'result_key': 'x0736067c362e56a8bf430161'}, 'catalog': {'route': '/x34990b26214c2a91bbed4c3d', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'x1a5b33cdb83b8a418692f0af', 'response_box': 'xb55fc954d42260ddd5de5b77', 'result_key': 'x84e3609ea9b440240bb69b45'}, 'create_order': {'route': '/xa7fa20fbd5a73f5807c253e4', 'fields': ['product_id', 'quantity', 'request_id'], 'aliases': {'product_id': 'xd952df5e958d716e90c138eb', 'quantity': 'xa11407f8140a5ece87c0b084', 'request_id': 'xedeceab68386a1a40975ec0a'}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'xfc15e92a5e0600de96b9a862', 'response_box': 'x13d8a6ce4f7f803e9f9ebc5f', 'result_key': 'x2d7ba3faefa81037c4413e49'}, 'order': {'route': '/x2b0368fcad7e4340754dc08a', 'fields': ['order_id'], 'aliases': {'order_id': 'x25c2bf0c63fb00ea5bffc4dc'}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'x9e46d166477422d18ce876ea', 'response_box': 'x16499976d5bfa6e8a30c7ac5', 'result_key': 'x247a9dede210b5adc776809d'}, 'orders': {'route': '/xf141a08a4ad0e67030e88c1b', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'wrapped', 'request_box': 'x0d78b03f749ffef114c31c77', 'response_box': 'x230537a4c24ec5cc7391a7d1', 'result_key': 'x5c3e55b1a2fd06021b107955'}, 'update_product': {'route': '/xa9b3cc0a0a17728985a99751', 'fields': ['product_id', 'price', 'stock'], 'aliases': {'product_id': 'xe3f45f85fff0829a7e2279c2', 'price': 'xe5976ce5ee733f13a504f484', 'stock': 'xad216f59ef794636deb00a55'}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'x7ac48f9ce17766bdd95ba405', 'response_box': 'x14e399bcda9b1c0d9ce634ae', 'result_key': 'x4b24f06b4f773c9a452e435d'}}
HANDLERS = {'login': 'x1ea6ea6131cba218ece9847c', 'logout': 'x214c59f07e7358eb8795e0c5', 'catalog': 'x7d67ff2fbd65b218567b8bbc', 'create_order': 'x076dd871550f94a3a91d2a9f', 'order': 'x63e07717678de3327fee55fa', 'orders': 'xc57d52ab41df4a748fb9152e', 'update_product': 'xe40fcdbcdfbbd922c91f2d06'}
BACKEND_GRAPH = {'x1ea6ea6131cba218ece9847c': {'operation': 'login', 'target': 'xfba3276d4985dd40ccbdd8ad', 'kind': 'adapter'}, 'xfba3276d4985dd40ccbdd8ad': {'operation': 'login', 'target': 'xdf26ba9aaf4635e79e7064ce', 'kind': 'adapter'}, 'xdf26ba9aaf4635e79e7064ce': {'operation': 'login', 'target': 'x45af4b65154312434ac2be61', 'kind': 'adapter'}, 'x45af4b65154312434ac2be61': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x214c59f07e7358eb8795e0c5': {'operation': 'logout', 'target': 'x71a0afc1da8737be85759d60', 'kind': 'adapter'}, 'x71a0afc1da8737be85759d60': {'operation': 'logout', 'target': 'x23dcd8e8fc32d74da85e33c9', 'kind': 'adapter'}, 'x23dcd8e8fc32d74da85e33c9': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x7d67ff2fbd65b218567b8bbc': {'operation': 'catalog', 'target': 'xf2f0731d9c4ebf7e953a7ef1', 'kind': 'adapter'}, 'xf2f0731d9c4ebf7e953a7ef1': {'operation': 'catalog', 'target': 'x50c2e1a7ad2b08e4c0a418c9', 'kind': 'adapter'}, 'x50c2e1a7ad2b08e4c0a418c9': {'operation': 'catalog', 'target': 'x13508ee6fe37cc3c869659ef', 'kind': 'adapter'}, 'x13508ee6fe37cc3c869659ef': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x076dd871550f94a3a91d2a9f': {'operation': 'create_order', 'target': 'x6753f67664ec4eec2969916d', 'kind': 'adapter'}, 'x6753f67664ec4eec2969916d': {'operation': 'create_order', 'target': 'x262cb0ebca4a3ce7a799c87f', 'kind': 'adapter'}, 'x262cb0ebca4a3ce7a799c87f': {'operation': 'create_order', 'target': 'xf447d492542b2a66971a6332', 'kind': 'adapter'}, 'xf447d492542b2a66971a6332': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x63e07717678de3327fee55fa': {'operation': 'order', 'target': 'x78e407664d5827270352c9c6', 'kind': 'adapter'}, 'x78e407664d5827270352c9c6': {'operation': 'order', 'target': 'x9d531537d9f7cd25d70f0f73', 'kind': 'adapter'}, 'x9d531537d9f7cd25d70f0f73': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'xc57d52ab41df4a748fb9152e': {'operation': 'orders', 'target': 'x0a77fd48b14143e59ab3f45c', 'kind': 'adapter'}, 'x0a77fd48b14143e59ab3f45c': {'operation': 'orders', 'target': 'xfbdb70e3cb7392e60f4dc197', 'kind': 'adapter'}, 'xfbdb70e3cb7392e60f4dc197': {'operation': 'orders', 'target': 'x44392fc09ecd5727c0901fe3', 'kind': 'adapter'}, 'x44392fc09ecd5727c0901fe3': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'xe40fcdbcdfbbd922c91f2d06': {'operation': 'update_product', 'target': 'x93a8e19796b097b6bf9008b7', 'kind': 'adapter'}, 'x93a8e19796b097b6bf9008b7': {'operation': 'update_product', 'target': 'xca09e42619afbf0b84b4e879', 'kind': 'adapter'}, 'xca09e42619afbf0b84b4e879': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def x1ea6ea6131cba218ece9847c(core, operation, data, session, actor, trace):
    trace.append('x1ea6ea6131cba218ece9847c')
    return xfba3276d4985dd40ccbdd8ad(core, operation, data, session, actor, trace)

def xfba3276d4985dd40ccbdd8ad(core, operation, data, session, actor, trace):
    trace.append('xfba3276d4985dd40ccbdd8ad')
    return xdf26ba9aaf4635e79e7064ce(core, operation, data, session, actor, trace)

def xdf26ba9aaf4635e79e7064ce(core, operation, data, session, actor, trace):
    trace.append('xdf26ba9aaf4635e79e7064ce')
    return x45af4b65154312434ac2be61(core, operation, data, session, actor, trace)

def x45af4b65154312434ac2be61(core, operation, data, session, actor, trace):
    trace.append('x45af4b65154312434ac2be61')
    return core.execute(operation, data, session, actor)

def x214c59f07e7358eb8795e0c5(core, operation, data, session, actor, trace):
    trace.append('x214c59f07e7358eb8795e0c5')
    return x71a0afc1da8737be85759d60(core, operation, data, session, actor, trace)

def x71a0afc1da8737be85759d60(core, operation, data, session, actor, trace):
    trace.append('x71a0afc1da8737be85759d60')
    return x23dcd8e8fc32d74da85e33c9(core, operation, data, session, actor, trace)

def x23dcd8e8fc32d74da85e33c9(core, operation, data, session, actor, trace):
    trace.append('x23dcd8e8fc32d74da85e33c9')
    return core.execute(operation, data, session, actor)

def x7d67ff2fbd65b218567b8bbc(core, operation, data, session, actor, trace):
    trace.append('x7d67ff2fbd65b218567b8bbc')
    return xf2f0731d9c4ebf7e953a7ef1(core, operation, data, session, actor, trace)

def xf2f0731d9c4ebf7e953a7ef1(core, operation, data, session, actor, trace):
    trace.append('xf2f0731d9c4ebf7e953a7ef1')
    return x50c2e1a7ad2b08e4c0a418c9(core, operation, data, session, actor, trace)

def x50c2e1a7ad2b08e4c0a418c9(core, operation, data, session, actor, trace):
    trace.append('x50c2e1a7ad2b08e4c0a418c9')
    return x13508ee6fe37cc3c869659ef(core, operation, data, session, actor, trace)

def x13508ee6fe37cc3c869659ef(core, operation, data, session, actor, trace):
    trace.append('x13508ee6fe37cc3c869659ef')
    return core.execute(operation, data, session, actor)

def x076dd871550f94a3a91d2a9f(core, operation, data, session, actor, trace):
    trace.append('x076dd871550f94a3a91d2a9f')
    return x6753f67664ec4eec2969916d(core, operation, data, session, actor, trace)

def x6753f67664ec4eec2969916d(core, operation, data, session, actor, trace):
    trace.append('x6753f67664ec4eec2969916d')
    return x262cb0ebca4a3ce7a799c87f(core, operation, data, session, actor, trace)

def x262cb0ebca4a3ce7a799c87f(core, operation, data, session, actor, trace):
    trace.append('x262cb0ebca4a3ce7a799c87f')
    return xf447d492542b2a66971a6332(core, operation, data, session, actor, trace)

def xf447d492542b2a66971a6332(core, operation, data, session, actor, trace):
    trace.append('xf447d492542b2a66971a6332')
    return core.execute(operation, data, session, actor)

def x63e07717678de3327fee55fa(core, operation, data, session, actor, trace):
    trace.append('x63e07717678de3327fee55fa')
    return x78e407664d5827270352c9c6(core, operation, data, session, actor, trace)

def x78e407664d5827270352c9c6(core, operation, data, session, actor, trace):
    trace.append('x78e407664d5827270352c9c6')
    return x9d531537d9f7cd25d70f0f73(core, operation, data, session, actor, trace)

def x9d531537d9f7cd25d70f0f73(core, operation, data, session, actor, trace):
    trace.append('x9d531537d9f7cd25d70f0f73')
    return core.execute(operation, data, session, actor)

def xc57d52ab41df4a748fb9152e(core, operation, data, session, actor, trace):
    trace.append('xc57d52ab41df4a748fb9152e')
    return x0a77fd48b14143e59ab3f45c(core, operation, data, session, actor, trace)

def x0a77fd48b14143e59ab3f45c(core, operation, data, session, actor, trace):
    trace.append('x0a77fd48b14143e59ab3f45c')
    return xfbdb70e3cb7392e60f4dc197(core, operation, data, session, actor, trace)

def xfbdb70e3cb7392e60f4dc197(core, operation, data, session, actor, trace):
    trace.append('xfbdb70e3cb7392e60f4dc197')
    return x44392fc09ecd5727c0901fe3(core, operation, data, session, actor, trace)

def x44392fc09ecd5727c0901fe3(core, operation, data, session, actor, trace):
    trace.append('x44392fc09ecd5727c0901fe3')
    return core.execute(operation, data, session, actor)

def xe40fcdbcdfbbd922c91f2d06(core, operation, data, session, actor, trace):
    trace.append('xe40fcdbcdfbbd922c91f2d06')
    return x93a8e19796b097b6bf9008b7(core, operation, data, session, actor, trace)

def x93a8e19796b097b6bf9008b7(core, operation, data, session, actor, trace):
    trace.append('x93a8e19796b097b6bf9008b7')
    return xca09e42619afbf0b84b4e879(core, operation, data, session, actor, trace)

def xca09e42619afbf0b84b4e879(core, operation, data, session, actor, trace):
    trace.append('xca09e42619afbf0b84b4e879')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def adapter_binding(operation):
    groups = {
        'wrapped': {
            'login': x1ea6ea6131cba218ece9847c,
            'create_order': x076dd871550f94a3a91d2a9f
        },
        'flat': {'logout': x214c59f07e7358eb8795e0c5},
        'positional': {
            'catalog': x7d67ff2fbd65b218567b8bbc,
            'orders': xc57d52ab41df4a748fb9152e
        },
        'pairs': {
            'order': x63e07717678de3327fee55fa,
            'update_product': xe40fcdbcdfbbd922c91f2d06
        }
    }
    return groups[CONTRACT[operation]['request_shape']][operation]

def call_adapter(binding, arguments):
    trace = []
    status, result, cookie = binding(*arguments, trace)
    return status, result, cookie, trace

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    binding = adapter_binding(operation)
    return call_adapter(binding, (core, operation, data, session, actor))

