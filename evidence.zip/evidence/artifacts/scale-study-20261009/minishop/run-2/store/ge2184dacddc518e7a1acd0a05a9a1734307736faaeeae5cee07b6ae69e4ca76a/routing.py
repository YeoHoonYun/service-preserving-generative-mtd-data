GRAPH = {'xa4373c11ac08d0e8785589c6': {'kind': 'router', 'edges': {'/x557f5a76ec67f14381cd32eb': {'target': 'x872e772f4e0bb51fef0c8c90', 'next_key': 'x8579be09089edd9af36fd88e'}, '/xfca95ec372e1f2d5c0c0cc3f': {'target': 'x4583b8a0e78f4873967976d4', 'next_key': 'xefa3812d22a4beb9d17303f4'}, '/x34990b26214c2a91bbed4c3d': {'target': 'x872e772f4e0bb51fef0c8c90', 'next_key': 'x9e6df629dbdec3be702b5ae0'}, '/xa7fa20fbd5a73f5807c253e4': {'target': 'x4583b8a0e78f4873967976d4', 'next_key': 'x52e413d220d0c3bff68a3000'}, '/x2b0368fcad7e4340754dc08a': {'target': 'x872e772f4e0bb51fef0c8c90', 'next_key': 'x061930415b8efb0902f61bee'}, '/xf141a08a4ad0e67030e88c1b': {'target': 'x4583b8a0e78f4873967976d4', 'next_key': 'xd1b3468cb46b550f1eea2303'}, '/xa9b3cc0a0a17728985a99751': {'target': 'x872e772f4e0bb51fef0c8c90', 'next_key': 'x7ab8eab9f650348509d11348'}}}, 'x4583b8a0e78f4873967976d4': {'kind': 'router', 'edges': {'xefa3812d22a4beb9d17303f4': {'target': 'x5d566c02c9c3c03fe50cc5de', 'next_key': 'x0c64252671222fe008e0f27d'}, 'x52e413d220d0c3bff68a3000': {'target': 'x5d566c02c9c3c03fe50cc5de', 'next_key': 'x53bebc846016ec0921306594'}, 'xd1b3468cb46b550f1eea2303': {'target': 'x5d566c02c9c3c03fe50cc5de', 'next_key': 'x3e173dd8bec37a136716c35e'}}}, 'x872e772f4e0bb51fef0c8c90': {'kind': 'router', 'edges': {'x8579be09089edd9af36fd88e': {'target': 'x5d566c02c9c3c03fe50cc5de', 'next_key': 'x1eb4c38e6ac8de8ac51a440a'}, 'x9e6df629dbdec3be702b5ae0': {'target': 'x5d566c02c9c3c03fe50cc5de', 'next_key': 'x006d2eec53a9717e9c24c404'}, 'x061930415b8efb0902f61bee': {'target': 'x5d566c02c9c3c03fe50cc5de', 'next_key': 'xc495d4a877c2314bf02d9046'}, 'x7ab8eab9f650348509d11348': {'target': 'x5d566c02c9c3c03fe50cc5de', 'next_key': 'x9eac1161f11666731f8222bb'}}}, 'x5d566c02c9c3c03fe50cc5de': {'kind': 'router', 'edges': {'x1eb4c38e6ac8de8ac51a440a': {'target': 'xca4b3903b0cdf27de92a3fd0', 'next_key': None}, 'x0c64252671222fe008e0f27d': {'target': 'x114984d52314013e1fb637b2', 'next_key': None}, 'x006d2eec53a9717e9c24c404': {'target': 'x2fd3fb86a548f207504fb574', 'next_key': None}, 'x53bebc846016ec0921306594': {'target': 'x4c38388af3127b79db28d495', 'next_key': None}, 'xc495d4a877c2314bf02d9046': {'target': 'x754f6e1e13d8e73b33cb9993', 'next_key': None}, 'x3e173dd8bec37a136716c35e': {'target': 'xc0462489c0860423537e6cdc', 'next_key': None}, 'x9eac1161f11666731f8222bb': {'target': 'xb659a3218159e0b7a21c0650', 'next_key': None}}}, 'xca4b3903b0cdf27de92a3fd0': {'kind': 'service', 'operation': 'login', 'handler': 'x1ea6ea6131cba218ece9847c'}, 'x114984d52314013e1fb637b2': {'kind': 'service', 'operation': 'logout', 'handler': 'x214c59f07e7358eb8795e0c5'}, 'x2fd3fb86a548f207504fb574': {'kind': 'service', 'operation': 'catalog', 'handler': 'x7d67ff2fbd65b218567b8bbc'}, 'x4c38388af3127b79db28d495': {'kind': 'service', 'operation': 'create_order', 'handler': 'x076dd871550f94a3a91d2a9f'}, 'x754f6e1e13d8e73b33cb9993': {'kind': 'service', 'operation': 'order', 'handler': 'x63e07717678de3327fee55fa'}, 'xc0462489c0860423537e6cdc': {'kind': 'service', 'operation': 'orders', 'handler': 'xc57d52ab41df4a748fb9152e'}, 'xb659a3218159e0b7a21c0650': {'kind': 'service', 'operation': 'update_product', 'handler': 'xe40fcdbcdfbbd922c91f2d06'}}
ENTRY = 'xa4373c11ac08d0e8785589c6'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    bindings = []
    for path in sorted(graph[entry]['edges']):
        node, key, seen = entry, path, set()
        while graph[node]['kind'] != 'service':
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        bindings.append((path, node))
    root = 'placement:root'
    result = {root: {'kind': 'router', 'edges': {}}}
    count = min(3, len(bindings))
    loads = [0] * count
    leaves = {}
    for index, binding in enumerate(bindings):
        path, source = binding
        if index < count:
            bucket = index
        else:
            first = sum(ord(char) for char in path) % count
            second = sum((position + 1) * ord(char) for position, char in enumerate(path)) % count
            bucket = first if loads[first] <= loads[second] else second
        branch = 'placement:bucket:' + str(bucket)
        if branch not in result:
            result[branch] = {'kind': 'router', 'edges': {}}
        if source not in leaves:
            leaf = 'placement:leaf:' + str(len(leaves))
            leaves[source] = leaf
            result[leaf] = dict(graph[source])
        result[root]['edges'][path] = {'target': branch, 'next_key': path}
        result[branch]['edges'][path] = {'target': leaves[source], 'next_key': None}
        loads[bucket] += 1
    return result, root

def resolve(path):
    node, key = ENTRY, path
    trace, visited = [], set()
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
