# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x45cc2cb3587d03e84d4a1644', 'fields': ['username', 'password'], 'aliases': {'username': 'x43885942a39a87cf4ff9dc34', 'password': 'x54148dccf3a77ed11b763867'}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'xa99173283a2870202ec4dc62', 'response_box': 'xa0cdf54d2dd287225a8c9254', 'result_key': 'x6f3827576604be64b0406efb'}, 'logout': {'route': '/xdcfeef34a494fc1c838079fc', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'xa630647036de76383bfa2e6a', 'response_box': 'xfde3f8beffd0746fb7ddc628', 'result_key': 'x0d6fe95b475ce28ffee3d31d'}, 'catalog': {'route': '/x805eac4b12cc8bb06887cfc3', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'x7fe7eea6626afb582a517b4f', 'response_box': 'xb6999dc81f079e99a64eb359', 'result_key': 'x451611f066b787daf9243141'}, 'create_order': {'route': '/x683db0c5133c10755bce980c', 'fields': ['quantity', 'request_id', 'product_id'], 'aliases': {'quantity': 'xb2068105517c75f03eafe96e', 'request_id': 'x14bcdd75d983394efc5cd5e2', 'product_id': 'x407a605e1d7d6e4e42737d31'}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'xae607794981598f82f2d67e7', 'response_box': 'xe024b376e96c4373acdc46b7', 'result_key': 'x3f75732a3e121bf08cb192fa'}, 'order': {'route': '/x6d049fb664afdea33f7534fa', 'fields': ['order_id'], 'aliases': {'order_id': 'x8b966542248451d88876f5e0'}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'xcc66bba3cfaae68288d19c98', 'response_box': 'xe3afe5305dfea3b755b61c5c', 'result_key': 'xd9cf77ed6c56307ddb2855eb'}, 'orders': {'route': '/x509f31dea8596967ee22dd1a', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'xd2b82eae57625fd5503338d7', 'response_box': 'x45ec7b1ca2649a97252a3e58', 'result_key': 'x7940b258961a7b9aad13efa6'}, 'update_product': {'route': '/x794335aa089eb5d59e1ee1fc', 'fields': ['product_id', 'price', 'stock'], 'aliases': {'product_id': 'xc36aec2fd445d133d2b004d5', 'price': 'xb3f4c5c9d63553f4af1d9c7e', 'stock': 'x7dcda874c44264a51c880de1'}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'x3e7157b5eccdbecb5620b228', 'response_box': 'x978b110b10938b93ed4668fe', 'result_key': 'x168b8573f51660e7da5b6710'}}
HANDLERS = {'login': 'xf98339b152568b6b6761b2f2', 'logout': 'x6cd5a6fb2553d34aca381b41', 'catalog': 'x4eee480cc649d3fd8757a74c', 'create_order': 'x9f01d7afa92d6aa4b1cd29c9', 'order': 'x32cfdcd02c1a94c5ca7d2601', 'orders': 'x8a266fc8003881c79c7a30a0', 'update_product': 'x283a2ba334aaec3383faf07f'}
BACKEND_GRAPH = {'xf98339b152568b6b6761b2f2': {'operation': 'login', 'target': 'x189595d54ea550a36774a54f', 'kind': 'adapter'}, 'x189595d54ea550a36774a54f': {'operation': 'login', 'target': 'x0f13d09dd28228c68fa96ff7', 'kind': 'adapter'}, 'x0f13d09dd28228c68fa96ff7': {'operation': 'login', 'target': 'xc8b5acfd57b1b7d128af024e', 'kind': 'adapter'}, 'xc8b5acfd57b1b7d128af024e': {'operation': 'login', 'target': 'x009342aa7373532c4e271efc', 'kind': 'adapter'}, 'x009342aa7373532c4e271efc': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x6cd5a6fb2553d34aca381b41': {'operation': 'logout', 'target': 'xca79db50ed294a7c9045f4a7', 'kind': 'adapter'}, 'xca79db50ed294a7c9045f4a7': {'operation': 'logout', 'target': 'x456335e14855dc77cab73054', 'kind': 'adapter'}, 'x456335e14855dc77cab73054': {'operation': 'logout', 'target': 'x18efe8ee9753ef05e7d07c6b', 'kind': 'adapter'}, 'x18efe8ee9753ef05e7d07c6b': {'operation': 'logout', 'target': 'x152dc0eee2e31a9d6cec8453', 'kind': 'adapter'}, 'x152dc0eee2e31a9d6cec8453': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x4eee480cc649d3fd8757a74c': {'operation': 'catalog', 'target': 'x1113d340ee65e18e7b6a84a3', 'kind': 'adapter'}, 'x1113d340ee65e18e7b6a84a3': {'operation': 'catalog', 'target': 'x1dbd2933a0fcc9098cedc5a1', 'kind': 'adapter'}, 'x1dbd2933a0fcc9098cedc5a1': {'operation': 'catalog', 'target': 'xa6c53ed8b157d3abe0886736', 'kind': 'adapter'}, 'xa6c53ed8b157d3abe0886736': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x9f01d7afa92d6aa4b1cd29c9': {'operation': 'create_order', 'target': 'x113da7b3b051598f9ba2cf9a', 'kind': 'adapter'}, 'x113da7b3b051598f9ba2cf9a': {'operation': 'create_order', 'target': 'xf31738755547da6a9980c73b', 'kind': 'adapter'}, 'xf31738755547da6a9980c73b': {'operation': 'create_order', 'target': 'xf5d92114f47f859c7b2b12d1', 'kind': 'adapter'}, 'xf5d92114f47f859c7b2b12d1': {'operation': 'create_order', 'target': 'xf9c28ea613b4439be64a1303', 'kind': 'adapter'}, 'xf9c28ea613b4439be64a1303': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x32cfdcd02c1a94c5ca7d2601': {'operation': 'order', 'target': 'x4a94668439d7d564bbdd4eed', 'kind': 'adapter'}, 'x4a94668439d7d564bbdd4eed': {'operation': 'order', 'target': 'xc50b99350bb90bc4ce4c09a2', 'kind': 'adapter'}, 'xc50b99350bb90bc4ce4c09a2': {'operation': 'order', 'target': 'xb372985bb31e9f4a1b70f445', 'kind': 'adapter'}, 'xb372985bb31e9f4a1b70f445': {'operation': 'order', 'target': 'x597b31ef28fbcb84ce8f6edb', 'kind': 'adapter'}, 'x597b31ef28fbcb84ce8f6edb': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x8a266fc8003881c79c7a30a0': {'operation': 'orders', 'target': 'xa7bfe86e4e636f475619ceed', 'kind': 'adapter'}, 'xa7bfe86e4e636f475619ceed': {'operation': 'orders', 'target': 'x1c5da4f82d8654a2a8158040', 'kind': 'adapter'}, 'x1c5da4f82d8654a2a8158040': {'operation': 'orders', 'target': 'xbb9afe3966745c58a9505bd6', 'kind': 'adapter'}, 'xbb9afe3966745c58a9505bd6': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x283a2ba334aaec3383faf07f': {'operation': 'update_product', 'target': 'x3647596c694ad33e299e7da8', 'kind': 'adapter'}, 'x3647596c694ad33e299e7da8': {'operation': 'update_product', 'target': 'xe473fc146ab9b4dcd3c7b057', 'kind': 'adapter'}, 'xe473fc146ab9b4dcd3c7b057': {'operation': 'update_product', 'target': 'x08cba979d9010f1f8ac19242', 'kind': 'adapter'}, 'x08cba979d9010f1f8ac19242': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xf98339b152568b6b6761b2f2(core, operation, data, session, actor, trace):
    trace.append('xf98339b152568b6b6761b2f2')
    return x189595d54ea550a36774a54f(core, operation, data, session, actor, trace)

def x189595d54ea550a36774a54f(core, operation, data, session, actor, trace):
    trace.append('x189595d54ea550a36774a54f')
    return x0f13d09dd28228c68fa96ff7(core, operation, data, session, actor, trace)

def x0f13d09dd28228c68fa96ff7(core, operation, data, session, actor, trace):
    trace.append('x0f13d09dd28228c68fa96ff7')
    return xc8b5acfd57b1b7d128af024e(core, operation, data, session, actor, trace)

def xc8b5acfd57b1b7d128af024e(core, operation, data, session, actor, trace):
    trace.append('xc8b5acfd57b1b7d128af024e')
    return x009342aa7373532c4e271efc(core, operation, data, session, actor, trace)

def x009342aa7373532c4e271efc(core, operation, data, session, actor, trace):
    trace.append('x009342aa7373532c4e271efc')
    return core.execute(operation, data, session, actor)

def x6cd5a6fb2553d34aca381b41(core, operation, data, session, actor, trace):
    trace.append('x6cd5a6fb2553d34aca381b41')
    return xca79db50ed294a7c9045f4a7(core, operation, data, session, actor, trace)

def xca79db50ed294a7c9045f4a7(core, operation, data, session, actor, trace):
    trace.append('xca79db50ed294a7c9045f4a7')
    return x456335e14855dc77cab73054(core, operation, data, session, actor, trace)

def x456335e14855dc77cab73054(core, operation, data, session, actor, trace):
    trace.append('x456335e14855dc77cab73054')
    return x18efe8ee9753ef05e7d07c6b(core, operation, data, session, actor, trace)

def x18efe8ee9753ef05e7d07c6b(core, operation, data, session, actor, trace):
    trace.append('x18efe8ee9753ef05e7d07c6b')
    return x152dc0eee2e31a9d6cec8453(core, operation, data, session, actor, trace)

def x152dc0eee2e31a9d6cec8453(core, operation, data, session, actor, trace):
    trace.append('x152dc0eee2e31a9d6cec8453')
    return core.execute(operation, data, session, actor)

def x4eee480cc649d3fd8757a74c(core, operation, data, session, actor, trace):
    trace.append('x4eee480cc649d3fd8757a74c')
    return x1113d340ee65e18e7b6a84a3(core, operation, data, session, actor, trace)

def x1113d340ee65e18e7b6a84a3(core, operation, data, session, actor, trace):
    trace.append('x1113d340ee65e18e7b6a84a3')
    return x1dbd2933a0fcc9098cedc5a1(core, operation, data, session, actor, trace)

def x1dbd2933a0fcc9098cedc5a1(core, operation, data, session, actor, trace):
    trace.append('x1dbd2933a0fcc9098cedc5a1')
    return xa6c53ed8b157d3abe0886736(core, operation, data, session, actor, trace)

def xa6c53ed8b157d3abe0886736(core, operation, data, session, actor, trace):
    trace.append('xa6c53ed8b157d3abe0886736')
    return core.execute(operation, data, session, actor)

def x9f01d7afa92d6aa4b1cd29c9(core, operation, data, session, actor, trace):
    trace.append('x9f01d7afa92d6aa4b1cd29c9')
    return x113da7b3b051598f9ba2cf9a(core, operation, data, session, actor, trace)

def x113da7b3b051598f9ba2cf9a(core, operation, data, session, actor, trace):
    trace.append('x113da7b3b051598f9ba2cf9a')
    return xf31738755547da6a9980c73b(core, operation, data, session, actor, trace)

def xf31738755547da6a9980c73b(core, operation, data, session, actor, trace):
    trace.append('xf31738755547da6a9980c73b')
    return xf5d92114f47f859c7b2b12d1(core, operation, data, session, actor, trace)

def xf5d92114f47f859c7b2b12d1(core, operation, data, session, actor, trace):
    trace.append('xf5d92114f47f859c7b2b12d1')
    return xf9c28ea613b4439be64a1303(core, operation, data, session, actor, trace)

def xf9c28ea613b4439be64a1303(core, operation, data, session, actor, trace):
    trace.append('xf9c28ea613b4439be64a1303')
    return core.execute(operation, data, session, actor)

def x32cfdcd02c1a94c5ca7d2601(core, operation, data, session, actor, trace):
    trace.append('x32cfdcd02c1a94c5ca7d2601')
    return x4a94668439d7d564bbdd4eed(core, operation, data, session, actor, trace)

def x4a94668439d7d564bbdd4eed(core, operation, data, session, actor, trace):
    trace.append('x4a94668439d7d564bbdd4eed')
    return xc50b99350bb90bc4ce4c09a2(core, operation, data, session, actor, trace)

def xc50b99350bb90bc4ce4c09a2(core, operation, data, session, actor, trace):
    trace.append('xc50b99350bb90bc4ce4c09a2')
    return xb372985bb31e9f4a1b70f445(core, operation, data, session, actor, trace)

def xb372985bb31e9f4a1b70f445(core, operation, data, session, actor, trace):
    trace.append('xb372985bb31e9f4a1b70f445')
    return x597b31ef28fbcb84ce8f6edb(core, operation, data, session, actor, trace)

def x597b31ef28fbcb84ce8f6edb(core, operation, data, session, actor, trace):
    trace.append('x597b31ef28fbcb84ce8f6edb')
    return core.execute(operation, data, session, actor)

def x8a266fc8003881c79c7a30a0(core, operation, data, session, actor, trace):
    trace.append('x8a266fc8003881c79c7a30a0')
    return xa7bfe86e4e636f475619ceed(core, operation, data, session, actor, trace)

def xa7bfe86e4e636f475619ceed(core, operation, data, session, actor, trace):
    trace.append('xa7bfe86e4e636f475619ceed')
    return x1c5da4f82d8654a2a8158040(core, operation, data, session, actor, trace)

def x1c5da4f82d8654a2a8158040(core, operation, data, session, actor, trace):
    trace.append('x1c5da4f82d8654a2a8158040')
    return xbb9afe3966745c58a9505bd6(core, operation, data, session, actor, trace)

def xbb9afe3966745c58a9505bd6(core, operation, data, session, actor, trace):
    trace.append('xbb9afe3966745c58a9505bd6')
    return core.execute(operation, data, session, actor)

def x283a2ba334aaec3383faf07f(core, operation, data, session, actor, trace):
    trace.append('x283a2ba334aaec3383faf07f')
    return x3647596c694ad33e299e7da8(core, operation, data, session, actor, trace)

def x3647596c694ad33e299e7da8(core, operation, data, session, actor, trace):
    trace.append('x3647596c694ad33e299e7da8')
    return xe473fc146ab9b4dcd3c7b057(core, operation, data, session, actor, trace)

def xe473fc146ab9b4dcd3c7b057(core, operation, data, session, actor, trace):
    trace.append('xe473fc146ab9b4dcd3c7b057')
    return x08cba979d9010f1f8ac19242(core, operation, data, session, actor, trace)

def x08cba979d9010f1f8ac19242(core, operation, data, session, actor, trace):
    trace.append('x08cba979d9010f1f8ac19242')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def unwrap_request(contract, wire):
    if contract['request_shape'] in ('wrapped', 'pairs'):
        box = contract['request_box']
        if not isinstance(wire, dict) or set(wire) != {box}:
            raise ValueError('box')
        return wire[box]
    return wire

def collect_pairs(wire):
    if not isinstance(wire, list):
        raise ValueError('pairs')
    values = {}
    for pair in wire:
        if not isinstance(pair, list) or len(pair) != 2 or not isinstance(pair[0], str) or pair[0] in values:
            raise ValueError('pair')
        values[pair[0]] = pair[1]
    return values

def project_fields(contract, wire):
    if not isinstance(wire, dict) or set(wire) != set(contract['aliases'].values()):
        raise ValueError('fields')
    values = {}
    for field in contract['fields']:
        values[field] = wire[contract['aliases'][field]]
    return values

def decode(operation, wire):
    contract = CONTRACT[operation]
    source = unwrap_request(contract, wire)
    shape = contract['request_shape']
    if shape == 'positional':
        if not isinstance(source, list) or len(source) != len(contract['fields']):
            raise ValueError('arity')
        return dict(zip(contract['fields'], source))
    if shape == 'pairs':
        source = collect_pairs(source)
    return project_fields(contract, source)

def encode(operation, result):
    contract = CONTRACT[operation]
    shape = contract['response_shape']
    if shape == 'array':
        return [result]
    keys = [contract['result_key']]
    if shape != 'object':
        keys.append(contract['response_box'])
    for key in keys:
        result = {key: result}
    return result

def adapter_result(outcome):
    status, result, cookie, trace = outcome
    return status, result, cookie, trace

def adapter_call(arguments, continuation):
    outcome = ORIGINAL_INVOKE(*arguments)
    return continuation(outcome)

def invoke(handler_name, core, operation, data, session, actor):
    return adapter_call((handler_name, core, operation, data, session, actor), adapter_result)

