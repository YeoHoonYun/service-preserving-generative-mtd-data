import {xcff4b2ab48b81bfa89720e4a,xeae50b028e8e143923f4e9e7,x55f76ccf035ebff7531a33f0} from './x8b4e4c23bea55dd571336ba4.js';
import {xa153782baab2cf105c8da9c8,x8ba2be4b7e39b30fa8182963} from './xdcacf36fef88ccfb7014a897.js';
import {x3b99945e9eea5d7c4f2dff6c,x3fe72cb325f636633c03ae65} from './xddc28a92a8231f6b7cff1945.js';

let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('x01d89d02dbbbf7fa4d80b03a');
const endpoints={login:xcff4b2ab48b81bfa89720e4a,logout:xa153782baab2cf105c8da9c8,catalog:x3b99945e9eea5d7c4f2dff6c,create_order:xeae50b028e8e143923f4e9e7,order:x8ba2be4b7e39b30fa8182963,orders:x3fe72cb325f636633c03ae65,update_product:x55f76ccf035ebff7531a33f0};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('xe602bfb211babe2a810a6339').textContent=boot.user?boot.user.id:'방문자';}

async function drive(flow){
  let step=flow.next();
  while(!step.done){
    const result=await step.value;
    step=flow.next(result);
  }
  return step.value;
}
function run(promise){promise.catch(error=>message.textContent=error.message);}

function* catalogFlow(){
  const list=document.getElementById('xc13127fa363af10c31943023');
  list.replaceChildren();
  const products=yield api('catalog');
  for(const p of products){
    const li=document.createElement('li');
    li.textContent=p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock;
    list.append(li);
  }
  document.body.dataset.ready='yes';
}
function* ordersFlow(){
  const list=document.getElementById('xd94bc4953685d4d4133914a3');
  list.replaceChildren();
  const orders=yield api('orders');
  for(const order of orders){
    const li=document.createElement('li');
    li.textContent=order.id+' · '+order.total+'원';
    list.append(li);
  }
}
function* submissionFlow(form){
  const raw=Object.fromEntries(new FormData(form));
  const data={username:raw['x74546fb6cb2397d393147f87'],password:raw['x09d0d250c3f4e8d87e350070'],product_id:raw['xe40615695eb8efec7e50726f'],quantity:raw['x401ae65e372741ecf6b8b7c9'],price:raw['x206b85f4ef663f5c36d39019'],stock:raw['x87a0457f8f02a93e7a030f57']};
  if(form.dataset.action==='x6d0596188a7a28673ccc4680'){
    boot=yield api('login',data);
    identity();
    message.textContent='로그인되었습니다.';
  }
  if(form.dataset.action==='x53d9df139308ae9e6340fc34'){
    const order=yield api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()});
    message.textContent='주문 '+order.id+' · '+order.total+'원';
    yield drive(catalogFlow());
    yield drive(ordersFlow());
  }
  if(form.dataset.action==='x3114dec4e40976230721b2f8'){
    yield api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)});
    message.textContent='상품을 수정했습니다.';
    yield drive(catalogFlow());
  }
}
function* logoutFlow(){yield api('logout');location.reload();}
function submit(event){event.preventDefault();run(drive(submissionFlow(event.target)));}
document.addEventListener('submit',submit);
document.getElementById('xbbb5881cbedb44fdc6ffdbe4').onclick=()=>run(drive(logoutFlow()));
document.getElementById('xce6b29542345d4416925c4d9').onclick=()=>run(drive(ordersFlow()));
identity();run(drive(catalogFlow()));
