import {send} from './x2b03694fa6fa4fabe8a7fd51.js';
export async function xa153782baab2cf105c8da9c8(data,csrf){const wire={};const value=await send("/xdcfeef34a494fc1c838079fc",wire,csrf);return value["x0d6fe95b475ce28ffee3d31d"];}
export async function x8ba2be4b7e39b30fa8182963(data,csrf){const wire=[data["order_id"]];const value=await send("/x6d049fb664afdea33f7534fa",wire,csrf);return value["xd9cf77ed6c56307ddb2855eb"];}
