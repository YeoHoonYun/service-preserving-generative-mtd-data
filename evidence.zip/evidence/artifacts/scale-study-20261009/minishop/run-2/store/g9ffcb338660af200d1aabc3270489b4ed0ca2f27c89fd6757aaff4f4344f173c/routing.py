GRAPH = {'x8cffaf8c294efa949bff32fd': {'kind': 'router', 'edges': {'/x45cc2cb3587d03e84d4a1644': {'target': 'x2ba5e32cef2211f911f6c043', 'next_key': 'x627e6732622a7fec3015480b'}, '/xdcfeef34a494fc1c838079fc': {'target': 'x82c9b2a3cafe7e9a2dbeeab7', 'next_key': 'x37614425a7372b3d3f755945'}, '/x805eac4b12cc8bb06887cfc3': {'target': 'x2ba5e32cef2211f911f6c043', 'next_key': 'xfada966e240469cd99dca246'}, '/x683db0c5133c10755bce980c': {'target': 'x82c9b2a3cafe7e9a2dbeeab7', 'next_key': 'x65a3b66b8886fcbe2a625ce6'}, '/x6d049fb664afdea33f7534fa': {'target': 'x2ba5e32cef2211f911f6c043', 'next_key': 'x0bec7f2ae7fa3d049a162e40'}, '/x509f31dea8596967ee22dd1a': {'target': 'x82c9b2a3cafe7e9a2dbeeab7', 'next_key': 'xc8d3d9f2cd0193b168bac6d5'}, '/x794335aa089eb5d59e1ee1fc': {'target': 'x2ba5e32cef2211f911f6c043', 'next_key': 'xafe7ef61bea2cd8ea3f59ab5'}}}, 'x82c9b2a3cafe7e9a2dbeeab7': {'kind': 'router', 'edges': {'x37614425a7372b3d3f755945': {'target': 'x9fa27b9e9513997a52590867', 'next_key': 'x65abd664272cfbfb6a983162'}, 'x65a3b66b8886fcbe2a625ce6': {'target': 'x9fa27b9e9513997a52590867', 'next_key': 'x06cbc8a77f42320af30e9ea3'}, 'xc8d3d9f2cd0193b168bac6d5': {'target': 'x9fa27b9e9513997a52590867', 'next_key': 'xf782ad53096fa1c44b11e4cd'}}}, 'x2ba5e32cef2211f911f6c043': {'kind': 'router', 'edges': {'x627e6732622a7fec3015480b': {'target': 'x9fa27b9e9513997a52590867', 'next_key': 'x7192e4893c917523c3d0b3d5'}, 'xfada966e240469cd99dca246': {'target': 'x9fa27b9e9513997a52590867', 'next_key': 'xe5c39dea0a01003846fc54a3'}, 'x0bec7f2ae7fa3d049a162e40': {'target': 'x9fa27b9e9513997a52590867', 'next_key': 'x7a3bd225c4c317d1c134ea0e'}, 'xafe7ef61bea2cd8ea3f59ab5': {'target': 'x9fa27b9e9513997a52590867', 'next_key': 'x47f054d5b8edffde04ef9736'}}}, 'x9fa27b9e9513997a52590867': {'kind': 'router', 'edges': {'x7192e4893c917523c3d0b3d5': {'target': 'x82968f16efaaab31b7b515c6', 'next_key': 'x943f61b856e461a8f0fadaef'}, 'x65abd664272cfbfb6a983162': {'target': 'x82968f16efaaab31b7b515c6', 'next_key': 'x0e8dcab2984a3043678c8ac5'}, 'xe5c39dea0a01003846fc54a3': {'target': 'x82968f16efaaab31b7b515c6', 'next_key': 'x9de93aa91df4221c1af4ebcf'}, 'x06cbc8a77f42320af30e9ea3': {'target': 'x82968f16efaaab31b7b515c6', 'next_key': 'x29a12b38320ce91ee19b9789'}, 'x7a3bd225c4c317d1c134ea0e': {'target': 'x82968f16efaaab31b7b515c6', 'next_key': 'xfcb332358d2e50ceacb1a657'}, 'xf782ad53096fa1c44b11e4cd': {'target': 'x82968f16efaaab31b7b515c6', 'next_key': 'xf06226cf833d937a21e38c30'}, 'x47f054d5b8edffde04ef9736': {'target': 'x82968f16efaaab31b7b515c6', 'next_key': 'x7471a567408f7b0055f78166'}}}, 'x82968f16efaaab31b7b515c6': {'kind': 'router', 'edges': {'x943f61b856e461a8f0fadaef': {'target': 'x3aab15e61eaa7e392998ce67', 'next_key': None}, 'x0e8dcab2984a3043678c8ac5': {'target': 'x2909fa27f407a8328408e491', 'next_key': None}, 'x9de93aa91df4221c1af4ebcf': {'target': 'x4fece13f8634ead1c41c5db8', 'next_key': None}, 'x29a12b38320ce91ee19b9789': {'target': 'x33c9f95ef933c86a3410dee8', 'next_key': None}, 'xfcb332358d2e50ceacb1a657': {'target': 'xe9ed4d92a83f3b7b7d0204de', 'next_key': None}, 'xf06226cf833d937a21e38c30': {'target': 'x43f8e405c4623e3da440a3ca', 'next_key': None}, 'x7471a567408f7b0055f78166': {'target': 'xdda3c11e31d498d14eddb25e', 'next_key': None}}}, 'x3aab15e61eaa7e392998ce67': {'kind': 'service', 'operation': 'login', 'handler': 'xf98339b152568b6b6761b2f2'}, 'x2909fa27f407a8328408e491': {'kind': 'service', 'operation': 'logout', 'handler': 'x6cd5a6fb2553d34aca381b41'}, 'x4fece13f8634ead1c41c5db8': {'kind': 'service', 'operation': 'catalog', 'handler': 'x4eee480cc649d3fd8757a74c'}, 'x33c9f95ef933c86a3410dee8': {'kind': 'service', 'operation': 'create_order', 'handler': 'x9f01d7afa92d6aa4b1cd29c9'}, 'xe9ed4d92a83f3b7b7d0204de': {'kind': 'service', 'operation': 'order', 'handler': 'x32cfdcd02c1a94c5ca7d2601'}, 'x43f8e405c4623e3da440a3ca': {'kind': 'service', 'operation': 'orders', 'handler': 'x8a266fc8003881c79c7a30a0'}, 'xdda3c11e31d498d14eddb25e': {'kind': 'service', 'operation': 'update_product', 'handler': 'x283a2ba334aaec3383faf07f'}}
ENTRY = 'x8cffaf8c294efa949bff32fd'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    rebuilt = {'route_root': {'kind': 'router', 'edges': {}}}
    prefixes = {}
    leaves = {}
    for path in graph[entry]['edges']:
        node, key = entry, path
        visited = set()
        while graph[node]['kind'] != 'service':
            if node in visited:
                raise ValueError('routing cycle')
            visited.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        if node not in leaves:
            leaf = 'route_leaf_' + str(len(leaves))
            leaves[node] = leaf
            rebuilt[leaf] = dict(graph[node])
        prefix, suffix = path[:3], path[3:]
        if prefix not in prefixes:
            branch = 'route_prefix_' + str(len(prefixes))
            prefixes[prefix] = branch
            rebuilt[branch] = {'kind': 'router', 'edges': {}}
        branch = prefixes[prefix]
        rebuilt['route_root']['edges'][path] = {'target': branch, 'next_key': suffix}
        rebuilt[branch]['edges'][suffix] = {'target': leaves[node], 'next_key': None}
    return rebuilt, 'route_root'

def resolve(path):
    node, key = ENTRY, path
    trace, visited = [], set()
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
