import {send} from './x2b03694fa6fa4fabe8a7fd51.js';
export async function x3b99945e9eea5d7c4f2dff6c(data,csrf){const wire={};const value=await send("/x805eac4b12cc8bb06887cfc3",wire,csrf);return value[0];}
export async function x3fe72cb325f636633c03ae65(data,csrf){const wire={"xd2b82eae57625fd5503338d7":[]};const value=await send("/x509f31dea8596967ee22dd1a",wire,csrf);return value["x7940b258961a7b9aad13efa6"];}
