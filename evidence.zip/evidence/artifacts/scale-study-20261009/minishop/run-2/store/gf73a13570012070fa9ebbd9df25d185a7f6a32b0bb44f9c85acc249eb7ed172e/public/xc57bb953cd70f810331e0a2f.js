import {x3d556f60eef6bbe65f127a94,x284859b0537ad1cd2fce9983,x2bb468e7beb511160a12e942} from './x6336e985e747763cfc6e0054.js';
import {x588aef8de72d6e3eeca1baec,xd2333130e13e9c2b0a23a370} from './xb1ac0993716e65963a078f6f.js';
import {xccf5a79befb733bc2743c6ce,xe2a2c19260300685833b5f69} from './xff882506ce360c6e31111832.js';

let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('xe0012cc2d1f7e1a3977ee318');
const endpoints={login:x3d556f60eef6bbe65f127a94,logout:x588aef8de72d6e3eeca1baec,catalog:xccf5a79befb733bc2743c6ce,create_order:x284859b0537ad1cd2fce9983,order:xd2333130e13e9c2b0a23a370,orders:xe2a2c19260300685833b5f69,update_product:x2bb468e7beb511160a12e942};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('xf4891f28493b4c40a4571ce9').textContent=boot.user?boot.user.id:'방문자';}
function run(promise){promise.catch(error=>message.textContent=error.message);}
async function catalog(){
 const list=document.getElementById('x584b875427f3412d4bab633c');
 list.replaceChildren();
 for(const p of await api('catalog')){
  const li=document.createElement('li');
  li.textContent=p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock;
  list.append(li);
 }
 document.body.dataset.ready='yes';
}
async function orders(){
 const list=document.getElementById('x0eb4172c272320ed79483472');
 list.replaceChildren();
 for(const order of await api('orders')){
  const li=document.createElement('li');
  li.textContent=order.id+' · '+order.total+'원';
  list.append(li);
 }
}

function evaluateEffects(graph,root){
 const results=new Map();
 function demand(name){
  if(!results.has(name)){
   const [dependencies,effect]=graph[name];
   const pending=(async()=>{
    const inputs=[];
    for(const dependency of dependencies) inputs.push(await demand(dependency));
    return effect(...inputs);
   })();
   results.set(name,pending);
  }
  return results.get(name);
 }
 return demand(root);
}
async function submitForm(form){
 const raw=Object.fromEntries(new FormData(form));
 const data={username:raw['x526d444cd2c83daa0f4242a4'],password:raw['x7a3e5a1896740ceaf545f410'],product_id:raw['x11ad46572ae43ad5f79b5608'],quantity:raw['xe15de60512d5a78e0b01da9e'],price:raw['xb5d377de049cb94d4baceb4e'],stock:raw['x7e7f11da7f3742c26e4aaa01']};
 const graph={
  loginRequest:[[],()=>api('login',data)],
  loginView:[['loginRequest'],result=>{
   boot=result;
   identity();
   message.textContent='로그인되었습니다.';
  }],
  orderRequest:[[],()=>api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()})],
  orderView:[['orderRequest'],order=>{message.textContent='주문 '+order.id+' · '+order.total+'원';}],
  orderCatalog:[['orderView'],()=>catalog()],
  orderList:[['orderCatalog'],()=>orders()],
  productRequest:[[],()=>api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)})],
  productView:[['productRequest'],()=>{message.textContent='상품을 수정했습니다.';}],
  productCatalog:[['productView'],()=>catalog()]
 };
 if(form.dataset.action==='x7ca2de511b549b46db4c0730') await evaluateEffects(graph,'loginView');
 if(form.dataset.action==='x94d21f2dabc66029faf4c8d2') await evaluateEffects(graph,'orderList');
 if(form.dataset.action==='x326554fd25fac277c29dbe7d') await evaluateEffects(graph,'productCatalog');
}
document.addEventListener('submit',event=>{
 event.preventDefault();
 run(submitForm(event.target));
});
document.getElementById('xd3c31c293e48efaf9602ffba').onclick=()=>run(api('logout').then(()=>location.reload()));
document.getElementById('x9ceabb6ba3c1a5051c65b0b8').onclick=()=>run(orders());
identity();
run(catalog());
