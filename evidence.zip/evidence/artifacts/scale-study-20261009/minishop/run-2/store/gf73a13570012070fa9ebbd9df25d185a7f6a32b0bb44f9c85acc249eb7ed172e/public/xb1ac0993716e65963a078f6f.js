import {send} from './x040efef1faf09ecbd07659f0.js';
export async function x588aef8de72d6e3eeca1baec(data,csrf){const wire={"x5098d443703287b12fc38aa6":{}};const value=await send("/x3978c06488e0d4848b199899",wire,csrf);return value["x8d1e741af22f950e12783f91"]["x5137c8b59a34ed5fe14b6b63"];}
export async function xd2333130e13e9c2b0a23a370(data,csrf){const wire={"x41080b79fbfcd2485943fe49":{"xbfc6d7a4bd45e8e9a66f6571":data["order_id"]}};const value=await send("/x44767e6eb07dea97d736759a",wire,csrf);return value["x78c3fa64b07be2c06ea4f804"];}
