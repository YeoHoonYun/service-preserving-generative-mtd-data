# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x98f119c34037a70d6bea634d', 'fields': ['username', 'password'], 'aliases': {'username': 'x4b2c97d73fb6b1f99cbf67cd', 'password': 'xecb616091d3aa0c9be95aa22'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'xf53d14a75043954a64e3ca4e', 'response_box': 'x6a1d5daf6e4d21b3e4e00111', 'result_key': 'x9c1c356f7837ee7e0d5edf2c'}, 'logout': {'route': '/x3978c06488e0d4848b199899', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'x5098d443703287b12fc38aa6', 'response_box': 'x8d1e741af22f950e12783f91', 'result_key': 'x5137c8b59a34ed5fe14b6b63'}, 'catalog': {'route': '/xa9dfd0d92218a16ac0684dcc', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x46973a49fee1620ef8142e6c', 'response_box': 'x74a8e602fb59ad0673c57b20', 'result_key': 'xde079d70448f09b2625099c5'}, 'create_order': {'route': '/x4143a87ae07f07c6d745b069', 'fields': ['request_id', 'product_id', 'quantity'], 'aliases': {'request_id': 'xe330714726ac4c84872c11d1', 'product_id': 'xd57a2284d16a2a76506226d5', 'quantity': 'x5887ada34e3cf38a8b080638'}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'x00e7e7404d4e6b0019456569', 'response_box': 'x65556cf17a6ec85b9f3b5e0d', 'result_key': 'x4530f44c04fe0f33089abdc2'}, 'order': {'route': '/x44767e6eb07dea97d736759a', 'fields': ['order_id'], 'aliases': {'order_id': 'xbfc6d7a4bd45e8e9a66f6571'}, 'request_shape': 'wrapped', 'response_shape': 'object', 'request_box': 'x41080b79fbfcd2485943fe49', 'response_box': 'xf252c4386210473c2a77cbc5', 'result_key': 'x78c3fa64b07be2c06ea4f804'}, 'orders': {'route': '/xd70c6c033b16ace559ddb7ee', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'xe404a8afbb5a1cbfc65d4081', 'response_box': 'x73afc6df13348e2e7f82fa50', 'result_key': 'x8b727b3df1cd907207400356'}, 'update_product': {'route': '/x502a0c42918dfdb8d2e71af3', 'fields': ['product_id', 'price', 'stock'], 'aliases': {'product_id': 'x620f610fdd57032f3905eef7', 'price': 'xf8de46eb60ec1c78fce55b46', 'stock': 'x55a7e5767827e5281c4c0d59'}, 'request_shape': 'positional', 'response_shape': 'array', 'request_box': 'x1d25f8b501afa4fd2936f398', 'response_box': 'x62fb3dbd23ec279eec0f77a8', 'result_key': 'xbc15f9fe966565473b4f1c56'}}
HANDLERS = {'login': 'x54345e0263ea87be5efaf9f3', 'logout': 'x638a5a66fc81ad4e2a89a750', 'catalog': 'xb32405216591966d08222b23', 'create_order': 'x04663345f39ffba567c54854', 'order': 'x7c33f0f9e435fb1450b0be59', 'orders': 'x4ecb8538ccb125bdd956527d', 'update_product': 'x2dc58e23e60a632a0fb3ad3f'}
BACKEND_GRAPH = {'x54345e0263ea87be5efaf9f3': {'operation': 'login', 'target': 'x8b95a639667eee8d822d2c3c', 'kind': 'adapter'}, 'x8b95a639667eee8d822d2c3c': {'operation': 'login', 'target': 'x3540fdb25b2462b69cc900f9', 'kind': 'adapter'}, 'x3540fdb25b2462b69cc900f9': {'operation': 'login', 'target': 'x2bc8f45fe659b3971de01bdb', 'kind': 'adapter'}, 'x2bc8f45fe659b3971de01bdb': {'operation': 'login', 'target': 'x214bb236bc03ee87a3e32cf9', 'kind': 'adapter'}, 'x214bb236bc03ee87a3e32cf9': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x638a5a66fc81ad4e2a89a750': {'operation': 'logout', 'target': 'x1edf0469387a072fdb71f1c5', 'kind': 'adapter'}, 'x1edf0469387a072fdb71f1c5': {'operation': 'logout', 'target': 'x249c8a26987cf72db690193c', 'kind': 'adapter'}, 'x249c8a26987cf72db690193c': {'operation': 'logout', 'target': 'x6b89aeec57e159b3181f0741', 'kind': 'adapter'}, 'x6b89aeec57e159b3181f0741': {'operation': 'logout', 'target': 'x18959f991621a66976ba4e6a', 'kind': 'adapter'}, 'x18959f991621a66976ba4e6a': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'xb32405216591966d08222b23': {'operation': 'catalog', 'target': 'xebddb3fcc812dc630fb8eed0', 'kind': 'adapter'}, 'xebddb3fcc812dc630fb8eed0': {'operation': 'catalog', 'target': 'x3cbe7eecdb595ee9158abeb3', 'kind': 'adapter'}, 'x3cbe7eecdb595ee9158abeb3': {'operation': 'catalog', 'target': 'x98a4fbb03cb2690bf48d8b04', 'kind': 'adapter'}, 'x98a4fbb03cb2690bf48d8b04': {'operation': 'catalog', 'target': 'xde36a987d1cd1e77c3fbd06a', 'kind': 'adapter'}, 'xde36a987d1cd1e77c3fbd06a': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x04663345f39ffba567c54854': {'operation': 'create_order', 'target': 'xda2ac1d42130b3c46badd048', 'kind': 'adapter'}, 'xda2ac1d42130b3c46badd048': {'operation': 'create_order', 'target': 'xd961a27bc4d1f2bb98a87e94', 'kind': 'adapter'}, 'xd961a27bc4d1f2bb98a87e94': {'operation': 'create_order', 'target': 'xb85c0dd80b80b4f3b947b84b', 'kind': 'adapter'}, 'xb85c0dd80b80b4f3b947b84b': {'operation': 'create_order', 'target': 'x9a35c1a7c16beb5b315093c7', 'kind': 'adapter'}, 'x9a35c1a7c16beb5b315093c7': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x7c33f0f9e435fb1450b0be59': {'operation': 'order', 'target': 'xc5ec7a51623b783c80271b1d', 'kind': 'adapter'}, 'xc5ec7a51623b783c80271b1d': {'operation': 'order', 'target': 'xf9b9ff3f39b5d783959417c9', 'kind': 'adapter'}, 'xf9b9ff3f39b5d783959417c9': {'operation': 'order', 'target': 'xbb39f1e640bcc45dd7c02f0f', 'kind': 'adapter'}, 'xbb39f1e640bcc45dd7c02f0f': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x4ecb8538ccb125bdd956527d': {'operation': 'orders', 'target': 'xd0ae6d887eccc99b154168c3', 'kind': 'adapter'}, 'xd0ae6d887eccc99b154168c3': {'operation': 'orders', 'target': 'x5020870c61683601b54eed29', 'kind': 'adapter'}, 'x5020870c61683601b54eed29': {'operation': 'orders', 'target': 'x352c219166b19c823b2b9430', 'kind': 'adapter'}, 'x352c219166b19c823b2b9430': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x2dc58e23e60a632a0fb3ad3f': {'operation': 'update_product', 'target': 'xf4c704f376a5bb795ed3b3c5', 'kind': 'adapter'}, 'xf4c704f376a5bb795ed3b3c5': {'operation': 'update_product', 'target': 'xa51176bb053da3a54b145d07', 'kind': 'adapter'}, 'xa51176bb053da3a54b145d07': {'operation': 'update_product', 'target': 'x1f020c7993cfac7da299d71d', 'kind': 'adapter'}, 'x1f020c7993cfac7da299d71d': {'operation': 'update_product', 'target': 'x4ac6c31639756aaf57482f17', 'kind': 'adapter'}, 'x4ac6c31639756aaf57482f17': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def x54345e0263ea87be5efaf9f3(core, operation, data, session, actor, trace):
    trace.append('x54345e0263ea87be5efaf9f3')
    return x8b95a639667eee8d822d2c3c(core, operation, data, session, actor, trace)

def x8b95a639667eee8d822d2c3c(core, operation, data, session, actor, trace):
    trace.append('x8b95a639667eee8d822d2c3c')
    return x3540fdb25b2462b69cc900f9(core, operation, data, session, actor, trace)

def x3540fdb25b2462b69cc900f9(core, operation, data, session, actor, trace):
    trace.append('x3540fdb25b2462b69cc900f9')
    return x2bc8f45fe659b3971de01bdb(core, operation, data, session, actor, trace)

def x2bc8f45fe659b3971de01bdb(core, operation, data, session, actor, trace):
    trace.append('x2bc8f45fe659b3971de01bdb')
    return x214bb236bc03ee87a3e32cf9(core, operation, data, session, actor, trace)

def x214bb236bc03ee87a3e32cf9(core, operation, data, session, actor, trace):
    trace.append('x214bb236bc03ee87a3e32cf9')
    return core.execute(operation, data, session, actor)

def x638a5a66fc81ad4e2a89a750(core, operation, data, session, actor, trace):
    trace.append('x638a5a66fc81ad4e2a89a750')
    return x1edf0469387a072fdb71f1c5(core, operation, data, session, actor, trace)

def x1edf0469387a072fdb71f1c5(core, operation, data, session, actor, trace):
    trace.append('x1edf0469387a072fdb71f1c5')
    return x249c8a26987cf72db690193c(core, operation, data, session, actor, trace)

def x249c8a26987cf72db690193c(core, operation, data, session, actor, trace):
    trace.append('x249c8a26987cf72db690193c')
    return x6b89aeec57e159b3181f0741(core, operation, data, session, actor, trace)

def x6b89aeec57e159b3181f0741(core, operation, data, session, actor, trace):
    trace.append('x6b89aeec57e159b3181f0741')
    return x18959f991621a66976ba4e6a(core, operation, data, session, actor, trace)

def x18959f991621a66976ba4e6a(core, operation, data, session, actor, trace):
    trace.append('x18959f991621a66976ba4e6a')
    return core.execute(operation, data, session, actor)

def xb32405216591966d08222b23(core, operation, data, session, actor, trace):
    trace.append('xb32405216591966d08222b23')
    return xebddb3fcc812dc630fb8eed0(core, operation, data, session, actor, trace)

def xebddb3fcc812dc630fb8eed0(core, operation, data, session, actor, trace):
    trace.append('xebddb3fcc812dc630fb8eed0')
    return x3cbe7eecdb595ee9158abeb3(core, operation, data, session, actor, trace)

def x3cbe7eecdb595ee9158abeb3(core, operation, data, session, actor, trace):
    trace.append('x3cbe7eecdb595ee9158abeb3')
    return x98a4fbb03cb2690bf48d8b04(core, operation, data, session, actor, trace)

def x98a4fbb03cb2690bf48d8b04(core, operation, data, session, actor, trace):
    trace.append('x98a4fbb03cb2690bf48d8b04')
    return xde36a987d1cd1e77c3fbd06a(core, operation, data, session, actor, trace)

def xde36a987d1cd1e77c3fbd06a(core, operation, data, session, actor, trace):
    trace.append('xde36a987d1cd1e77c3fbd06a')
    return core.execute(operation, data, session, actor)

def x04663345f39ffba567c54854(core, operation, data, session, actor, trace):
    trace.append('x04663345f39ffba567c54854')
    return xda2ac1d42130b3c46badd048(core, operation, data, session, actor, trace)

def xda2ac1d42130b3c46badd048(core, operation, data, session, actor, trace):
    trace.append('xda2ac1d42130b3c46badd048')
    return xd961a27bc4d1f2bb98a87e94(core, operation, data, session, actor, trace)

def xd961a27bc4d1f2bb98a87e94(core, operation, data, session, actor, trace):
    trace.append('xd961a27bc4d1f2bb98a87e94')
    return xb85c0dd80b80b4f3b947b84b(core, operation, data, session, actor, trace)

def xb85c0dd80b80b4f3b947b84b(core, operation, data, session, actor, trace):
    trace.append('xb85c0dd80b80b4f3b947b84b')
    return x9a35c1a7c16beb5b315093c7(core, operation, data, session, actor, trace)

def x9a35c1a7c16beb5b315093c7(core, operation, data, session, actor, trace):
    trace.append('x9a35c1a7c16beb5b315093c7')
    return core.execute(operation, data, session, actor)

def x7c33f0f9e435fb1450b0be59(core, operation, data, session, actor, trace):
    trace.append('x7c33f0f9e435fb1450b0be59')
    return xc5ec7a51623b783c80271b1d(core, operation, data, session, actor, trace)

def xc5ec7a51623b783c80271b1d(core, operation, data, session, actor, trace):
    trace.append('xc5ec7a51623b783c80271b1d')
    return xf9b9ff3f39b5d783959417c9(core, operation, data, session, actor, trace)

def xf9b9ff3f39b5d783959417c9(core, operation, data, session, actor, trace):
    trace.append('xf9b9ff3f39b5d783959417c9')
    return xbb39f1e640bcc45dd7c02f0f(core, operation, data, session, actor, trace)

def xbb39f1e640bcc45dd7c02f0f(core, operation, data, session, actor, trace):
    trace.append('xbb39f1e640bcc45dd7c02f0f')
    return core.execute(operation, data, session, actor)

def x4ecb8538ccb125bdd956527d(core, operation, data, session, actor, trace):
    trace.append('x4ecb8538ccb125bdd956527d')
    return xd0ae6d887eccc99b154168c3(core, operation, data, session, actor, trace)

def xd0ae6d887eccc99b154168c3(core, operation, data, session, actor, trace):
    trace.append('xd0ae6d887eccc99b154168c3')
    return x5020870c61683601b54eed29(core, operation, data, session, actor, trace)

def x5020870c61683601b54eed29(core, operation, data, session, actor, trace):
    trace.append('x5020870c61683601b54eed29')
    return x352c219166b19c823b2b9430(core, operation, data, session, actor, trace)

def x352c219166b19c823b2b9430(core, operation, data, session, actor, trace):
    trace.append('x352c219166b19c823b2b9430')
    return core.execute(operation, data, session, actor)

def x2dc58e23e60a632a0fb3ad3f(core, operation, data, session, actor, trace):
    trace.append('x2dc58e23e60a632a0fb3ad3f')
    return xf4c704f376a5bb795ed3b3c5(core, operation, data, session, actor, trace)

def xf4c704f376a5bb795ed3b3c5(core, operation, data, session, actor, trace):
    trace.append('xf4c704f376a5bb795ed3b3c5')
    return xa51176bb053da3a54b145d07(core, operation, data, session, actor, trace)

def xa51176bb053da3a54b145d07(core, operation, data, session, actor, trace):
    trace.append('xa51176bb053da3a54b145d07')
    return x1f020c7993cfac7da299d71d(core, operation, data, session, actor, trace)

def x1f020c7993cfac7da299d71d(core, operation, data, session, actor, trace):
    trace.append('x1f020c7993cfac7da299d71d')
    return x4ac6c31639756aaf57482f17(core, operation, data, session, actor, trace)

def x4ac6c31639756aaf57482f17(core, operation, data, session, actor, trace):
    trace.append('x4ac6c31639756aaf57482f17')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def drain_adapter_jobs(jobs):
    completed = []
    cursor = 0
    while cursor < len(jobs):
        handler_name, core, operation, data, session, actor = jobs[cursor]
        completed.append(ORIGINAL_INVOKE(handler_name, core, operation, data, session, actor))
        cursor += 1
    return completed

def invoke(handler_name, core, operation, data, session, actor):
    pending = [(handler_name, core, operation, data, session, actor)]
    return drain_adapter_jobs(pending)[0]

