import {send} from './x040efef1faf09ecbd07659f0.js';
export async function xccf5a79befb733bc2743c6ce(data,csrf){const wire={};const value=await send("/xa9dfd0d92218a16ac0684dcc",wire,csrf);return value["xde079d70448f09b2625099c5"];}
export async function xe2a2c19260300685833b5f69(data,csrf){const wire=[];const value=await send("/xd70c6c033b16ace559ddb7ee",wire,csrf);return value["x8b727b3df1cd907207400356"];}
