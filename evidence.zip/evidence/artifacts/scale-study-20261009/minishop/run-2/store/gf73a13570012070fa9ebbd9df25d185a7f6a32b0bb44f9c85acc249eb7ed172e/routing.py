GRAPH = {'xe460f619ab8fb01f5f8d4d92': {'kind': 'router', 'edges': {'/x98f119c34037a70d6bea634d': {'target': 'x837eb787398043e48baed74f', 'next_key': 'x25d98bef7293e90754719fc0'}, '/x3978c06488e0d4848b199899': {'target': 'x837eb787398043e48baed74f', 'next_key': 'xb06bf3afda1174c8ce2bb2fb'}, '/xa9dfd0d92218a16ac0684dcc': {'target': 'x837eb787398043e48baed74f', 'next_key': 'x1539d1f76e9e8df08cdbe72b'}, '/x4143a87ae07f07c6d745b069': {'target': 'x837eb787398043e48baed74f', 'next_key': 'xc320fc85da42b1b9b92829e2'}, '/x44767e6eb07dea97d736759a': {'target': 'x837eb787398043e48baed74f', 'next_key': 'x224ccda9f500dd63492d9a2a'}, '/xd70c6c033b16ace559ddb7ee': {'target': 'x837eb787398043e48baed74f', 'next_key': 'x7750cb4d749d85b26cf2d059'}, '/x502a0c42918dfdb8d2e71af3': {'target': 'x837eb787398043e48baed74f', 'next_key': 'x00b99bf78ebcd91100228da0'}}}, 'x837eb787398043e48baed74f': {'kind': 'router', 'edges': {'x25d98bef7293e90754719fc0': {'target': 'x522778cdbcd73fccff4d0095', 'next_key': 'x69f4c318bc9ab3d98f147520'}, 'xb06bf3afda1174c8ce2bb2fb': {'target': 'xfd8015ac5eb354ecbfae318d', 'next_key': 'x6d4d9baa275a695ebd6290be'}, 'x1539d1f76e9e8df08cdbe72b': {'target': 'x522778cdbcd73fccff4d0095', 'next_key': 'x80700798bb6feb77fbe4fa0e'}, 'xc320fc85da42b1b9b92829e2': {'target': 'xfd8015ac5eb354ecbfae318d', 'next_key': 'x57569dabb003f799f3fd576d'}, 'x224ccda9f500dd63492d9a2a': {'target': 'x522778cdbcd73fccff4d0095', 'next_key': 'x93a2b251e79e14fdfd142fc6'}, 'x7750cb4d749d85b26cf2d059': {'target': 'xfd8015ac5eb354ecbfae318d', 'next_key': 'x0c921b4e3f7e75c7d6525d06'}, 'x00b99bf78ebcd91100228da0': {'target': 'x522778cdbcd73fccff4d0095', 'next_key': 'x7faf0e6c9984121a794747a9'}}}, 'x522778cdbcd73fccff4d0095': {'kind': 'router', 'edges': {'x69f4c318bc9ab3d98f147520': {'target': 'xf34187e0d1dafec61aebd678', 'next_key': 'x9817779148b4e0b8d49f7997'}, 'x80700798bb6feb77fbe4fa0e': {'target': 'xf34187e0d1dafec61aebd678', 'next_key': 'xad17ecf760d6d32cee557a7e'}, 'x93a2b251e79e14fdfd142fc6': {'target': 'xf34187e0d1dafec61aebd678', 'next_key': 'xb16d63272dfe91cd2d34091a'}, 'x7faf0e6c9984121a794747a9': {'target': 'xf34187e0d1dafec61aebd678', 'next_key': 'x197018704a3dbe4852bea26c'}}}, 'xfd8015ac5eb354ecbfae318d': {'kind': 'router', 'edges': {'x6d4d9baa275a695ebd6290be': {'target': 'x97a74b003bb41d393902e57e', 'next_key': 'xfcaa8bcb989219cb8d4a303c'}, 'x57569dabb003f799f3fd576d': {'target': 'x97a74b003bb41d393902e57e', 'next_key': 'x919c12e6baa4c42ec7279910'}, 'x0c921b4e3f7e75c7d6525d06': {'target': 'x97a74b003bb41d393902e57e', 'next_key': 'x2a5766a70db32d2863dcdd57'}}}, 'x97a74b003bb41d393902e57e': {'kind': 'router', 'edges': {'xfcaa8bcb989219cb8d4a303c': {'target': 'x15abaa2b90dd31818abc6f51', 'next_key': None}, 'x919c12e6baa4c42ec7279910': {'target': 'xcc80502a5e084dc58632e1d8', 'next_key': None}, 'x2a5766a70db32d2863dcdd57': {'target': 'x3d81671ec95c96d1e7d4fd79', 'next_key': None}}}, 'xf34187e0d1dafec61aebd678': {'kind': 'router', 'edges': {'x9817779148b4e0b8d49f7997': {'target': 'xd6fa7edab876015917e9f58d', 'next_key': None}, 'xad17ecf760d6d32cee557a7e': {'target': 'x16c85362dc6e0a8b5f22507c', 'next_key': None}, 'xb16d63272dfe91cd2d34091a': {'target': 'x7143681a13412b39d28c1b97', 'next_key': None}, 'x197018704a3dbe4852bea26c': {'target': 'x9ee9e9d76fda9f93a80263da', 'next_key': None}}}, 'xd6fa7edab876015917e9f58d': {'kind': 'service', 'operation': 'login', 'handler': 'x54345e0263ea87be5efaf9f3'}, 'x15abaa2b90dd31818abc6f51': {'kind': 'service', 'operation': 'logout', 'handler': 'x638a5a66fc81ad4e2a89a750'}, 'x16c85362dc6e0a8b5f22507c': {'kind': 'service', 'operation': 'catalog', 'handler': 'xb32405216591966d08222b23'}, 'xcc80502a5e084dc58632e1d8': {'kind': 'service', 'operation': 'create_order', 'handler': 'x04663345f39ffba567c54854'}, 'x7143681a13412b39d28c1b97': {'kind': 'service', 'operation': 'order', 'handler': 'x7c33f0f9e435fb1450b0be59'}, 'x3d81671ec95c96d1e7d4fd79': {'kind': 'service', 'operation': 'orders', 'handler': 'x4ecb8538ccb125bdd956527d'}, 'x9ee9e9d76fda9f93a80263da': {'kind': 'service', 'operation': 'update_product', 'handler': 'x2dc58e23e60a632a0fb3ad3f'}}
ENTRY = 'xe460f619ab8fb01f5f8d4d92'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    bindings = []
    rebuilt = {'route_entry': {'kind': 'router', 'edges': {}}}
    for path in graph[entry]['edges']:
        node, key = entry, path
        visited = set()
        while graph[node]['kind'] != 'service':
            if node in visited:
                raise ValueError('routing cycle')
            visited.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        bindings.append((path, node))
        rebuilt[node] = dict(graph[node])
    for start in range(0, len(bindings), 2):
        gate = 'route_gate_' + str(start // 2)
        edges = {}
        for index in range(start, len(bindings)):
            path, leaf = bindings[index]
            if index < start + 2:
                edges[path] = {'target': leaf, 'next_key': None}
            else:
                edges[path] = {'target': 'route_gate_' + str(start // 2 + 1), 'next_key': path}
        rebuilt[gate] = {'kind': 'router', 'edges': edges}
    for path, leaf in bindings:
        rebuilt['route_entry']['edges'][path] = {'target': 'route_gate_0', 'next_key': path}
    return rebuilt, 'route_entry'

def resolve(path):
    current, key = ENTRY, path
    visited, trace = set(), []
    while current not in visited:
        visited.add(current)
        trace.append(current)
        record = GRAPH[current]
        if record['kind'] == 'service':
            return record['operation'], record['handler'], trace
        transition = record['edges'][key]
        current, key = transition['target'], transition['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
