GRAPH = {'x746502bccba354e22a43b73a': {'kind': 'router', 'edges': {'/xa12c6a0e03120ce732370842': {'target': 'xec27d4e6a41aaf7f97151730', 'next_key': 'xe931fc070b17a62b805a9515'}, '/x9006049ee6b4951bd537d210': {'target': 'xec27d4e6a41aaf7f97151730', 'next_key': 'xaaad924b809d837fbed53032'}, '/x5009dc5cba7adb1ad6a01422': {'target': 'xec27d4e6a41aaf7f97151730', 'next_key': 'x4ed082e292e17fefbca8fd63'}, '/xa7de0c52708493e48cd8f11a': {'target': 'xec27d4e6a41aaf7f97151730', 'next_key': 'x4eb03bdd0fa6a3cbde91dada'}, '/x1d8811d42e883b1195def865': {'target': 'xec27d4e6a41aaf7f97151730', 'next_key': 'xa5e163e4124121269287a230'}, '/x0ed975ddb416a6ff136c64a1': {'target': 'xec27d4e6a41aaf7f97151730', 'next_key': 'xd24ee32a067dc110f61dd59d'}, '/xe38c0d10f076f32df74b5f40': {'target': 'xec27d4e6a41aaf7f97151730', 'next_key': 'xcc4caa98776c38a5cad44350'}}}, 'xec27d4e6a41aaf7f97151730': {'kind': 'router', 'edges': {'xe931fc070b17a62b805a9515': {'target': 'xb3eacdba7b4ed1534ca15da7', 'next_key': 'xb8b7865c8f77514980fdb524'}, 'xaaad924b809d837fbed53032': {'target': 'xb3eacdba7b4ed1534ca15da7', 'next_key': 'x1523dbf1fb9074b619c111b8'}, 'x4ed082e292e17fefbca8fd63': {'target': 'xb3eacdba7b4ed1534ca15da7', 'next_key': 'x0766143b5b4bb4efd2114c78'}, 'x4eb03bdd0fa6a3cbde91dada': {'target': 'xb3eacdba7b4ed1534ca15da7', 'next_key': 'x1aa975d93adbcda5a6ef5a8f'}, 'xa5e163e4124121269287a230': {'target': 'xb3eacdba7b4ed1534ca15da7', 'next_key': 'x656d597a16c2fe2dd6f36d9c'}, 'xd24ee32a067dc110f61dd59d': {'target': 'xb3eacdba7b4ed1534ca15da7', 'next_key': 'x7d8d516f806ecd196d24923c'}, 'xcc4caa98776c38a5cad44350': {'target': 'xb3eacdba7b4ed1534ca15da7', 'next_key': 'x6087a36053506e6768105a64'}}}, 'xb3eacdba7b4ed1534ca15da7': {'kind': 'router', 'edges': {'xb8b7865c8f77514980fdb524': {'target': 'xd75d8fd2e97c8ac1bf88416c', 'next_key': 'x529b491dfe7290adec96c40c'}, 'x1523dbf1fb9074b619c111b8': {'target': 'xd75d8fd2e97c8ac1bf88416c', 'next_key': 'x24c37643ee9743b0e7594aeb'}, 'x0766143b5b4bb4efd2114c78': {'target': 'xd75d8fd2e97c8ac1bf88416c', 'next_key': 'x4dcdae76c082dad10e30cce6'}, 'x1aa975d93adbcda5a6ef5a8f': {'target': 'xd75d8fd2e97c8ac1bf88416c', 'next_key': 'xc9080748dbcf3e7c0a283ea5'}, 'x656d597a16c2fe2dd6f36d9c': {'target': 'xd75d8fd2e97c8ac1bf88416c', 'next_key': 'xd6ac12f5fd05699bfa158401'}, 'x7d8d516f806ecd196d24923c': {'target': 'xd75d8fd2e97c8ac1bf88416c', 'next_key': 'xe47f36eee70b073b83fd0296'}, 'x6087a36053506e6768105a64': {'target': 'xd75d8fd2e97c8ac1bf88416c', 'next_key': 'x5309eaeaade6af4167502a85'}}}, 'xd75d8fd2e97c8ac1bf88416c': {'kind': 'router', 'edges': {'x529b491dfe7290adec96c40c': {'target': 'x3ccfd15aee5d9effcdf15d98', 'next_key': 'x8c28a9a85ee94ca2e49f51c5'}, 'x24c37643ee9743b0e7594aeb': {'target': 'x6513ae146c013b6ac9252761', 'next_key': 'xa09b3116e3fbabddcd2fd48e'}, 'x4dcdae76c082dad10e30cce6': {'target': 'x3ccfd15aee5d9effcdf15d98', 'next_key': 'x45c34cbf248223dc229bd99b'}, 'xc9080748dbcf3e7c0a283ea5': {'target': 'x6513ae146c013b6ac9252761', 'next_key': 'xb9527b6dd101b20dbf56860d'}, 'xd6ac12f5fd05699bfa158401': {'target': 'x3ccfd15aee5d9effcdf15d98', 'next_key': 'xf722968ac288ade4a3820180'}, 'xe47f36eee70b073b83fd0296': {'target': 'x6513ae146c013b6ac9252761', 'next_key': 'x89ea90ac78eef8ac9ef231ce'}, 'x5309eaeaade6af4167502a85': {'target': 'x3ccfd15aee5d9effcdf15d98', 'next_key': 'xee26276593cd218ec708dc24'}}}, 'x3ccfd15aee5d9effcdf15d98': {'kind': 'router', 'edges': {'x8c28a9a85ee94ca2e49f51c5': {'target': 'x8fc6f991c7bfdb814576b066', 'next_key': None}, 'x45c34cbf248223dc229bd99b': {'target': 'x08588a885b9cb58df952c154', 'next_key': None}, 'xf722968ac288ade4a3820180': {'target': 'x4daed9fb91c059cc0d751d26', 'next_key': None}, 'xee26276593cd218ec708dc24': {'target': 'xc4b944f78681f65a7cfda912', 'next_key': None}}}, 'x6513ae146c013b6ac9252761': {'kind': 'router', 'edges': {'xa09b3116e3fbabddcd2fd48e': {'target': 'xa80a745ba27b12c4e4ca7241', 'next_key': None}, 'xb9527b6dd101b20dbf56860d': {'target': 'x75e5f11cde276665ddf343f8', 'next_key': None}, 'x89ea90ac78eef8ac9ef231ce': {'target': 'xf4d1b56ec5ee83db633ad841', 'next_key': None}}}, 'x8fc6f991c7bfdb814576b066': {'kind': 'service', 'operation': 'login', 'handler': 'x1674831d5a0c4acd14511ae8'}, 'xa80a745ba27b12c4e4ca7241': {'kind': 'service', 'operation': 'logout', 'handler': 'x7be08ef748c24d54b21eff3c'}, 'x08588a885b9cb58df952c154': {'kind': 'service', 'operation': 'catalog', 'handler': 'x26f63a67af625d3d21eba4ef'}, 'x75e5f11cde276665ddf343f8': {'kind': 'service', 'operation': 'create_order', 'handler': 'xb28849f1155c2517f3c4e202'}, 'x4daed9fb91c059cc0d751d26': {'kind': 'service', 'operation': 'order', 'handler': 'xe819899afae0b5808da8febc'}, 'xf4d1b56ec5ee83db633ad841': {'kind': 'service', 'operation': 'orders', 'handler': 'x4052274a07f16587dda9d966'}, 'xc4b944f78681f65a7cfda912': {'kind': 'service', 'operation': 'update_product', 'handler': 'x717ac0633453c4f8e31b6a89'}}
ENTRY = 'x746502bccba354e22a43b73a'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def routing_cluster(records, rebuilt, source):
    name = 'route_cluster_' + str(len(rebuilt))
    while name in source or name in rebuilt:
        name += '_r'
    edges = {}
    rebuilt[name] = {'kind': 'router', 'edges': edges}
    if len(records) == 1:
        path, leaf, handler = records[0]
        edges[path] = {'target': leaf, 'next_key': None}
        return name
    if not records:
        return name
    best = {}
    width = max(len(record[2]) for record in records)
    for column in range(width):
        groups = {}
        for record in records:
            token = record[2][column:column + 1]
            groups.setdefault(token, []).append(record)
        if len(groups) > len(best):
            best = groups
    if len(best) < 2:
        middle = len(records) // 2
        best = {'left': records[:middle], 'right': records[middle:]}
    for group in best.values():
        child = routing_cluster(group, rebuilt, source)
        for path, leaf, handler in group:
            edges[path] = {'target': child, 'next_key': path}
    return name

def rewrite_graph(graph, entry):
    records = []
    rebuilt = {}
    for path in graph[entry]['edges']:
        node, key = entry, path
        seen = set()
        while graph[node]['kind'] != 'service':
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        rebuilt[node] = dict(graph[node])
        records.append((path, node, graph[node]['handler']))
    root = routing_cluster(records, rebuilt, graph)
    return rebuilt, root

def resolve(path):
    node, key = ENTRY, path
    trace, visited = [], set()
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
