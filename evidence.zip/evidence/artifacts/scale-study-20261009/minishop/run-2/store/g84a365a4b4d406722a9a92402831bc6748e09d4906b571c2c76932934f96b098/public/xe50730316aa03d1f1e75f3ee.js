import {xe0e53ccae6abdbb548be1a00,xe82e13cd692223351902cc93} from './x056518ea146f4c524bfba26b.js';
import {x81806c04c5f45c3abf243ae7,x3443e2b540dc3e999819a814} from './x8dd66906f20d4b61085d151c.js';
import {xfd310f5f8e57902981edf87a,x678e6098ec6aaa72fd87ef57} from './xccad4f36d3a91e179fc5faf2.js';
import {xeaf5703f37dfa1299ebf7812} from './x9bd848f680f22c7112e88b0b.js';

let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('xc97e17e4048f01dc35e9196f');
const endpoints={login:xe0e53ccae6abdbb548be1a00,logout:x81806c04c5f45c3abf243ae7,catalog:xfd310f5f8e57902981edf87a,create_order:xeaf5703f37dfa1299ebf7812,order:xe82e13cd692223351902cc93,orders:x3443e2b540dc3e999819a814,update_product:x678e6098ec6aaa72fd87ef57};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('x868bafdfa6f53780cd426a3c').textContent=boot.user?boot.user.id:'방문자';}
function run(promise){promise.catch(error=>message.textContent=error.message);}

function commandFrom(event){
  if(event.type!=='submit'){
    return {kind:event.currentTarget.id==='xb2f6d55e5dbfc617711f68f2'?'logout':'orders'};
  }
  const form=event.target;
  const raw=Object.fromEntries(new FormData(form));
  return {kind:form.dataset.action,data:{
    username:raw['xbb779402d11ac03e533e1495'],
    password:raw['x621ab523c0fc05898782dc3a'],
    product_id:raw['xa4eafba9a871d6c3fdb6b279'],
    quantity:raw['x86e03ea13cc7d0230afbf4e8'],
    price:raw['x19bb5078c28893192344d3e8'],
    stock:raw['xf8f37b33b793b3f68fe2f58a']
  }};
}

async function execute(command){
  const data=command.data;
  switch(command.kind){
    case 'x2bfb12c0de359a26a04b3eca':
      return api('login',data).then(result=>{
        boot=result;
        identity();
        message.textContent='로그인되었습니다.';
      });
    case 'xb71966c48293b8cdabb0a704':
      return api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()})
        .then(order=>{
          message.textContent='주문 '+order.id+' · '+order.total+'원';
          return execute({kind:'catalog'});
        })
        .then(()=>execute({kind:'orders'}));
    case 'x1231e706fec9a5b1cb6126b1':
      return api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)})
        .then(()=>{
          message.textContent='상품을 수정했습니다.';
          return execute({kind:'catalog'});
        });
    case 'logout':
      return api('logout').then(()=>location.reload());
    case 'catalog':{
      const list=document.getElementById('x59df79187b492fcfc47af1c7');
      list.replaceChildren();
      return api('catalog').then(products=>{
        for(const p of products){
          const li=document.createElement('li');
          li.textContent=p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock;
          list.append(li);
        }
        document.body.dataset.ready='yes';
      });
    }
    case 'orders':{
      const list=document.getElementById('x81b38e7e3b3bed0cef2a67fb');
      list.replaceChildren();
      return api('orders').then(orders=>{
        for(const order of orders){
          const li=document.createElement('li');
          li.textContent=order.id+' · '+order.total+'원';
          list.append(li);
        }
      });
    }
  }
}

function receive(event){
  if(event.type==='submit')event.preventDefault();
  run((async()=>execute(commandFrom(event)))());
}
document.addEventListener('submit',receive);
document.getElementById('xb2f6d55e5dbfc617711f68f2').onclick=receive;
document.getElementById('x7c54b25d5c960a96d7751408').onclick=receive;
identity();
run(execute({kind:'catalog'}));
