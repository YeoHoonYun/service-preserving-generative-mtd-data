import {send} from './x9d1541c369e9d0a2782e4034.js';
export async function xeaf5703f37dfa1299ebf7812(data,csrf){const wire={"x044fbe2e854676e6c8c13e91":{"xd07742d2f51779a25c9cb85c":data["product_id"],"xb4743c0fddb3cef2e6de4313":data["quantity"],"xfa1abbc234195252307f44bd":data["request_id"]}};const value=await send("/xa7de0c52708493e48cd8f11a",wire,csrf);return value[0];}
