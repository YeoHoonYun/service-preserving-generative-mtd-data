# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/xa12c6a0e03120ce732370842', 'fields': ['username', 'password'], 'aliases': {'username': 'x9086a8eb3437e0bef49495b4', 'password': 'x296367e7d05dea75f95c3a65'}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'x56abce063de2298faae481d8', 'response_box': 'x9f3e8984b49b3567b96fa2f3', 'result_key': 'x4270e1e9787d4ad142591527'}, 'logout': {'route': '/x9006049ee6b4951bd537d210', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'array', 'request_box': 'x91014be6c3e54ba40fc842e5', 'response_box': 'x3b464a78855d0e6a2b3aa8c4', 'result_key': 'x6fda8e6cc9a2508e53b675eb'}, 'catalog': {'route': '/x5009dc5cba7adb1ad6a01422', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'xaf49004b61b0c4c1817ff804', 'response_box': 'xad446274dc7fe5a1ae0b8a92', 'result_key': 'x6f1b275c10eb99e58d9d7dd4'}, 'create_order': {'route': '/xa7de0c52708493e48cd8f11a', 'fields': ['product_id', 'quantity', 'request_id'], 'aliases': {'product_id': 'xd07742d2f51779a25c9cb85c', 'quantity': 'xb4743c0fddb3cef2e6de4313', 'request_id': 'xfa1abbc234195252307f44bd'}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x044fbe2e854676e6c8c13e91', 'response_box': 'x9d3587cf71cf017aaeff7a5c', 'result_key': 'xfed2c46538b6b3f28aa402de'}, 'order': {'route': '/x1d8811d42e883b1195def865', 'fields': ['order_id'], 'aliases': {'order_id': 'xdd4383e652a23f14acf495d1'}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'xc72fa542800b3e12a3940ad7', 'response_box': 'x44348fe27eef123712bb7feb', 'result_key': 'x22d5d9ab3600ef345fcb68cd'}, 'orders': {'route': '/x0ed975ddb416a6ff136c64a1', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x79f71096733f73300f6a2c12', 'response_box': 'xab287d2b05c20507aa93d6c3', 'result_key': 'xea646d8c32308f606cdcd8f8'}, 'update_product': {'route': '/xe38c0d10f076f32df74b5f40', 'fields': ['product_id', 'stock', 'price'], 'aliases': {'product_id': 'x76f0e985c5c2b4f911a8dbb6', 'stock': 'x0063d1808dbd8d0a37c47a41', 'price': 'x7a04d57e7ca6dde6c8c595e4'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x7d12b3d7572642636dfbc7a4', 'response_box': 'xe79b2fbc096592464b30759c', 'result_key': 'x96516577955b0c7f7fe9f687'}}
HANDLERS = {'login': 'x1674831d5a0c4acd14511ae8', 'logout': 'x7be08ef748c24d54b21eff3c', 'catalog': 'x26f63a67af625d3d21eba4ef', 'create_order': 'xb28849f1155c2517f3c4e202', 'order': 'xe819899afae0b5808da8febc', 'orders': 'x4052274a07f16587dda9d966', 'update_product': 'x717ac0633453c4f8e31b6a89'}
BACKEND_GRAPH = {'x1674831d5a0c4acd14511ae8': {'operation': 'login', 'target': 'xab5a4ce92b78b5ca9a32bff8', 'kind': 'adapter'}, 'xab5a4ce92b78b5ca9a32bff8': {'operation': 'login', 'target': 'xedc7114274f5c1d3b7f07b77', 'kind': 'adapter'}, 'xedc7114274f5c1d3b7f07b77': {'operation': 'login', 'target': 'xcdc87cdce4abc385fe0ff737', 'kind': 'adapter'}, 'xcdc87cdce4abc385fe0ff737': {'operation': 'login', 'target': 'xa3b96b0afe156e64f9f6ddec', 'kind': 'adapter'}, 'xa3b96b0afe156e64f9f6ddec': {'operation': 'login', 'target': 'x318fd6261779585b9b3cae4f', 'kind': 'adapter'}, 'x318fd6261779585b9b3cae4f': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x7be08ef748c24d54b21eff3c': {'operation': 'logout', 'target': 'xa81e6bf8f2bd3657fc6dd9f9', 'kind': 'adapter'}, 'xa81e6bf8f2bd3657fc6dd9f9': {'operation': 'logout', 'target': 'x8482b2b305fd4b19027c2d23', 'kind': 'adapter'}, 'x8482b2b305fd4b19027c2d23': {'operation': 'logout', 'target': 'xe75c747a0942bb2526f94577', 'kind': 'adapter'}, 'xe75c747a0942bb2526f94577': {'operation': 'logout', 'target': 'x3c352f5ef9c8301acfe998f8', 'kind': 'adapter'}, 'x3c352f5ef9c8301acfe998f8': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x26f63a67af625d3d21eba4ef': {'operation': 'catalog', 'target': 'xea6a46fe3ed6cb911cbdae0a', 'kind': 'adapter'}, 'xea6a46fe3ed6cb911cbdae0a': {'operation': 'catalog', 'target': 'xb12c74aeea3db232ac799d91', 'kind': 'adapter'}, 'xb12c74aeea3db232ac799d91': {'operation': 'catalog', 'target': 'x6cc27df230583ccf6272b484', 'kind': 'adapter'}, 'x6cc27df230583ccf6272b484': {'operation': 'catalog', 'target': 'xc98e1fcd92774b07d2daf0f3', 'kind': 'adapter'}, 'xc98e1fcd92774b07d2daf0f3': {'operation': 'catalog', 'target': 'x6f48262bc82e2944321407da', 'kind': 'adapter'}, 'x6f48262bc82e2944321407da': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'xb28849f1155c2517f3c4e202': {'operation': 'create_order', 'target': 'xb331f4a9a5e302d5accae744', 'kind': 'adapter'}, 'xb331f4a9a5e302d5accae744': {'operation': 'create_order', 'target': 'xb6103eaa2a7f3b3a78bd6e56', 'kind': 'adapter'}, 'xb6103eaa2a7f3b3a78bd6e56': {'operation': 'create_order', 'target': 'x1764b6d5e5c90ac9b3d91f08', 'kind': 'adapter'}, 'x1764b6d5e5c90ac9b3d91f08': {'operation': 'create_order', 'target': 'x6f85bf2a122d87e018748a0a', 'kind': 'adapter'}, 'x6f85bf2a122d87e018748a0a': {'operation': 'create_order', 'target': 'x1eb746ff4106bb095858542e', 'kind': 'adapter'}, 'x1eb746ff4106bb095858542e': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'xe819899afae0b5808da8febc': {'operation': 'order', 'target': 'x4e2b7c1af48134a8601f6b2f', 'kind': 'adapter'}, 'x4e2b7c1af48134a8601f6b2f': {'operation': 'order', 'target': 'xe44f8b3f2241bec42e008c28', 'kind': 'adapter'}, 'xe44f8b3f2241bec42e008c28': {'operation': 'order', 'target': 'x7054f794536ab7417974e734', 'kind': 'adapter'}, 'x7054f794536ab7417974e734': {'operation': 'order', 'target': 'x709e3989dbd401ffb5b64f8b', 'kind': 'adapter'}, 'x709e3989dbd401ffb5b64f8b': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x4052274a07f16587dda9d966': {'operation': 'orders', 'target': 'x532334e0f6eb3c9469ed59a2', 'kind': 'adapter'}, 'x532334e0f6eb3c9469ed59a2': {'operation': 'orders', 'target': 'xcf07297c3c6673898eb409fe', 'kind': 'adapter'}, 'xcf07297c3c6673898eb409fe': {'operation': 'orders', 'target': 'x1066b598ed4726765fa53ae5', 'kind': 'adapter'}, 'x1066b598ed4726765fa53ae5': {'operation': 'orders', 'target': 'xa4276c0a2a27a346c2cb1aed', 'kind': 'adapter'}, 'xa4276c0a2a27a346c2cb1aed': {'operation': 'orders', 'target': 'xabd0e974720b7796a4144d39', 'kind': 'adapter'}, 'xabd0e974720b7796a4144d39': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x717ac0633453c4f8e31b6a89': {'operation': 'update_product', 'target': 'x59692b612c12c8320c328df3', 'kind': 'adapter'}, 'x59692b612c12c8320c328df3': {'operation': 'update_product', 'target': 'xf2813767d80b1ed6409daede', 'kind': 'adapter'}, 'xf2813767d80b1ed6409daede': {'operation': 'update_product', 'target': 'x066d762bc597a6e4e07e5a7d', 'kind': 'adapter'}, 'x066d762bc597a6e4e07e5a7d': {'operation': 'update_product', 'target': 'x489ba9581933699cf024f70b', 'kind': 'adapter'}, 'x489ba9581933699cf024f70b': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def x1674831d5a0c4acd14511ae8(core, operation, data, session, actor, trace):
    trace.append('x1674831d5a0c4acd14511ae8')
    return xab5a4ce92b78b5ca9a32bff8(core, operation, data, session, actor, trace)

def xab5a4ce92b78b5ca9a32bff8(core, operation, data, session, actor, trace):
    trace.append('xab5a4ce92b78b5ca9a32bff8')
    return xedc7114274f5c1d3b7f07b77(core, operation, data, session, actor, trace)

def xedc7114274f5c1d3b7f07b77(core, operation, data, session, actor, trace):
    trace.append('xedc7114274f5c1d3b7f07b77')
    return xcdc87cdce4abc385fe0ff737(core, operation, data, session, actor, trace)

def xcdc87cdce4abc385fe0ff737(core, operation, data, session, actor, trace):
    trace.append('xcdc87cdce4abc385fe0ff737')
    return xa3b96b0afe156e64f9f6ddec(core, operation, data, session, actor, trace)

def xa3b96b0afe156e64f9f6ddec(core, operation, data, session, actor, trace):
    trace.append('xa3b96b0afe156e64f9f6ddec')
    return x318fd6261779585b9b3cae4f(core, operation, data, session, actor, trace)

def x318fd6261779585b9b3cae4f(core, operation, data, session, actor, trace):
    trace.append('x318fd6261779585b9b3cae4f')
    return core.execute(operation, data, session, actor)

def x7be08ef748c24d54b21eff3c(core, operation, data, session, actor, trace):
    trace.append('x7be08ef748c24d54b21eff3c')
    return xa81e6bf8f2bd3657fc6dd9f9(core, operation, data, session, actor, trace)

def xa81e6bf8f2bd3657fc6dd9f9(core, operation, data, session, actor, trace):
    trace.append('xa81e6bf8f2bd3657fc6dd9f9')
    return x8482b2b305fd4b19027c2d23(core, operation, data, session, actor, trace)

def x8482b2b305fd4b19027c2d23(core, operation, data, session, actor, trace):
    trace.append('x8482b2b305fd4b19027c2d23')
    return xe75c747a0942bb2526f94577(core, operation, data, session, actor, trace)

def xe75c747a0942bb2526f94577(core, operation, data, session, actor, trace):
    trace.append('xe75c747a0942bb2526f94577')
    return x3c352f5ef9c8301acfe998f8(core, operation, data, session, actor, trace)

def x3c352f5ef9c8301acfe998f8(core, operation, data, session, actor, trace):
    trace.append('x3c352f5ef9c8301acfe998f8')
    return core.execute(operation, data, session, actor)

def x26f63a67af625d3d21eba4ef(core, operation, data, session, actor, trace):
    trace.append('x26f63a67af625d3d21eba4ef')
    return xea6a46fe3ed6cb911cbdae0a(core, operation, data, session, actor, trace)

def xea6a46fe3ed6cb911cbdae0a(core, operation, data, session, actor, trace):
    trace.append('xea6a46fe3ed6cb911cbdae0a')
    return xb12c74aeea3db232ac799d91(core, operation, data, session, actor, trace)

def xb12c74aeea3db232ac799d91(core, operation, data, session, actor, trace):
    trace.append('xb12c74aeea3db232ac799d91')
    return x6cc27df230583ccf6272b484(core, operation, data, session, actor, trace)

def x6cc27df230583ccf6272b484(core, operation, data, session, actor, trace):
    trace.append('x6cc27df230583ccf6272b484')
    return xc98e1fcd92774b07d2daf0f3(core, operation, data, session, actor, trace)

def xc98e1fcd92774b07d2daf0f3(core, operation, data, session, actor, trace):
    trace.append('xc98e1fcd92774b07d2daf0f3')
    return x6f48262bc82e2944321407da(core, operation, data, session, actor, trace)

def x6f48262bc82e2944321407da(core, operation, data, session, actor, trace):
    trace.append('x6f48262bc82e2944321407da')
    return core.execute(operation, data, session, actor)

def xb28849f1155c2517f3c4e202(core, operation, data, session, actor, trace):
    trace.append('xb28849f1155c2517f3c4e202')
    return xb331f4a9a5e302d5accae744(core, operation, data, session, actor, trace)

def xb331f4a9a5e302d5accae744(core, operation, data, session, actor, trace):
    trace.append('xb331f4a9a5e302d5accae744')
    return xb6103eaa2a7f3b3a78bd6e56(core, operation, data, session, actor, trace)

def xb6103eaa2a7f3b3a78bd6e56(core, operation, data, session, actor, trace):
    trace.append('xb6103eaa2a7f3b3a78bd6e56')
    return x1764b6d5e5c90ac9b3d91f08(core, operation, data, session, actor, trace)

def x1764b6d5e5c90ac9b3d91f08(core, operation, data, session, actor, trace):
    trace.append('x1764b6d5e5c90ac9b3d91f08')
    return x6f85bf2a122d87e018748a0a(core, operation, data, session, actor, trace)

def x6f85bf2a122d87e018748a0a(core, operation, data, session, actor, trace):
    trace.append('x6f85bf2a122d87e018748a0a')
    return x1eb746ff4106bb095858542e(core, operation, data, session, actor, trace)

def x1eb746ff4106bb095858542e(core, operation, data, session, actor, trace):
    trace.append('x1eb746ff4106bb095858542e')
    return core.execute(operation, data, session, actor)

def xe819899afae0b5808da8febc(core, operation, data, session, actor, trace):
    trace.append('xe819899afae0b5808da8febc')
    return x4e2b7c1af48134a8601f6b2f(core, operation, data, session, actor, trace)

def x4e2b7c1af48134a8601f6b2f(core, operation, data, session, actor, trace):
    trace.append('x4e2b7c1af48134a8601f6b2f')
    return xe44f8b3f2241bec42e008c28(core, operation, data, session, actor, trace)

def xe44f8b3f2241bec42e008c28(core, operation, data, session, actor, trace):
    trace.append('xe44f8b3f2241bec42e008c28')
    return x7054f794536ab7417974e734(core, operation, data, session, actor, trace)

def x7054f794536ab7417974e734(core, operation, data, session, actor, trace):
    trace.append('x7054f794536ab7417974e734')
    return x709e3989dbd401ffb5b64f8b(core, operation, data, session, actor, trace)

def x709e3989dbd401ffb5b64f8b(core, operation, data, session, actor, trace):
    trace.append('x709e3989dbd401ffb5b64f8b')
    return core.execute(operation, data, session, actor)

def x4052274a07f16587dda9d966(core, operation, data, session, actor, trace):
    trace.append('x4052274a07f16587dda9d966')
    return x532334e0f6eb3c9469ed59a2(core, operation, data, session, actor, trace)

def x532334e0f6eb3c9469ed59a2(core, operation, data, session, actor, trace):
    trace.append('x532334e0f6eb3c9469ed59a2')
    return xcf07297c3c6673898eb409fe(core, operation, data, session, actor, trace)

def xcf07297c3c6673898eb409fe(core, operation, data, session, actor, trace):
    trace.append('xcf07297c3c6673898eb409fe')
    return x1066b598ed4726765fa53ae5(core, operation, data, session, actor, trace)

def x1066b598ed4726765fa53ae5(core, operation, data, session, actor, trace):
    trace.append('x1066b598ed4726765fa53ae5')
    return xa4276c0a2a27a346c2cb1aed(core, operation, data, session, actor, trace)

def xa4276c0a2a27a346c2cb1aed(core, operation, data, session, actor, trace):
    trace.append('xa4276c0a2a27a346c2cb1aed')
    return xabd0e974720b7796a4144d39(core, operation, data, session, actor, trace)

def xabd0e974720b7796a4144d39(core, operation, data, session, actor, trace):
    trace.append('xabd0e974720b7796a4144d39')
    return core.execute(operation, data, session, actor)

def x717ac0633453c4f8e31b6a89(core, operation, data, session, actor, trace):
    trace.append('x717ac0633453c4f8e31b6a89')
    return x59692b612c12c8320c328df3(core, operation, data, session, actor, trace)

def x59692b612c12c8320c328df3(core, operation, data, session, actor, trace):
    trace.append('x59692b612c12c8320c328df3')
    return xf2813767d80b1ed6409daede(core, operation, data, session, actor, trace)

def xf2813767d80b1ed6409daede(core, operation, data, session, actor, trace):
    trace.append('xf2813767d80b1ed6409daede')
    return x066d762bc597a6e4e07e5a7d(core, operation, data, session, actor, trace)

def x066d762bc597a6e4e07e5a7d(core, operation, data, session, actor, trace):
    trace.append('x066d762bc597a6e4e07e5a7d')
    return x489ba9581933699cf024f70b(core, operation, data, session, actor, trace)

def x489ba9581933699cf024f70b(core, operation, data, session, actor, trace):
    trace.append('x489ba9581933699cf024f70b')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def invocation_exchange(handler_name, core, operation, data, session, actor):
    response = yield (ORIGINAL_INVOKE, (handler_name, core, operation, data, session, actor))
    status, result, cookie, trace = response
    return status, result, cookie, trace

def invoke(handler_name, core, operation, data, session, actor):
    exchange = invocation_exchange(handler_name, core, operation, data, session, actor)
    pending = next(exchange)
    while True:
        function, arguments = pending
        response = function(*arguments)
        try:
            pending = exchange.send(response)
        except StopIteration as finished:
            return finished.value

