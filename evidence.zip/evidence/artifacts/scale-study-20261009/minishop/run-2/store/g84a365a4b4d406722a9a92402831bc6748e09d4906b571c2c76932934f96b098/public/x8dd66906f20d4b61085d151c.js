import {send} from './x9d1541c369e9d0a2782e4034.js';
export async function x81806c04c5f45c3abf243ae7(data,csrf){const wire=[];const value=await send("/x9006049ee6b4951bd537d210",wire,csrf);return value[0];}
export async function x3443e2b540dc3e999819a814(data,csrf){const wire={"x79f71096733f73300f6a2c12":{}};const value=await send("/x0ed975ddb416a6ff136c64a1",wire,csrf);return value[0];}
