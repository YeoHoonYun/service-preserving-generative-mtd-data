import {send} from './x9d1541c369e9d0a2782e4034.js';
export async function xfd310f5f8e57902981edf87a(data,csrf){const wire={};const value=await send("/x5009dc5cba7adb1ad6a01422",wire,csrf);return value["xad446274dc7fe5a1ae0b8a92"]["x6f1b275c10eb99e58d9d7dd4"];}
export async function x678e6098ec6aaa72fd87ef57(data,csrf){const wire={"x76f0e985c5c2b4f911a8dbb6":data["product_id"],"x0063d1808dbd8d0a37c47a41":data["stock"],"x7a04d57e7ca6dde6c8c595e4":data["price"]};const value=await send("/xe38c0d10f076f32df74b5f40",wire,csrf);return value["x96516577955b0c7f7fe9f687"];}
