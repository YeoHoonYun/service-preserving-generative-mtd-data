GRAPH = {'xd90d731741427d37f0b22919': {'kind': 'router', 'edges': {'/xe6b8748ff7c6f9fa8987a98e': {'target': 'xa6a3d05b6f9f9506bdf378e5', 'next_key': 'x22a87e184fa509e931c5767e'}, '/x69e12e2b8a7492302f3578e0': {'target': 'xa6a3d05b6f9f9506bdf378e5', 'next_key': 'xd8b002d8567e785f3d975363'}, '/x6e0f8357ba5d70b1db86a3f2': {'target': 'xa6a3d05b6f9f9506bdf378e5', 'next_key': 'x6fbd80b37cb23d795f174ec3'}, '/x51d4c1dd5526d0626a8e6475': {'target': 'xa6a3d05b6f9f9506bdf378e5', 'next_key': 'x40064e7ffdcca4ae648f552e'}, '/xc8e90badbf42e608a0843e87': {'target': 'xa6a3d05b6f9f9506bdf378e5', 'next_key': 'xb71c150c24aac99f3724a2c6'}, '/x9376147664e1f785bf760eb1': {'target': 'xa6a3d05b6f9f9506bdf378e5', 'next_key': 'x3b8eedf923d015ff4d01b7d6'}, '/x0ae0b06af40432dac044559e': {'target': 'xa6a3d05b6f9f9506bdf378e5', 'next_key': 'x6a7aa0580840833de839fc3c'}}}, 'xa6a3d05b6f9f9506bdf378e5': {'kind': 'router', 'edges': {'x22a87e184fa509e931c5767e': {'target': 'x8b160ba7fbee8d96ea7cf634', 'next_key': 'xd0b201fcbd7cccf88a84ad31'}, 'xd8b002d8567e785f3d975363': {'target': 'x8b160ba7fbee8d96ea7cf634', 'next_key': 'x81a77cc1d59007ec8c4aacf1'}, 'x6fbd80b37cb23d795f174ec3': {'target': 'x8b160ba7fbee8d96ea7cf634', 'next_key': 'x85cd32928c1484f719b05e47'}, 'x40064e7ffdcca4ae648f552e': {'target': 'x8b160ba7fbee8d96ea7cf634', 'next_key': 'x2d751ae5919c5912c47b0609'}, 'xb71c150c24aac99f3724a2c6': {'target': 'x8b160ba7fbee8d96ea7cf634', 'next_key': 'xf2d4708321e745588d0ffebe'}, 'x3b8eedf923d015ff4d01b7d6': {'target': 'x8b160ba7fbee8d96ea7cf634', 'next_key': 'x0c0dd49aea18b0fa44964d69'}, 'x6a7aa0580840833de839fc3c': {'target': 'x8b160ba7fbee8d96ea7cf634', 'next_key': 'x69c7c5267dd8f13438786945'}}}, 'x8b160ba7fbee8d96ea7cf634': {'kind': 'router', 'edges': {'xd0b201fcbd7cccf88a84ad31': {'target': 'xef2eee8989895366b9771291', 'next_key': 'x9461dd483d4df338999c1bb2'}, 'x81a77cc1d59007ec8c4aacf1': {'target': 'xef2eee8989895366b9771291', 'next_key': 'x2ee52fa861e248fd058d9014'}, 'x85cd32928c1484f719b05e47': {'target': 'xef2eee8989895366b9771291', 'next_key': 'xfb0322f9b0764002ae66f89c'}, 'x2d751ae5919c5912c47b0609': {'target': 'xef2eee8989895366b9771291', 'next_key': 'xb671a5d0caff6c6ff9ffa52c'}, 'xf2d4708321e745588d0ffebe': {'target': 'xef2eee8989895366b9771291', 'next_key': 'xb17b41276bab2c44eccc5c93'}, 'x0c0dd49aea18b0fa44964d69': {'target': 'xef2eee8989895366b9771291', 'next_key': 'xbafd3682a632f4489e8242f5'}, 'x69c7c5267dd8f13438786945': {'target': 'xef2eee8989895366b9771291', 'next_key': 'xcb39433ad88a926560751317'}}}, 'xef2eee8989895366b9771291': {'kind': 'router', 'edges': {'x9461dd483d4df338999c1bb2': {'target': 'x00127880da83d915218efc72', 'next_key': 'xe9eec7057d3c7a0430defc90'}, 'x2ee52fa861e248fd058d9014': {'target': 'x0a994b545d099311c347f511', 'next_key': 'xb27bc5b5271a36fbca65b589'}, 'xfb0322f9b0764002ae66f89c': {'target': 'x00127880da83d915218efc72', 'next_key': 'x64d0e148b7ed2f170247af61'}, 'xb671a5d0caff6c6ff9ffa52c': {'target': 'x0a994b545d099311c347f511', 'next_key': 'xfb587c1ceb5cefc942053ed1'}, 'xb17b41276bab2c44eccc5c93': {'target': 'x00127880da83d915218efc72', 'next_key': 'x379dd0514aaada133f865328'}, 'xbafd3682a632f4489e8242f5': {'target': 'x0a994b545d099311c347f511', 'next_key': 'x1648ab5196631616d112441c'}, 'xcb39433ad88a926560751317': {'target': 'x00127880da83d915218efc72', 'next_key': 'x96b192710ac74be22c9300b0'}}}, 'x0a994b545d099311c347f511': {'kind': 'router', 'edges': {'xb27bc5b5271a36fbca65b589': {'target': 'x3735c2bbca8af4c5e348f6ae', 'next_key': None}, 'xfb587c1ceb5cefc942053ed1': {'target': 'x50e694abfd0d7e655dd57ea9', 'next_key': None}, 'x1648ab5196631616d112441c': {'target': 'xb51302dd2e1ff51621523cdf', 'next_key': None}}}, 'x00127880da83d915218efc72': {'kind': 'router', 'edges': {'xe9eec7057d3c7a0430defc90': {'target': 'xa2eedc0f418905d8d93a15c8', 'next_key': None}, 'x64d0e148b7ed2f170247af61': {'target': 'x75e20b22cb8a0ddd2b1b697f', 'next_key': None}, 'x379dd0514aaada133f865328': {'target': 'x2084b819c8d23c82638440ff', 'next_key': None}, 'x96b192710ac74be22c9300b0': {'target': 'x30205bac2a26f6383ae20b11', 'next_key': None}}}, 'xa2eedc0f418905d8d93a15c8': {'kind': 'service', 'operation': 'login', 'handler': 'xba8946fdc12099f04e7e9ca9'}, 'x3735c2bbca8af4c5e348f6ae': {'kind': 'service', 'operation': 'logout', 'handler': 'x49b0f1b1437e0b820740f314'}, 'x75e20b22cb8a0ddd2b1b697f': {'kind': 'service', 'operation': 'catalog', 'handler': 'x48349ae7259511640748584a'}, 'x50e694abfd0d7e655dd57ea9': {'kind': 'service', 'operation': 'create_order', 'handler': 'xdea791951c52b8b97677ba1c'}, 'x2084b819c8d23c82638440ff': {'kind': 'service', 'operation': 'order', 'handler': 'x0fe0dddda255434e978cc4d0'}, 'xb51302dd2e1ff51621523cdf': {'kind': 'service', 'operation': 'orders', 'handler': 'x7a488f2546633ac7a0611a27'}, 'x30205bac2a26f6383ae20b11': {'kind': 'service', 'operation': 'update_product', 'handler': 'xc6f964404d0405cac3ccb979'}}
ENTRY = 'xd90d731741427d37f0b22919'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    bindings = []
    for path in graph[entry]['edges']:
        node, key, seen = entry, path, set()
        while graph[node]['kind'] != 'service':
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        bindings.append((len(graph[node]['operation']), path, node))
    bins = []
    for weight, path, leaf in reversed(sorted(bindings)):
        chosen = None
        for bucket in bins:
            if len(bucket['items']) < 3 and bucket['weight'] + weight <= 20:
                chosen = bucket
                break
        if chosen is None:
            chosen = {'weight': 0, 'items': []}
            bins.append(chosen)
        chosen['weight'] += weight
        chosen['items'].append((path, leaf))
    result = {'route_index': {'kind': 'router', 'edges': {}}}
    for number, bucket in enumerate(bins):
        branch = 'capacity_' + str(number)
        result[branch] = {'kind': 'router', 'edges': {}}
        for path, leaf in bucket['items']:
            result[leaf] = dict(graph[leaf])
            result['route_index']['edges'][path] = {'target': branch, 'next_key': path}
            result[branch]['edges'][path] = {'target': leaf, 'next_key': None}
    return result, 'route_index'

def resolve(path):
    node, key = ENTRY, path
    visited, trace = set(), []
    while node not in visited:
        visited.add(node)
        trace.append(node)
        current = GRAPH[node]
        if current['kind'] == 'service':
            return current['operation'], current['handler'], trace
        edge = current['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
