import {send} from './x3f6068331e620f37f8aef295.js';
export async function x6975a9b422246af49cc36266(data,csrf){const wire=[];const value=await send("/x69e12e2b8a7492302f3578e0",wire,csrf);return value[0];}
export async function x732643bb91f1b0c0c93e771c(data,csrf){const wire=[];const value=await send("/x9376147664e1f785bf760eb1",wire,csrf);return value["x979d9e60e530d8a325fa080c"];}
