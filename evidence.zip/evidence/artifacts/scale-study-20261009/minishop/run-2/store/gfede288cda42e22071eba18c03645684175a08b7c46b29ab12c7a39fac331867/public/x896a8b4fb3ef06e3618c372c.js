import {send} from './x3f6068331e620f37f8aef295.js';
export async function x0bcc1f31cba5568da614ee1d(data,csrf){const wire={"xacfa4fb387ee77ee9ecbd925":data["password"],"xfc08d5df78a736b7e1514fa3":data["username"]};const value=await send("/xe6b8748ff7c6f9fa8987a98e",wire,csrf);return value["x3740b722a40588640d7bab20"];}
export async function xece0b6dc63c7ba8fa190b567(data,csrf){const wire={"x92b569e92e0058f9eea5089a":{"x68631cc1ea9c73e5326bfff1":data["order_id"]}};const value=await send("/xc8e90badbf42e608a0843e87",wire,csrf);return value[0];}
