# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/xe6b8748ff7c6f9fa8987a98e', 'fields': ['password', 'username'], 'aliases': {'password': 'xacfa4fb387ee77ee9ecbd925', 'username': 'xfc08d5df78a736b7e1514fa3'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x28199e0e9ad6e856f30f1e29', 'response_box': 'xa8d79a05520f627e334a5ae6', 'result_key': 'x3740b722a40588640d7bab20'}, 'logout': {'route': '/x69e12e2b8a7492302f3578e0', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'array', 'request_box': 'xc29ac01f80f555e7e6f8f06a', 'response_box': 'x12b838fdd537eaa4be15d28f', 'result_key': 'x1ed024b35310647bc4fd9217'}, 'catalog': {'route': '/x6e0f8357ba5d70b1db86a3f2', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'wrapped', 'request_box': 'x5f9a99990f1fad261f361ba1', 'response_box': 'x5fbc2ca2de2f7299e66d6c93', 'result_key': 'x328692fbbcd3f5b0a38a9e69'}, 'create_order': {'route': '/x51d4c1dd5526d0626a8e6475', 'fields': ['request_id', 'product_id', 'quantity'], 'aliases': {'request_id': 'xdf061a53f913cf93ae58f945', 'product_id': 'x803f764137b36257bdee5e94', 'quantity': 'x40feb37eb72ed69b62d113c9'}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'xfe22fcabc7ed7a4de8b125b0', 'response_box': 'x46b076b4caeefe2baa6d2d77', 'result_key': 'x3b94e04d63a1f6943e1d2d56'}, 'order': {'route': '/xc8e90badbf42e608a0843e87', 'fields': ['order_id'], 'aliases': {'order_id': 'x68631cc1ea9c73e5326bfff1'}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x92b569e92e0058f9eea5089a', 'response_box': 'x8a4966a061be10b93a411a51', 'result_key': 'xd5faa245f735fda619f21fad'}, 'orders': {'route': '/x9376147664e1f785bf760eb1', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'x437d93a822bab1d477579994', 'response_box': 'xb043867282e3516ba856118a', 'result_key': 'x979d9e60e530d8a325fa080c'}, 'update_product': {'route': '/x0ae0b06af40432dac044559e', 'fields': ['product_id', 'stock', 'price'], 'aliases': {'product_id': 'xfa6117960847831a6fba6b60', 'stock': 'xfc090b2ce334611290126423', 'price': 'xefdbae9c78368e674b7c2edc'}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'xaf88b38edc1221461997a4e2', 'response_box': 'xb7e5fc9c10f0e39ba5f08274', 'result_key': 'x91a51d538585fe22da1c5929'}}
HANDLERS = {'login': 'xba8946fdc12099f04e7e9ca9', 'logout': 'x49b0f1b1437e0b820740f314', 'catalog': 'x48349ae7259511640748584a', 'create_order': 'xdea791951c52b8b97677ba1c', 'order': 'x0fe0dddda255434e978cc4d0', 'orders': 'x7a488f2546633ac7a0611a27', 'update_product': 'xc6f964404d0405cac3ccb979'}
BACKEND_GRAPH = {'xba8946fdc12099f04e7e9ca9': {'operation': 'login', 'target': 'xeccd00fcd0e9de53a6e6ccf4', 'kind': 'adapter'}, 'xeccd00fcd0e9de53a6e6ccf4': {'operation': 'login', 'target': 'x3846e83f133e12a165037d77', 'kind': 'adapter'}, 'x3846e83f133e12a165037d77': {'operation': 'login', 'target': 'xe900e03376f00efcdf1b7912', 'kind': 'adapter'}, 'xe900e03376f00efcdf1b7912': {'operation': 'login', 'target': 'x6a9e370f0a4226be05bcf059', 'kind': 'adapter'}, 'x6a9e370f0a4226be05bcf059': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x49b0f1b1437e0b820740f314': {'operation': 'logout', 'target': 'x91af0923103598a0c60f5b7c', 'kind': 'adapter'}, 'x91af0923103598a0c60f5b7c': {'operation': 'logout', 'target': 'xb70425543a0aca3d05ce735a', 'kind': 'adapter'}, 'xb70425543a0aca3d05ce735a': {'operation': 'logout', 'target': 'xae3494fef23f9283bb72cbb6', 'kind': 'adapter'}, 'xae3494fef23f9283bb72cbb6': {'operation': 'logout', 'target': 'x24881019b2d6f7364cd7500d', 'kind': 'adapter'}, 'x24881019b2d6f7364cd7500d': {'operation': 'logout', 'target': 'xa27dd3043c65799b2d7d811c', 'kind': 'adapter'}, 'xa27dd3043c65799b2d7d811c': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x48349ae7259511640748584a': {'operation': 'catalog', 'target': 'x90f05a5fe240243e9e5ffd8a', 'kind': 'adapter'}, 'x90f05a5fe240243e9e5ffd8a': {'operation': 'catalog', 'target': 'xbdbda79b580d24b2da8e50b7', 'kind': 'adapter'}, 'xbdbda79b580d24b2da8e50b7': {'operation': 'catalog', 'target': 'x6123f18354b20853588fc459', 'kind': 'adapter'}, 'x6123f18354b20853588fc459': {'operation': 'catalog', 'target': 'x980dfe026428a2b13b52256c', 'kind': 'adapter'}, 'x980dfe026428a2b13b52256c': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'xdea791951c52b8b97677ba1c': {'operation': 'create_order', 'target': 'x43bccc7c1200709a5d77dcc3', 'kind': 'adapter'}, 'x43bccc7c1200709a5d77dcc3': {'operation': 'create_order', 'target': 'x7e52a5eff023cad9f387416e', 'kind': 'adapter'}, 'x7e52a5eff023cad9f387416e': {'operation': 'create_order', 'target': 'xe3e83a212b8bc240618f137a', 'kind': 'adapter'}, 'xe3e83a212b8bc240618f137a': {'operation': 'create_order', 'target': 'xb9671fd0e71669d4e01b48bb', 'kind': 'adapter'}, 'xb9671fd0e71669d4e01b48bb': {'operation': 'create_order', 'target': 'xbb48310d9d0f378f323ad0ba', 'kind': 'adapter'}, 'xbb48310d9d0f378f323ad0ba': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x0fe0dddda255434e978cc4d0': {'operation': 'order', 'target': 'x92a943fd2ba7c60a0d146b13', 'kind': 'adapter'}, 'x92a943fd2ba7c60a0d146b13': {'operation': 'order', 'target': 'x7af8fd71e0519e39d43cdb4c', 'kind': 'adapter'}, 'x7af8fd71e0519e39d43cdb4c': {'operation': 'order', 'target': 'x52cb535c8a3dd82ec620ce35', 'kind': 'adapter'}, 'x52cb535c8a3dd82ec620ce35': {'operation': 'order', 'target': 'x7dea81eab02bc1c97b4946dc', 'kind': 'adapter'}, 'x7dea81eab02bc1c97b4946dc': {'operation': 'order', 'target': 'x1f33cf6ecc06eb2318e1e44b', 'kind': 'adapter'}, 'x1f33cf6ecc06eb2318e1e44b': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x7a488f2546633ac7a0611a27': {'operation': 'orders', 'target': 'xbff6ea6f8ec7b57eee77940e', 'kind': 'adapter'}, 'xbff6ea6f8ec7b57eee77940e': {'operation': 'orders', 'target': 'x0a8f0ab8e5adbe26df7dd3cf', 'kind': 'adapter'}, 'x0a8f0ab8e5adbe26df7dd3cf': {'operation': 'orders', 'target': 'xde6c0ab141014877ae792182', 'kind': 'adapter'}, 'xde6c0ab141014877ae792182': {'operation': 'orders', 'target': 'xd1c32b4dc7676718f4189022', 'kind': 'adapter'}, 'xd1c32b4dc7676718f4189022': {'operation': 'orders', 'target': 'x0b3929d885f2efaca8cb8c3d', 'kind': 'adapter'}, 'x0b3929d885f2efaca8cb8c3d': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'xc6f964404d0405cac3ccb979': {'operation': 'update_product', 'target': 'xaee928f64a2aaa5b03ba5641', 'kind': 'adapter'}, 'xaee928f64a2aaa5b03ba5641': {'operation': 'update_product', 'target': 'x672ec4565cbd9cfb5862be3e', 'kind': 'adapter'}, 'x672ec4565cbd9cfb5862be3e': {'operation': 'update_product', 'target': 'x909eaf52f09800daffeb2f6f', 'kind': 'adapter'}, 'x909eaf52f09800daffeb2f6f': {'operation': 'update_product', 'target': 'x4c1072dac57e18021e87faf4', 'kind': 'adapter'}, 'x4c1072dac57e18021e87faf4': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xba8946fdc12099f04e7e9ca9(core, operation, data, session, actor, trace):
    trace.append('xba8946fdc12099f04e7e9ca9')
    return xeccd00fcd0e9de53a6e6ccf4(core, operation, data, session, actor, trace)

def xeccd00fcd0e9de53a6e6ccf4(core, operation, data, session, actor, trace):
    trace.append('xeccd00fcd0e9de53a6e6ccf4')
    return x3846e83f133e12a165037d77(core, operation, data, session, actor, trace)

def x3846e83f133e12a165037d77(core, operation, data, session, actor, trace):
    trace.append('x3846e83f133e12a165037d77')
    return xe900e03376f00efcdf1b7912(core, operation, data, session, actor, trace)

def xe900e03376f00efcdf1b7912(core, operation, data, session, actor, trace):
    trace.append('xe900e03376f00efcdf1b7912')
    return x6a9e370f0a4226be05bcf059(core, operation, data, session, actor, trace)

def x6a9e370f0a4226be05bcf059(core, operation, data, session, actor, trace):
    trace.append('x6a9e370f0a4226be05bcf059')
    return core.execute(operation, data, session, actor)

def x49b0f1b1437e0b820740f314(core, operation, data, session, actor, trace):
    trace.append('x49b0f1b1437e0b820740f314')
    return x91af0923103598a0c60f5b7c(core, operation, data, session, actor, trace)

def x91af0923103598a0c60f5b7c(core, operation, data, session, actor, trace):
    trace.append('x91af0923103598a0c60f5b7c')
    return xb70425543a0aca3d05ce735a(core, operation, data, session, actor, trace)

def xb70425543a0aca3d05ce735a(core, operation, data, session, actor, trace):
    trace.append('xb70425543a0aca3d05ce735a')
    return xae3494fef23f9283bb72cbb6(core, operation, data, session, actor, trace)

def xae3494fef23f9283bb72cbb6(core, operation, data, session, actor, trace):
    trace.append('xae3494fef23f9283bb72cbb6')
    return x24881019b2d6f7364cd7500d(core, operation, data, session, actor, trace)

def x24881019b2d6f7364cd7500d(core, operation, data, session, actor, trace):
    trace.append('x24881019b2d6f7364cd7500d')
    return xa27dd3043c65799b2d7d811c(core, operation, data, session, actor, trace)

def xa27dd3043c65799b2d7d811c(core, operation, data, session, actor, trace):
    trace.append('xa27dd3043c65799b2d7d811c')
    return core.execute(operation, data, session, actor)

def x48349ae7259511640748584a(core, operation, data, session, actor, trace):
    trace.append('x48349ae7259511640748584a')
    return x90f05a5fe240243e9e5ffd8a(core, operation, data, session, actor, trace)

def x90f05a5fe240243e9e5ffd8a(core, operation, data, session, actor, trace):
    trace.append('x90f05a5fe240243e9e5ffd8a')
    return xbdbda79b580d24b2da8e50b7(core, operation, data, session, actor, trace)

def xbdbda79b580d24b2da8e50b7(core, operation, data, session, actor, trace):
    trace.append('xbdbda79b580d24b2da8e50b7')
    return x6123f18354b20853588fc459(core, operation, data, session, actor, trace)

def x6123f18354b20853588fc459(core, operation, data, session, actor, trace):
    trace.append('x6123f18354b20853588fc459')
    return x980dfe026428a2b13b52256c(core, operation, data, session, actor, trace)

def x980dfe026428a2b13b52256c(core, operation, data, session, actor, trace):
    trace.append('x980dfe026428a2b13b52256c')
    return core.execute(operation, data, session, actor)

def xdea791951c52b8b97677ba1c(core, operation, data, session, actor, trace):
    trace.append('xdea791951c52b8b97677ba1c')
    return x43bccc7c1200709a5d77dcc3(core, operation, data, session, actor, trace)

def x43bccc7c1200709a5d77dcc3(core, operation, data, session, actor, trace):
    trace.append('x43bccc7c1200709a5d77dcc3')
    return x7e52a5eff023cad9f387416e(core, operation, data, session, actor, trace)

def x7e52a5eff023cad9f387416e(core, operation, data, session, actor, trace):
    trace.append('x7e52a5eff023cad9f387416e')
    return xe3e83a212b8bc240618f137a(core, operation, data, session, actor, trace)

def xe3e83a212b8bc240618f137a(core, operation, data, session, actor, trace):
    trace.append('xe3e83a212b8bc240618f137a')
    return xb9671fd0e71669d4e01b48bb(core, operation, data, session, actor, trace)

def xb9671fd0e71669d4e01b48bb(core, operation, data, session, actor, trace):
    trace.append('xb9671fd0e71669d4e01b48bb')
    return xbb48310d9d0f378f323ad0ba(core, operation, data, session, actor, trace)

def xbb48310d9d0f378f323ad0ba(core, operation, data, session, actor, trace):
    trace.append('xbb48310d9d0f378f323ad0ba')
    return core.execute(operation, data, session, actor)

def x0fe0dddda255434e978cc4d0(core, operation, data, session, actor, trace):
    trace.append('x0fe0dddda255434e978cc4d0')
    return x92a943fd2ba7c60a0d146b13(core, operation, data, session, actor, trace)

def x92a943fd2ba7c60a0d146b13(core, operation, data, session, actor, trace):
    trace.append('x92a943fd2ba7c60a0d146b13')
    return x7af8fd71e0519e39d43cdb4c(core, operation, data, session, actor, trace)

def x7af8fd71e0519e39d43cdb4c(core, operation, data, session, actor, trace):
    trace.append('x7af8fd71e0519e39d43cdb4c')
    return x52cb535c8a3dd82ec620ce35(core, operation, data, session, actor, trace)

def x52cb535c8a3dd82ec620ce35(core, operation, data, session, actor, trace):
    trace.append('x52cb535c8a3dd82ec620ce35')
    return x7dea81eab02bc1c97b4946dc(core, operation, data, session, actor, trace)

def x7dea81eab02bc1c97b4946dc(core, operation, data, session, actor, trace):
    trace.append('x7dea81eab02bc1c97b4946dc')
    return x1f33cf6ecc06eb2318e1e44b(core, operation, data, session, actor, trace)

def x1f33cf6ecc06eb2318e1e44b(core, operation, data, session, actor, trace):
    trace.append('x1f33cf6ecc06eb2318e1e44b')
    return core.execute(operation, data, session, actor)

def x7a488f2546633ac7a0611a27(core, operation, data, session, actor, trace):
    trace.append('x7a488f2546633ac7a0611a27')
    return xbff6ea6f8ec7b57eee77940e(core, operation, data, session, actor, trace)

def xbff6ea6f8ec7b57eee77940e(core, operation, data, session, actor, trace):
    trace.append('xbff6ea6f8ec7b57eee77940e')
    return x0a8f0ab8e5adbe26df7dd3cf(core, operation, data, session, actor, trace)

def x0a8f0ab8e5adbe26df7dd3cf(core, operation, data, session, actor, trace):
    trace.append('x0a8f0ab8e5adbe26df7dd3cf')
    return xde6c0ab141014877ae792182(core, operation, data, session, actor, trace)

def xde6c0ab141014877ae792182(core, operation, data, session, actor, trace):
    trace.append('xde6c0ab141014877ae792182')
    return xd1c32b4dc7676718f4189022(core, operation, data, session, actor, trace)

def xd1c32b4dc7676718f4189022(core, operation, data, session, actor, trace):
    trace.append('xd1c32b4dc7676718f4189022')
    return x0b3929d885f2efaca8cb8c3d(core, operation, data, session, actor, trace)

def x0b3929d885f2efaca8cb8c3d(core, operation, data, session, actor, trace):
    trace.append('x0b3929d885f2efaca8cb8c3d')
    return core.execute(operation, data, session, actor)

def xc6f964404d0405cac3ccb979(core, operation, data, session, actor, trace):
    trace.append('xc6f964404d0405cac3ccb979')
    return xaee928f64a2aaa5b03ba5641(core, operation, data, session, actor, trace)

def xaee928f64a2aaa5b03ba5641(core, operation, data, session, actor, trace):
    trace.append('xaee928f64a2aaa5b03ba5641')
    return x672ec4565cbd9cfb5862be3e(core, operation, data, session, actor, trace)

def x672ec4565cbd9cfb5862be3e(core, operation, data, session, actor, trace):
    trace.append('x672ec4565cbd9cfb5862be3e')
    return x909eaf52f09800daffeb2f6f(core, operation, data, session, actor, trace)

def x909eaf52f09800daffeb2f6f(core, operation, data, session, actor, trace):
    trace.append('x909eaf52f09800daffeb2f6f')
    return x4c1072dac57e18021e87faf4(core, operation, data, session, actor, trace)

def x4c1072dac57e18021e87faf4(core, operation, data, session, actor, trace):
    trace.append('x4c1072dac57e18021e87faf4')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def adapter_binding(handler_name):
    bindings = {
        'xba8946fdc12099f04e7e9ca9': xba8946fdc12099f04e7e9ca9,
        'x49b0f1b1437e0b820740f314': x49b0f1b1437e0b820740f314,
        'x48349ae7259511640748584a': x48349ae7259511640748584a,
        'xdea791951c52b8b97677ba1c': xdea791951c52b8b97677ba1c,
        'x0fe0dddda255434e978cc4d0': x0fe0dddda255434e978cc4d0,
        'x7a488f2546633ac7a0611a27': x7a488f2546633ac7a0611a27,
        'xc6f964404d0405cac3ccb979': xc6f964404d0405cac3ccb979
    }
    return bindings[handler_name]

def adapter_transaction(adapter, arguments):
    trace = []
    def execute_bound():
        return adapter(*arguments, trace)
    return execute_bound, trace

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    adapter = adapter_binding(handler_name)
    execute_bound, trace = adapter_transaction(adapter, (core, operation, data, session, actor))
    status, result, cookie = execute_bound()
    return status, result, cookie, trace

