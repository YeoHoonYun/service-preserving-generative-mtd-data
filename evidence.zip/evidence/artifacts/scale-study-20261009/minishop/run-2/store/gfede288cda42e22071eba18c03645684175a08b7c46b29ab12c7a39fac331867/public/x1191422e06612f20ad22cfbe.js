import {send} from './x3f6068331e620f37f8aef295.js';
export async function x299dd1e355a574ef6b257623(data,csrf){const wire={"xdf061a53f913cf93ae58f945":data["request_id"],"x803f764137b36257bdee5e94":data["product_id"],"x40feb37eb72ed69b62d113c9":data["quantity"]};const value=await send("/x51d4c1dd5526d0626a8e6475",wire,csrf);return value[0];}
