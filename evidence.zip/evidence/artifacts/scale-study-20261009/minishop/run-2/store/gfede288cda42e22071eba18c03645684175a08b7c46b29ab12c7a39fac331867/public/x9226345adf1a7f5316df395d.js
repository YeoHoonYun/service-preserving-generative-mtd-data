import {x0bcc1f31cba5568da614ee1d,xece0b6dc63c7ba8fa190b567} from './x896a8b4fb3ef06e3618c372c.js';
import {x6975a9b422246af49cc36266,x732643bb91f1b0c0c93e771c} from './x0decea009f2c4267e16ee344.js';
import {x23351635cae6dbc1a95524fa,xd7afc2539768d72da4e5215f} from './xd4faf43c735eba4eb563c928.js';
import {x299dd1e355a574ef6b257623} from './x1191422e06612f20ad22cfbe.js';

let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('x4f73741ac01c9c0dfa8c2e10');
const endpoints={login:x0bcc1f31cba5568da614ee1d,logout:x6975a9b422246af49cc36266,catalog:x23351635cae6dbc1a95524fa,create_order:x299dd1e355a574ef6b257623,order:xece0b6dc63c7ba8fa190b567,orders:x732643bb91f1b0c0c93e771c,update_product:xd7afc2539768d72da4e5215f};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('x4bad7b1e3ab40b11c45e27be').textContent=boot.user?boot.user.id:'방문자';}
function observe(promise){promise.catch(error=>message.textContent=error.message);}

function collectionView(id,operation,format,complete){
 return async function refresh(){
  const list=document.getElementById(id);
  list.replaceChildren();
  const records=await api(operation);
  for(const record of records){
   const item=document.createElement('li');
   item.textContent=format(record);
   list.append(item);
  }
  if(complete)complete();
 };
}
const catalog=collectionView('x884709e51ab7c581ac56364c','catalog',p=>p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock,()=>{document.body.dataset.ready='yes';});
const orders=collectionView('x262c671edc38849d5c5ad58b','orders',order=>order.id+' · '+order.total+'원');

function readSubmission(form){
 const raw=Object.fromEntries(new FormData(form));
 return {username:raw['xa958f95f81b4064281510d69'],password:raw['x618418391ff36a071c1fd089'],product_id:raw['x7fb2604214846272e9ff367d'],quantity:raw['xf6a7e282d17f97179375fb98'],price:raw['x5394304abbc46853273242e7'],stock:raw['x9ff1b7689db823d83bb214b2']};
}
async function acceptLogin(data){
 boot=await api('login',data);
 identity();
 message.textContent='로그인되었습니다.';
}
async function placeOrder(data){
 const order=await api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()});
 message.textContent='주문 '+order.id+' · '+order.total+'원';
 await catalog();
 await orders();
}
async function reviseProduct(data){
 await api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)});
 message.textContent='상품을 수정했습니다.';
 await catalog();
}
async function submitForm(form){
 const data=readSubmission(form);
 if(form.dataset.action==='x039ccacecfaea86c20b8608b')await acceptLogin(data);
 if(form.dataset.action==='x90c13a9098281019f5a0ddc1')await placeOrder(data);
 if(form.dataset.action==='xb22883a5fbf214ec96e3dc58')await reviseProduct(data);
}
const submissionListener={
 handleEvent(event){
  event.preventDefault();
  observe(submitForm(event.target));
 }
};
document.addEventListener('submit',submissionListener);
document.getElementById('xee50822b168eb803ee4d065d').onclick=()=>observe(api('logout').then(()=>location.reload()));
document.getElementById('x9a5ff92da7fc46b067953e32').onclick=()=>observe(orders());
identity();
observe(catalog());
