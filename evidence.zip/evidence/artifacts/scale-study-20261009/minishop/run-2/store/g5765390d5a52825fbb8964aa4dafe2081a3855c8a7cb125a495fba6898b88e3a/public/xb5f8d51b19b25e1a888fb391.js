import {x877644121ad7934b3b5dbe0e,x2f34d24e0ab566caa5fd2640,x2406f9f4266ee37a889df890} from './x8ff55c3e82804d9d323f38a4.js';
import {x18c1eaea1e0dbb623caaf5af,xbd7b61918868eb9ee7baff1c} from './x4d041d538011bde926365d5b.js';
import {xf0334a673f80ec7e445dba8c,x517733ed4b94dc764ca20ddf} from './x653181c643ae7288582e11f9.js';

let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('x3399e1a8dff5520c80c23e58');
const endpoints={login:x877644121ad7934b3b5dbe0e,logout:x18c1eaea1e0dbb623caaf5af,catalog:xf0334a673f80ec7e445dba8c,create_order:x2f34d24e0ab566caa5fd2640,order:xbd7b61918868eb9ee7baff1c,orders:x517733ed4b94dc764ca20ddf,update_product:x2406f9f4266ee37a889df890};
const fieldKeys={username:'xc3e30f4dcb152dd0e4912287',password:'xe48eef44a04914b2e234b90f',product_id:'x00e02e17db7f0dd0c402ba92',quantity:'x0a1535aad933eb6bb2afdc0f',price:'x70972f434275b111356c54eb',stock:'x97a1e519addb557bfb1c0761'};

async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('x8e9a033f69dea2d5bc18689a').textContent=boot.user?boot.user.id:'방문자';}
function run(promise){promise.catch(error=>message.textContent=error.message);}
async function sequence(tasks){for(const task of tasks){await task();}}

async function catalog(){
 const list=document.getElementById('xa7ba5973c6b50842d68980a2');
 list.replaceChildren();
 for(const product of await api('catalog')){
  const item=document.createElement('li');
  item.textContent=product.id+' · '+product.name+' · '+product.price+'원 · 재고 '+product.stock;
  list.append(item);
 }
 document.body.dataset.ready='yes';
}
async function orders(){
 const list=document.getElementById('xa320a112c6ff408fced09292');
 list.replaceChildren();
 for(const order of await api('orders')){
  const item=document.createElement('li');
  item.textContent=order.id+' · '+order.total+'원';
  list.append(item);
 }
}

function loginTasks(data){
 return [async()=>{
  boot=await api('login',data);
  identity();
  message.textContent='로그인되었습니다.';
 }];
}
function purchaseTasks(data){
 return [async()=>{
  const order=await api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()});
  message.textContent='주문 '+order.id+' · '+order.total+'원';
 },catalog,orders];
}
function productTasks(data){
 return [async()=>{
  await api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)});
  message.textContent='상품을 수정했습니다.';
 },catalog];
}
async function submit(form){
 const raw=Object.fromEntries(new FormData(form));
 const data=Object.fromEntries(Object.entries(fieldKeys).map(([field,key])=>[field,raw[key]]));
 if(form.dataset.action==='xf714439065a39b306c4e6c49')await sequence(loginTasks(data));
 if(form.dataset.action==='x34e7d693813cde2aee1b242c')await sequence(purchaseTasks(data));
 if(form.dataset.action==='xf5a1177a72ed20d0737137e7')await sequence(productTasks(data));
}
function attachEvents(){
 document.addEventListener('submit',event=>{
  event.preventDefault();
  run(submit(event.target));
 });
 document.getElementById('xd6cf64abefbb0e213d3dfb8d').onclick=()=>run(api('logout').then(()=>location.reload()));
 document.getElementById('xc3cf5720dcd3d851d35cd901').onclick=()=>run(orders());
}
attachEvents();
identity();
run(catalog());
