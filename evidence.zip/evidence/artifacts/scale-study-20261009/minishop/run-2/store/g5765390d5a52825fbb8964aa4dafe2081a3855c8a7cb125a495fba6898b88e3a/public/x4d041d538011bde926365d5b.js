import {send} from './x94d3ded8a6d53a628fb8c2a6.js';
export async function x18c1eaea1e0dbb623caaf5af(data,csrf){const wire={};const value=await send("/xb3acafb13bb7fc376f824762",wire,csrf);return value["x2d2562af63a0df7657c7ccd7"];}
export async function xbd7b61918868eb9ee7baff1c(data,csrf){const wire={"x5b12a9b51000d45a03cb5b3a":{"x246c9ba7cea98f25162e2a06":data["order_id"]}};const value=await send("/x2c865813779c82430d3e4b5d",wire,csrf);return value["xe17e53ae99c3130972039b29"]["x8955d0b25c4312c764992bc6"];}
