import {send} from './x94d3ded8a6d53a628fb8c2a6.js';
export async function xf0334a673f80ec7e445dba8c(data,csrf){const wire={"xa584c65ead1102f4c0fad145":[]};const value=await send("/xa0cf86b5d6b935c857d43d79",wire,csrf);return value["x8a2dbb796b6855ffcbefe639"]["x5b71b920d43f7618bb6b3388"];}
export async function x517733ed4b94dc764ca20ddf(data,csrf){const wire={"xb87849bf530ed43d246415b1":{}};const value=await send("/x7ee5755f72183428f13ba0db",wire,csrf);return value["xaa5f4f96f33a9ea880b0b175"];}
