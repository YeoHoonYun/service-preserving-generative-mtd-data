# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/xf698f07f6fbe2866bd7c7ebb', 'fields': ['username', 'password'], 'aliases': {'username': 'x85c1a07b69bd44a148f59022', 'password': 'xa595112d99ca36db055af24a'}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x76ffb29f73a6aa925f0750ac', 'response_box': 'xfb7511c6d36cc3ae786e9f76', 'result_key': 'x325768f7115a71b12d497e7d'}, 'logout': {'route': '/xb3acafb13bb7fc376f824762', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x6c2f7f76ef8dd6359aed7f85', 'response_box': 'x3340c356168537bc06c3b42e', 'result_key': 'x2d2562af63a0df7657c7ccd7'}, 'catalog': {'route': '/xa0cf86b5d6b935c857d43d79', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'wrapped', 'request_box': 'xa584c65ead1102f4c0fad145', 'response_box': 'x8a2dbb796b6855ffcbefe639', 'result_key': 'x5b71b920d43f7618bb6b3388'}, 'create_order': {'route': '/xbddc41cfa5aa5515565fb504', 'fields': ['product_id', 'quantity', 'request_id'], 'aliases': {'product_id': 'x036aa583886ec9de05100a9e', 'quantity': 'xb942671e7cff5540340e5ebc', 'request_id': 'xdd6b620c781a267f266fb954'}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'x049d77f9d8a422e19e71a399', 'response_box': 'xc84eb97cbf3d065f373476a4', 'result_key': 'x63d04d9dca86f88332467dff'}, 'order': {'route': '/x2c865813779c82430d3e4b5d', 'fields': ['order_id'], 'aliases': {'order_id': 'x246c9ba7cea98f25162e2a06'}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'x5b12a9b51000d45a03cb5b3a', 'response_box': 'xe17e53ae99c3130972039b29', 'result_key': 'x8955d0b25c4312c764992bc6'}, 'orders': {'route': '/x7ee5755f72183428f13ba0db', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'object', 'request_box': 'xb87849bf530ed43d246415b1', 'response_box': 'x0cfa9436d94a6218349c039a', 'result_key': 'xaa5f4f96f33a9ea880b0b175'}, 'update_product': {'route': '/xa548ab18e748584d283daf28', 'fields': ['product_id', 'stock', 'price'], 'aliases': {'product_id': 'xf82830f5093920d47aad97be', 'stock': 'x4c743346c29896b98514c6a4', 'price': 'xdc3f6626003c797104050414'}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'x07d51561f0327a8a3d22d444', 'response_box': 'xecb16c3d252cc603903743ee', 'result_key': 'x506611d44e8245828ab3aa83'}}
HANDLERS = {'login': 'xbb00595c91a6960c23defdb9', 'logout': 'xe2ab06e7ad20bef3a948eef0', 'catalog': 'x854fa195fe9423740f168a03', 'create_order': 'xd230e581f1a1a9ec97415609', 'order': 'x6b68cf4a8abf19656b832c2b', 'orders': 'x3e16e52ba11277533168937d', 'update_product': 'x7c3cdf35f68b9f3fb4336308'}
BACKEND_GRAPH = {'xbb00595c91a6960c23defdb9': {'operation': 'login', 'target': 'x3b8818ddf7207b527906f66e', 'kind': 'adapter'}, 'x3b8818ddf7207b527906f66e': {'operation': 'login', 'target': 'x93ce0eb58102f57df5434417', 'kind': 'adapter'}, 'x93ce0eb58102f57df5434417': {'operation': 'login', 'target': 'x835ea337c92875bc114d86ce', 'kind': 'adapter'}, 'x835ea337c92875bc114d86ce': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'xe2ab06e7ad20bef3a948eef0': {'operation': 'logout', 'target': 'xbc04d359653ec2e701b3530f', 'kind': 'adapter'}, 'xbc04d359653ec2e701b3530f': {'operation': 'logout', 'target': 'x70310fcf50b6ab6224973e02', 'kind': 'adapter'}, 'x70310fcf50b6ab6224973e02': {'operation': 'logout', 'target': 'x586575fd3ce225a7c142540d', 'kind': 'adapter'}, 'x586575fd3ce225a7c142540d': {'operation': 'logout', 'target': 'x54124c2c808011baff72112c', 'kind': 'adapter'}, 'x54124c2c808011baff72112c': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x854fa195fe9423740f168a03': {'operation': 'catalog', 'target': 'xfd8c13255e7e404428a0f01a', 'kind': 'adapter'}, 'xfd8c13255e7e404428a0f01a': {'operation': 'catalog', 'target': 'x441dad348a4c3110b9e160f8', 'kind': 'adapter'}, 'x441dad348a4c3110b9e160f8': {'operation': 'catalog', 'target': 'x55e6bb64ba6e97299a628474', 'kind': 'adapter'}, 'x55e6bb64ba6e97299a628474': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'xd230e581f1a1a9ec97415609': {'operation': 'create_order', 'target': 'x646eb75fd7dca16293acaced', 'kind': 'adapter'}, 'x646eb75fd7dca16293acaced': {'operation': 'create_order', 'target': 'xd32424e48b8e5da1616c1e4a', 'kind': 'adapter'}, 'xd32424e48b8e5da1616c1e4a': {'operation': 'create_order', 'target': 'x7cdbaa21bfdeeb926089e02f', 'kind': 'adapter'}, 'x7cdbaa21bfdeeb926089e02f': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x6b68cf4a8abf19656b832c2b': {'operation': 'order', 'target': 'xadd5485039a5f5eb2e7d43c4', 'kind': 'adapter'}, 'xadd5485039a5f5eb2e7d43c4': {'operation': 'order', 'target': 'x039fbf3bf1042f0009ef6823', 'kind': 'adapter'}, 'x039fbf3bf1042f0009ef6823': {'operation': 'order', 'target': 'x3737e64488f799f55c5286ce', 'kind': 'adapter'}, 'x3737e64488f799f55c5286ce': {'operation': 'order', 'target': 'xcf768b21ab4d2f2d8c690af6', 'kind': 'adapter'}, 'xcf768b21ab4d2f2d8c690af6': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x3e16e52ba11277533168937d': {'operation': 'orders', 'target': 'x02433eb3f21723dd23c85436', 'kind': 'adapter'}, 'x02433eb3f21723dd23c85436': {'operation': 'orders', 'target': 'x269d348694f9c6d86ada4ee8', 'kind': 'adapter'}, 'x269d348694f9c6d86ada4ee8': {'operation': 'orders', 'target': 'x5aab396b83d8e6e6e0d455d9', 'kind': 'adapter'}, 'x5aab396b83d8e6e6e0d455d9': {'operation': 'orders', 'target': 'x7da16dbc8e9da214c3189818', 'kind': 'adapter'}, 'x7da16dbc8e9da214c3189818': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x7c3cdf35f68b9f3fb4336308': {'operation': 'update_product', 'target': 'x601165501f4c82fd6eb4b406', 'kind': 'adapter'}, 'x601165501f4c82fd6eb4b406': {'operation': 'update_product', 'target': 'x3941fcf797656c4498f94de0', 'kind': 'adapter'}, 'x3941fcf797656c4498f94de0': {'operation': 'update_product', 'target': 'xa30c0fea13fb53ecf8710b5d', 'kind': 'adapter'}, 'xa30c0fea13fb53ecf8710b5d': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xbb00595c91a6960c23defdb9(core, operation, data, session, actor, trace):
    trace.append('xbb00595c91a6960c23defdb9')
    return x3b8818ddf7207b527906f66e(core, operation, data, session, actor, trace)

def x3b8818ddf7207b527906f66e(core, operation, data, session, actor, trace):
    trace.append('x3b8818ddf7207b527906f66e')
    return x93ce0eb58102f57df5434417(core, operation, data, session, actor, trace)

def x93ce0eb58102f57df5434417(core, operation, data, session, actor, trace):
    trace.append('x93ce0eb58102f57df5434417')
    return x835ea337c92875bc114d86ce(core, operation, data, session, actor, trace)

def x835ea337c92875bc114d86ce(core, operation, data, session, actor, trace):
    trace.append('x835ea337c92875bc114d86ce')
    return core.execute(operation, data, session, actor)

def xe2ab06e7ad20bef3a948eef0(core, operation, data, session, actor, trace):
    trace.append('xe2ab06e7ad20bef3a948eef0')
    return xbc04d359653ec2e701b3530f(core, operation, data, session, actor, trace)

def xbc04d359653ec2e701b3530f(core, operation, data, session, actor, trace):
    trace.append('xbc04d359653ec2e701b3530f')
    return x70310fcf50b6ab6224973e02(core, operation, data, session, actor, trace)

def x70310fcf50b6ab6224973e02(core, operation, data, session, actor, trace):
    trace.append('x70310fcf50b6ab6224973e02')
    return x586575fd3ce225a7c142540d(core, operation, data, session, actor, trace)

def x586575fd3ce225a7c142540d(core, operation, data, session, actor, trace):
    trace.append('x586575fd3ce225a7c142540d')
    return x54124c2c808011baff72112c(core, operation, data, session, actor, trace)

def x54124c2c808011baff72112c(core, operation, data, session, actor, trace):
    trace.append('x54124c2c808011baff72112c')
    return core.execute(operation, data, session, actor)

def x854fa195fe9423740f168a03(core, operation, data, session, actor, trace):
    trace.append('x854fa195fe9423740f168a03')
    return xfd8c13255e7e404428a0f01a(core, operation, data, session, actor, trace)

def xfd8c13255e7e404428a0f01a(core, operation, data, session, actor, trace):
    trace.append('xfd8c13255e7e404428a0f01a')
    return x441dad348a4c3110b9e160f8(core, operation, data, session, actor, trace)

def x441dad348a4c3110b9e160f8(core, operation, data, session, actor, trace):
    trace.append('x441dad348a4c3110b9e160f8')
    return x55e6bb64ba6e97299a628474(core, operation, data, session, actor, trace)

def x55e6bb64ba6e97299a628474(core, operation, data, session, actor, trace):
    trace.append('x55e6bb64ba6e97299a628474')
    return core.execute(operation, data, session, actor)

def xd230e581f1a1a9ec97415609(core, operation, data, session, actor, trace):
    trace.append('xd230e581f1a1a9ec97415609')
    return x646eb75fd7dca16293acaced(core, operation, data, session, actor, trace)

def x646eb75fd7dca16293acaced(core, operation, data, session, actor, trace):
    trace.append('x646eb75fd7dca16293acaced')
    return xd32424e48b8e5da1616c1e4a(core, operation, data, session, actor, trace)

def xd32424e48b8e5da1616c1e4a(core, operation, data, session, actor, trace):
    trace.append('xd32424e48b8e5da1616c1e4a')
    return x7cdbaa21bfdeeb926089e02f(core, operation, data, session, actor, trace)

def x7cdbaa21bfdeeb926089e02f(core, operation, data, session, actor, trace):
    trace.append('x7cdbaa21bfdeeb926089e02f')
    return core.execute(operation, data, session, actor)

def x6b68cf4a8abf19656b832c2b(core, operation, data, session, actor, trace):
    trace.append('x6b68cf4a8abf19656b832c2b')
    return xadd5485039a5f5eb2e7d43c4(core, operation, data, session, actor, trace)

def xadd5485039a5f5eb2e7d43c4(core, operation, data, session, actor, trace):
    trace.append('xadd5485039a5f5eb2e7d43c4')
    return x039fbf3bf1042f0009ef6823(core, operation, data, session, actor, trace)

def x039fbf3bf1042f0009ef6823(core, operation, data, session, actor, trace):
    trace.append('x039fbf3bf1042f0009ef6823')
    return x3737e64488f799f55c5286ce(core, operation, data, session, actor, trace)

def x3737e64488f799f55c5286ce(core, operation, data, session, actor, trace):
    trace.append('x3737e64488f799f55c5286ce')
    return xcf768b21ab4d2f2d8c690af6(core, operation, data, session, actor, trace)

def xcf768b21ab4d2f2d8c690af6(core, operation, data, session, actor, trace):
    trace.append('xcf768b21ab4d2f2d8c690af6')
    return core.execute(operation, data, session, actor)

def x3e16e52ba11277533168937d(core, operation, data, session, actor, trace):
    trace.append('x3e16e52ba11277533168937d')
    return x02433eb3f21723dd23c85436(core, operation, data, session, actor, trace)

def x02433eb3f21723dd23c85436(core, operation, data, session, actor, trace):
    trace.append('x02433eb3f21723dd23c85436')
    return x269d348694f9c6d86ada4ee8(core, operation, data, session, actor, trace)

def x269d348694f9c6d86ada4ee8(core, operation, data, session, actor, trace):
    trace.append('x269d348694f9c6d86ada4ee8')
    return x5aab396b83d8e6e6e0d455d9(core, operation, data, session, actor, trace)

def x5aab396b83d8e6e6e0d455d9(core, operation, data, session, actor, trace):
    trace.append('x5aab396b83d8e6e6e0d455d9')
    return x7da16dbc8e9da214c3189818(core, operation, data, session, actor, trace)

def x7da16dbc8e9da214c3189818(core, operation, data, session, actor, trace):
    trace.append('x7da16dbc8e9da214c3189818')
    return core.execute(operation, data, session, actor)

def x7c3cdf35f68b9f3fb4336308(core, operation, data, session, actor, trace):
    trace.append('x7c3cdf35f68b9f3fb4336308')
    return x601165501f4c82fd6eb4b406(core, operation, data, session, actor, trace)

def x601165501f4c82fd6eb4b406(core, operation, data, session, actor, trace):
    trace.append('x601165501f4c82fd6eb4b406')
    return x3941fcf797656c4498f94de0(core, operation, data, session, actor, trace)

def x3941fcf797656c4498f94de0(core, operation, data, session, actor, trace):
    trace.append('x3941fcf797656c4498f94de0')
    return xa30c0fea13fb53ecf8710b5d(core, operation, data, session, actor, trace)

def xa30c0fea13fb53ecf8710b5d(core, operation, data, session, actor, trace):
    trace.append('xa30c0fea13fb53ecf8710b5d')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

ADAPTER_CALLS = {
    'xbb00595c91a6960c23defdb9': xbb00595c91a6960c23defdb9,
    'xe2ab06e7ad20bef3a948eef0': xe2ab06e7ad20bef3a948eef0,
    'x854fa195fe9423740f168a03': x854fa195fe9423740f168a03,
    'xd230e581f1a1a9ec97415609': xd230e581f1a1a9ec97415609,
    'x6b68cf4a8abf19656b832c2b': x6b68cf4a8abf19656b832c2b,
    'x3e16e52ba11277533168937d': x3e16e52ba11277533168937d,
    'x7c3cdf35f68b9f3fb4336308': x7c3cdf35f68b9f3fb4336308
}

def prepare_adapter_job(job):
    handler_name, core, operation, data, session, actor = job['arguments']
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    job['call'] = ADAPTER_CALLS[handler_name]
    job['trace'] = []
    job['call_arguments'] = (core, operation, data, session, actor, job['trace'])

def execute_adapter_job(job):
    status, result, cookie = job['call'](*job['call_arguments'])
    job['response'] = (status, result, cookie)

def finish_adapter_job(job):
    status, result, cookie = job['response']
    return status, result, cookie, job['trace']

def invoke(handler_name, core, operation, data, session, actor):
    job = {'arguments': (handler_name, core, operation, data, session, actor)}
    for stage in (prepare_adapter_job, execute_adapter_job):
        stage(job)
    return finish_adapter_job(job)

