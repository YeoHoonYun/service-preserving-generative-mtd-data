GRAPH = {'xa73de7d1df42510c55b279f8': {'kind': 'router', 'edges': {'/xf698f07f6fbe2866bd7c7ebb': {'target': 'x31c79b29ea7223086e1eb626', 'next_key': 'xd73269dfea7dbab89e09730a'}, '/xb3acafb13bb7fc376f824762': {'target': 'x31c79b29ea7223086e1eb626', 'next_key': 'x258a9bef0a9d760ba2592cca'}, '/xa0cf86b5d6b935c857d43d79': {'target': 'x31c79b29ea7223086e1eb626', 'next_key': 'x304023bd2811e2e22795759d'}, '/xbddc41cfa5aa5515565fb504': {'target': 'x31c79b29ea7223086e1eb626', 'next_key': 'x65b6852945dfd946aed66e1d'}, '/x2c865813779c82430d3e4b5d': {'target': 'x31c79b29ea7223086e1eb626', 'next_key': 'xff689b328078435094d6e1e6'}, '/x7ee5755f72183428f13ba0db': {'target': 'x31c79b29ea7223086e1eb626', 'next_key': 'x3fe0980bdcddbb8a34f62a88'}, '/xa548ab18e748584d283daf28': {'target': 'x31c79b29ea7223086e1eb626', 'next_key': 'xaa9dc35b749ddd8af63ff6e0'}}}, 'x31c79b29ea7223086e1eb626': {'kind': 'router', 'edges': {'xd73269dfea7dbab89e09730a': {'target': 'x0d8d844414c45b2bcc132bf5', 'next_key': 'x7160a8b63e9217ba05175056'}, 'x258a9bef0a9d760ba2592cca': {'target': 'xd8aff5bc42643cd2410e21a3', 'next_key': 'x32aca0f570beea194b2dad06'}, 'x304023bd2811e2e22795759d': {'target': 'x0d8d844414c45b2bcc132bf5', 'next_key': 'x734e00dbface3d4f1c6eff24'}, 'x65b6852945dfd946aed66e1d': {'target': 'xd8aff5bc42643cd2410e21a3', 'next_key': 'x4d2e9f228bb718307a30041b'}, 'xff689b328078435094d6e1e6': {'target': 'x0d8d844414c45b2bcc132bf5', 'next_key': 'x62f31b527c3005a4cfbb0b25'}, 'x3fe0980bdcddbb8a34f62a88': {'target': 'xd8aff5bc42643cd2410e21a3', 'next_key': 'x2e504b7f11d3a5a239c3cc66'}, 'xaa9dc35b749ddd8af63ff6e0': {'target': 'x0d8d844414c45b2bcc132bf5', 'next_key': 'x72a092beee3463e7e0750c1e'}}}, 'xd8aff5bc42643cd2410e21a3': {'kind': 'router', 'edges': {'x32aca0f570beea194b2dad06': {'target': 'x1c03f921cfdf90a4593614a9', 'next_key': 'x2e9f4c1409e544b26605d35f'}, 'x4d2e9f228bb718307a30041b': {'target': 'x1c03f921cfdf90a4593614a9', 'next_key': 'xc0769d5effe3a3496b436723'}, 'x2e504b7f11d3a5a239c3cc66': {'target': 'x1c03f921cfdf90a4593614a9', 'next_key': 'xff10647753d587e6b3af3143'}}}, 'x0d8d844414c45b2bcc132bf5': {'kind': 'router', 'edges': {'x7160a8b63e9217ba05175056': {'target': 'x1c03f921cfdf90a4593614a9', 'next_key': 'xe3704d95012aa3996b43d7be'}, 'x734e00dbface3d4f1c6eff24': {'target': 'x1c03f921cfdf90a4593614a9', 'next_key': 'xd5a737326ebd544c01e7f5cc'}, 'x62f31b527c3005a4cfbb0b25': {'target': 'x1c03f921cfdf90a4593614a9', 'next_key': 'x973a8f794308d1d2986c9315'}, 'x72a092beee3463e7e0750c1e': {'target': 'x1c03f921cfdf90a4593614a9', 'next_key': 'x06ce5c0c3a8985f981b8d4f2'}}}, 'x1c03f921cfdf90a4593614a9': {'kind': 'router', 'edges': {'xe3704d95012aa3996b43d7be': {'target': 'xfa7ddde334fb5b02c6196834', 'next_key': None}, 'x2e9f4c1409e544b26605d35f': {'target': 'xfdcf31c72f394d93c6c0668e', 'next_key': None}, 'xd5a737326ebd544c01e7f5cc': {'target': 'xd082a535b749f9914ae491ba', 'next_key': None}, 'xc0769d5effe3a3496b436723': {'target': 'xef6a59fe0450d89eb8869c09', 'next_key': None}, 'x973a8f794308d1d2986c9315': {'target': 'x3a9aea6a9298ddadd8355483', 'next_key': None}, 'xff10647753d587e6b3af3143': {'target': 'xf493cd4b0e18eeb94b6a0309', 'next_key': None}, 'x06ce5c0c3a8985f981b8d4f2': {'target': 'xd51fb3de27f85ea1749a7ed2', 'next_key': None}}}, 'xfa7ddde334fb5b02c6196834': {'kind': 'service', 'operation': 'login', 'handler': 'xbb00595c91a6960c23defdb9'}, 'xfdcf31c72f394d93c6c0668e': {'kind': 'service', 'operation': 'logout', 'handler': 'xe2ab06e7ad20bef3a948eef0'}, 'xd082a535b749f9914ae491ba': {'kind': 'service', 'operation': 'catalog', 'handler': 'x854fa195fe9423740f168a03'}, 'xef6a59fe0450d89eb8869c09': {'kind': 'service', 'operation': 'create_order', 'handler': 'xd230e581f1a1a9ec97415609'}, 'x3a9aea6a9298ddadd8355483': {'kind': 'service', 'operation': 'order', 'handler': 'x6b68cf4a8abf19656b832c2b'}, 'xf493cd4b0e18eeb94b6a0309': {'kind': 'service', 'operation': 'orders', 'handler': 'x3e16e52ba11277533168937d'}, 'xd51fb3de27f85ea1749a7ed2': {'kind': 'service', 'operation': 'update_product', 'handler': 'x7c3cdf35f68b9f3fb4336308'}}
ENTRY = 'xa73de7d1df42510c55b279f8'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    bindings = []
    for path in graph[entry]['edges']:
        node, key, seen = entry, path, set()
        while True:
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            item = graph[node]
            if item['kind'] == 'service':
                bindings.append((path, node, dict(item)))
                break
            edge = item['edges'][key]
            node, key = edge['target'], edge['next_key']
    prefix = 'branch:'
    while any(name.startswith(prefix) for name in graph):
        prefix = 'r' + prefix
    root = prefix + 'entry'
    rebuilt = {root: {'kind': 'router', 'edges': {}}}
    for path, leaf, service in bindings:
        rebuilt[leaf] = service
        word = service['operation'] or ':'
        first = prefix + 'word:' + word[:1]
        rebuilt[root]['edges'][path] = {'target': first, 'next_key': path}
        for position in range(1, len(word) + 1):
            branch = prefix + 'word:' + word[:position]
            if branch not in rebuilt:
                rebuilt[branch] = {'kind': 'router', 'edges': {}}
            last = position == len(word)
            target = leaf if last else prefix + 'word:' + word[:position + 1]
            rebuilt[branch]['edges'][path] = {
                'target': target, 'next_key': None if last else path
            }
    return rebuilt, root

def resolve(path):
    cursor, key = ENTRY, path
    trace, visited = [], set()
    while cursor not in visited:
        visited.add(cursor)
        trace.append(cursor)
        record = GRAPH[cursor]
        if record['kind'] == 'service':
            return record['operation'], record['handler'], trace
        transition = record['edges'][key]
        cursor, key = transition['target'], transition['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
