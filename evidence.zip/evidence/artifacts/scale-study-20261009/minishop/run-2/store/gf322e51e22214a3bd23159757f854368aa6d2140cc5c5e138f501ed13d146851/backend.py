# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/xd7a746feb5198a179634844e', 'fields': ['username', 'password'], 'aliases': {'username': 'xb88a22f4f8f23a38da1a5187', 'password': 'xc0dfb2f065087c4dac786823'}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'xb33c47b6c91bdc9b4f92c403', 'response_box': 'x1f25ecce676675e771dcc9fa', 'result_key': 'x51cc6105c03a0c9482d1fb2c'}, 'logout': {'route': '/xfe9e874d955d3a0319119c48', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'x3224d0fc51062d188dcae08b', 'response_box': 'xfcb2aa2f935314deadbc9444', 'result_key': 'x548216896b9a140f04b54480'}, 'catalog': {'route': '/x385221c3b30d693944e7b5a9', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'x72555f9392d9f3ba654bb6d6', 'response_box': 'xca17076f6f6dfbfc9f697f64', 'result_key': 'xaedc2f9c0204cc5106f495fd'}, 'create_order': {'route': '/xd468e625890e0743d465a026', 'fields': ['request_id', 'product_id', 'quantity'], 'aliases': {'request_id': 'xa1eb48b13e09363b44cea51a', 'product_id': 'xb28f707e84f92350d9b6971a', 'quantity': 'xe2c565ab7ee237a699acd067'}, 'request_shape': 'pairs', 'response_shape': 'wrapped', 'request_box': 'x11ee6fd687ffbe40f52eb772', 'response_box': 'x27350486694b1cd2fd0588b1', 'result_key': 'xd9ab215b7bd4ec0ab7d39900'}, 'order': {'route': '/x823a4cae4cf89fd38c5c69c4', 'fields': ['order_id'], 'aliases': {'order_id': 'xd23e2b77b5a077a625a030d0'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x9f4fae53a5da6615a7e923c4', 'response_box': 'xb849b172d6c7d6501817bc75', 'result_key': 'x4da549ac46d69e27d1397ea2'}, 'orders': {'route': '/xdbfa746f41867acd674783cd', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'wrapped', 'request_box': 'xd6b8410540c5c5d060b2a330', 'response_box': 'x6e9a2a0f1b31cd236d1984e2', 'result_key': 'xb6d316971193be9591fcd5a7'}, 'update_product': {'route': '/x64bd63b6300d8692d7b5d67e', 'fields': ['price', 'stock', 'product_id'], 'aliases': {'price': 'xb985479ba83aed4a8c3f48e7', 'stock': 'xa56a76cb2384479563ae872c', 'product_id': 'x1b3cc9fce7229515e0ac11f1'}, 'request_shape': 'positional', 'response_shape': 'array', 'request_box': 'xdc3af516e7a8bdd759f20574', 'response_box': 'x85d36210c3c83430963ab1ea', 'result_key': 'x37f0922257c7ef61cecbbcd1'}}
HANDLERS = {'login': 'x18eae102cc11500dad098c71', 'logout': 'xc4fc549137d2de9a72b631f3', 'catalog': 'x75764dbe9634c003b2092d46', 'create_order': 'x77777b11ae3ed2e7fc67ba6a', 'order': 'xb12ca849c530eae9be47170f', 'orders': 'x0ea0f67475f63c9acf55597e', 'update_product': 'xa1cf534d77afe4eab630a2cb'}
BACKEND_GRAPH = {'x18eae102cc11500dad098c71': {'operation': 'login', 'target': 'xc6a12db1c6a0deb6711b91ff', 'kind': 'adapter'}, 'xc6a12db1c6a0deb6711b91ff': {'operation': 'login', 'target': 'x57663b6f1a51a766302b6658', 'kind': 'adapter'}, 'x57663b6f1a51a766302b6658': {'operation': 'login', 'target': 'x017d30584bcc2de1a108de72', 'kind': 'adapter'}, 'x017d30584bcc2de1a108de72': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'xc4fc549137d2de9a72b631f3': {'operation': 'logout', 'target': 'xb50544c463c03eb755a3f87b', 'kind': 'adapter'}, 'xb50544c463c03eb755a3f87b': {'operation': 'logout', 'target': 'xd2cdfc9deeaa7dfe570a5dcd', 'kind': 'adapter'}, 'xd2cdfc9deeaa7dfe570a5dcd': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x75764dbe9634c003b2092d46': {'operation': 'catalog', 'target': 'x16e6c28719b3a21ede8302ea', 'kind': 'adapter'}, 'x16e6c28719b3a21ede8302ea': {'operation': 'catalog', 'target': 'xce3e8e55fa3d5ee459907df4', 'kind': 'adapter'}, 'xce3e8e55fa3d5ee459907df4': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x77777b11ae3ed2e7fc67ba6a': {'operation': 'create_order', 'target': 'xd9e06cd6d69045ee64a3ecd2', 'kind': 'adapter'}, 'xd9e06cd6d69045ee64a3ecd2': {'operation': 'create_order', 'target': 'x9f6fd192fb1c9c4e446f25c2', 'kind': 'adapter'}, 'x9f6fd192fb1c9c4e446f25c2': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'xb12ca849c530eae9be47170f': {'operation': 'order', 'target': 'xa6958537d5957ee86c92bdd2', 'kind': 'adapter'}, 'xa6958537d5957ee86c92bdd2': {'operation': 'order', 'target': 'x7562933bbbcbee255a868595', 'kind': 'adapter'}, 'x7562933bbbcbee255a868595': {'operation': 'order', 'target': 'x70ec0117f45b46db6bb3fcae', 'kind': 'adapter'}, 'x70ec0117f45b46db6bb3fcae': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x0ea0f67475f63c9acf55597e': {'operation': 'orders', 'target': 'x005140e1004bf977175e5f92', 'kind': 'adapter'}, 'x005140e1004bf977175e5f92': {'operation': 'orders', 'target': 'xb7265ee4a71e0f0165f9aa4a', 'kind': 'adapter'}, 'xb7265ee4a71e0f0165f9aa4a': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'xa1cf534d77afe4eab630a2cb': {'operation': 'update_product', 'target': 'x99b060cd245d77f525e75283', 'kind': 'adapter'}, 'x99b060cd245d77f525e75283': {'operation': 'update_product', 'target': 'xf241f18a751234f1a2e9192d', 'kind': 'adapter'}, 'xf241f18a751234f1a2e9192d': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def x18eae102cc11500dad098c71(core, operation, data, session, actor, trace):
    trace.append('x18eae102cc11500dad098c71')
    return xc6a12db1c6a0deb6711b91ff(core, operation, data, session, actor, trace)

def xc6a12db1c6a0deb6711b91ff(core, operation, data, session, actor, trace):
    trace.append('xc6a12db1c6a0deb6711b91ff')
    return x57663b6f1a51a766302b6658(core, operation, data, session, actor, trace)

def x57663b6f1a51a766302b6658(core, operation, data, session, actor, trace):
    trace.append('x57663b6f1a51a766302b6658')
    return x017d30584bcc2de1a108de72(core, operation, data, session, actor, trace)

def x017d30584bcc2de1a108de72(core, operation, data, session, actor, trace):
    trace.append('x017d30584bcc2de1a108de72')
    return core.execute(operation, data, session, actor)

def xc4fc549137d2de9a72b631f3(core, operation, data, session, actor, trace):
    trace.append('xc4fc549137d2de9a72b631f3')
    return xb50544c463c03eb755a3f87b(core, operation, data, session, actor, trace)

def xb50544c463c03eb755a3f87b(core, operation, data, session, actor, trace):
    trace.append('xb50544c463c03eb755a3f87b')
    return xd2cdfc9deeaa7dfe570a5dcd(core, operation, data, session, actor, trace)

def xd2cdfc9deeaa7dfe570a5dcd(core, operation, data, session, actor, trace):
    trace.append('xd2cdfc9deeaa7dfe570a5dcd')
    return core.execute(operation, data, session, actor)

def x75764dbe9634c003b2092d46(core, operation, data, session, actor, trace):
    trace.append('x75764dbe9634c003b2092d46')
    return x16e6c28719b3a21ede8302ea(core, operation, data, session, actor, trace)

def x16e6c28719b3a21ede8302ea(core, operation, data, session, actor, trace):
    trace.append('x16e6c28719b3a21ede8302ea')
    return xce3e8e55fa3d5ee459907df4(core, operation, data, session, actor, trace)

def xce3e8e55fa3d5ee459907df4(core, operation, data, session, actor, trace):
    trace.append('xce3e8e55fa3d5ee459907df4')
    return core.execute(operation, data, session, actor)

def x77777b11ae3ed2e7fc67ba6a(core, operation, data, session, actor, trace):
    trace.append('x77777b11ae3ed2e7fc67ba6a')
    return xd9e06cd6d69045ee64a3ecd2(core, operation, data, session, actor, trace)

def xd9e06cd6d69045ee64a3ecd2(core, operation, data, session, actor, trace):
    trace.append('xd9e06cd6d69045ee64a3ecd2')
    return x9f6fd192fb1c9c4e446f25c2(core, operation, data, session, actor, trace)

def x9f6fd192fb1c9c4e446f25c2(core, operation, data, session, actor, trace):
    trace.append('x9f6fd192fb1c9c4e446f25c2')
    return core.execute(operation, data, session, actor)

def xb12ca849c530eae9be47170f(core, operation, data, session, actor, trace):
    trace.append('xb12ca849c530eae9be47170f')
    return xa6958537d5957ee86c92bdd2(core, operation, data, session, actor, trace)

def xa6958537d5957ee86c92bdd2(core, operation, data, session, actor, trace):
    trace.append('xa6958537d5957ee86c92bdd2')
    return x7562933bbbcbee255a868595(core, operation, data, session, actor, trace)

def x7562933bbbcbee255a868595(core, operation, data, session, actor, trace):
    trace.append('x7562933bbbcbee255a868595')
    return x70ec0117f45b46db6bb3fcae(core, operation, data, session, actor, trace)

def x70ec0117f45b46db6bb3fcae(core, operation, data, session, actor, trace):
    trace.append('x70ec0117f45b46db6bb3fcae')
    return core.execute(operation, data, session, actor)

def x0ea0f67475f63c9acf55597e(core, operation, data, session, actor, trace):
    trace.append('x0ea0f67475f63c9acf55597e')
    return x005140e1004bf977175e5f92(core, operation, data, session, actor, trace)

def x005140e1004bf977175e5f92(core, operation, data, session, actor, trace):
    trace.append('x005140e1004bf977175e5f92')
    return xb7265ee4a71e0f0165f9aa4a(core, operation, data, session, actor, trace)

def xb7265ee4a71e0f0165f9aa4a(core, operation, data, session, actor, trace):
    trace.append('xb7265ee4a71e0f0165f9aa4a')
    return core.execute(operation, data, session, actor)

def xa1cf534d77afe4eab630a2cb(core, operation, data, session, actor, trace):
    trace.append('xa1cf534d77afe4eab630a2cb')
    return x99b060cd245d77f525e75283(core, operation, data, session, actor, trace)

def x99b060cd245d77f525e75283(core, operation, data, session, actor, trace):
    trace.append('x99b060cd245d77f525e75283')
    return xf241f18a751234f1a2e9192d(core, operation, data, session, actor, trace)

def xf241f18a751234f1a2e9192d(core, operation, data, session, actor, trace):
    trace.append('xf241f18a751234f1a2e9192d')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

ADAPTER_ENTRIES = {
    'x18eae102cc11500dad098c71': x18eae102cc11500dad098c71,
    'xc4fc549137d2de9a72b631f3': xc4fc549137d2de9a72b631f3,
    'x75764dbe9634c003b2092d46': x75764dbe9634c003b2092d46,
    'x77777b11ae3ed2e7fc67ba6a': x77777b11ae3ed2e7fc67ba6a,
    'xb12ca849c530eae9be47170f': xb12ca849c530eae9be47170f,
    'x0ea0f67475f63c9acf55597e': x0ea0f67475f63c9acf55597e,
    'xa1cf534d77afe4eab630a2cb': xa1cf534d77afe4eab630a2cb
}

def checked_adapter(handler_name, operation):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    adapter = ADAPTER_ENTRIES[handler_name]
    node = handler_name
    visited = set()
    while node != 'core.execute':
        if node in visited:
            raise ValueError('adapter cycle')
        visited.add(node)
        descriptor = BACKEND_GRAPH[node]
        if descriptor['operation'] != operation:
            raise ValueError('handler')
        node = descriptor['target']
    return adapter

def invoke(handler_name, core, operation, data, session, actor):
    adapter = checked_adapter(handler_name, operation)
    trace = []
    status, result, cookie = adapter(core, operation, data, session, actor, trace)
    return status, result, cookie, trace

