import {send} from './x89e9d15ad346206678babd45.js';
export async function x7e4d04035e832d1ae62b5731(data,csrf){const wire={"xb33c47b6c91bdc9b4f92c403":[["xb88a22f4f8f23a38da1a5187",data["username"]],["xc0dfb2f065087c4dac786823",data["password"]]]};const value=await send("/xd7a746feb5198a179634844e",wire,csrf);return value[0];}
export async function x19bed12decf5ce9beb860f6e(data,csrf){const wire={};const value=await send("/x385221c3b30d693944e7b5a9",wire,csrf);return value[0];}
export async function x9cf79c35ddcf4629323a9d93(data,csrf){const wire={"xd23e2b77b5a077a625a030d0":data["order_id"]};const value=await send("/x823a4cae4cf89fd38c5c69c4",wire,csrf);return value["x4da549ac46d69e27d1397ea2"];}
export async function xe2d8d5c1eb6a285343aa561a(data,csrf){const wire=[data["price"],data["stock"],data["product_id"]];const value=await send("/x64bd63b6300d8692d7b5d67e",wire,csrf);return value[0];}
