GRAPH = {'x1af4e2d86e53264340379aea': {'kind': 'router', 'edges': {'/xd7a746feb5198a179634844e': {'target': 'xfeb53654cf7ad2a8c9d476c4', 'next_key': 'x408a06d3d6b46822d4f0bd3b'}, '/xfe9e874d955d3a0319119c48': {'target': 'xfeb53654cf7ad2a8c9d476c4', 'next_key': 'x0502d31f5fe35015117de86b'}, '/x385221c3b30d693944e7b5a9': {'target': 'xfeb53654cf7ad2a8c9d476c4', 'next_key': 'x164a2a83bf40c12bd8aff5a1'}, '/xd468e625890e0743d465a026': {'target': 'xfeb53654cf7ad2a8c9d476c4', 'next_key': 'x0a925af523bf10698e694259'}, '/x823a4cae4cf89fd38c5c69c4': {'target': 'xfeb53654cf7ad2a8c9d476c4', 'next_key': 'x853632545d2abc9441126bca'}, '/xdbfa746f41867acd674783cd': {'target': 'xfeb53654cf7ad2a8c9d476c4', 'next_key': 'x952b70a05f434f98e124dbaa'}, '/x64bd63b6300d8692d7b5d67e': {'target': 'xfeb53654cf7ad2a8c9d476c4', 'next_key': 'xf08b0cddc774f8fa3bd0adca'}}}, 'xfeb53654cf7ad2a8c9d476c4': {'kind': 'router', 'edges': {'x408a06d3d6b46822d4f0bd3b': {'target': 'xd28e0d05b4dec2e3b8d76cfd', 'next_key': 'x1512e94a748d59cc0362ed45'}, 'x0502d31f5fe35015117de86b': {'target': 'xd28e0d05b4dec2e3b8d76cfd', 'next_key': 'xa30e16702520d43707293bda'}, 'x164a2a83bf40c12bd8aff5a1': {'target': 'xd28e0d05b4dec2e3b8d76cfd', 'next_key': 'x5925e4872ccab90bd5dbec46'}, 'x0a925af523bf10698e694259': {'target': 'xd28e0d05b4dec2e3b8d76cfd', 'next_key': 'x0e3752bc37f1283d314d0029'}, 'x853632545d2abc9441126bca': {'target': 'xd28e0d05b4dec2e3b8d76cfd', 'next_key': 'x3f5685dfb7c29210a1d6d579'}, 'x952b70a05f434f98e124dbaa': {'target': 'xd28e0d05b4dec2e3b8d76cfd', 'next_key': 'x617c3c97b1bc199634ea2ef8'}, 'xf08b0cddc774f8fa3bd0adca': {'target': 'xd28e0d05b4dec2e3b8d76cfd', 'next_key': 'x72342837e544a9558c038e7f'}}}, 'xd28e0d05b4dec2e3b8d76cfd': {'kind': 'router', 'edges': {'x1512e94a748d59cc0362ed45': {'target': 'xd49302efe4cac9ead627e326', 'next_key': None}, 'xa30e16702520d43707293bda': {'target': 'x938edfaa377f089631a19d99', 'next_key': None}, 'x5925e4872ccab90bd5dbec46': {'target': 'x1af014b482dd05739582a4b4', 'next_key': None}, 'x0e3752bc37f1283d314d0029': {'target': 'x7c1f8fb59b01dd85b465a6ad', 'next_key': None}, 'x3f5685dfb7c29210a1d6d579': {'target': 'xde14e772e8745c7d62921b1e', 'next_key': None}, 'x617c3c97b1bc199634ea2ef8': {'target': 'x3cef8fb640c2546b47a36761', 'next_key': None}, 'x72342837e544a9558c038e7f': {'target': 'xbbea1f2a18f6bb1cb788c248', 'next_key': None}}}, 'xd49302efe4cac9ead627e326': {'kind': 'service', 'operation': 'login', 'handler': 'x18eae102cc11500dad098c71'}, 'x938edfaa377f089631a19d99': {'kind': 'service', 'operation': 'logout', 'handler': 'xc4fc549137d2de9a72b631f3'}, 'x1af014b482dd05739582a4b4': {'kind': 'service', 'operation': 'catalog', 'handler': 'x75764dbe9634c003b2092d46'}, 'x7c1f8fb59b01dd85b465a6ad': {'kind': 'service', 'operation': 'create_order', 'handler': 'x77777b11ae3ed2e7fc67ba6a'}, 'xde14e772e8745c7d62921b1e': {'kind': 'service', 'operation': 'order', 'handler': 'xb12ca849c530eae9be47170f'}, 'x3cef8fb640c2546b47a36761': {'kind': 'service', 'operation': 'orders', 'handler': 'x0ea0f67475f63c9acf55597e'}, 'xbbea1f2a18f6bb1cb788c248': {'kind': 'service', 'operation': 'update_product', 'handler': 'xa1cf534d77afe4eab630a2cb'}}
ENTRY = 'x1af4e2d86e53264340379aea'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def routing_name(reserved, label):
    name = 'route_' + label
    while name in reserved:
        name += 'r'
    reserved.add(name)
    return name

def rewrite_graph(graph, entry):
    rebuilt = {}
    reserved = set(graph)
    clusters = []
    for index, path in enumerate(graph[entry]['edges']):
        node, key = entry, path
        visited = set()
        while graph[node]['kind'] != 'service':
            if node in visited:
                raise ValueError('routing cycle')
            visited.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        service = graph[node]
        rebuilt[node] = dict(service)
        relay = routing_name(reserved, 'leaf_' + str(index))
        rebuilt[relay] = {'kind': 'router', 'edges': {path: {'target': node, 'next_key': None}}}
        clusters.append((len(service['operation']) + 1, index, relay, [path]))
    serial = len(clusters)
    if serial < 2:
        root = routing_name(reserved, 'root')
        edges = {}
        if clusters:
            child = clusters[0]
            for path in child[3]:
                edges[path] = {'target': child[2], 'next_key': path}
        rebuilt[root] = {'kind': 'router', 'edges': edges}
        return rebuilt, root
    while len(clusters) > 1:
        clusters.sort()
        left = clusters.pop(0)
        right = clusters.pop(0)
        parent = routing_name(reserved, 'merge_' + str(serial))
        edges = {}
        for child in (left, right):
            for path in child[3]:
                edges[path] = {'target': child[2], 'next_key': path}
        rebuilt[parent] = {'kind': 'router', 'edges': edges}
        clusters.append((left[0] + right[0], serial, parent, left[3] + right[3]))
        serial += 1
    return rebuilt, clusters[0][2]

def resolve(path):
    node, key = ENTRY, path
    visited, trace = set(), []
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
