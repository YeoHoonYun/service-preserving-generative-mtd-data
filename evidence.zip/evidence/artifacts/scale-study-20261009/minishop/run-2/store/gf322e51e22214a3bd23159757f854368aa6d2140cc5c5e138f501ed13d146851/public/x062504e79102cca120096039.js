import {x7e4d04035e832d1ae62b5731,x19bed12decf5ce9beb860f6e,x9cf79c35ddcf4629323a9d93,xe2d8d5c1eb6a285343aa561a} from './xdeee3f40df27a243bd526e6c.js';
import {xf64743908db5e1121bf16d5e,x544de4f5b38ac59d7f5ddf1e,x2aa1b94ab53c1e9b18c08096} from './xb3520f5d3babebfcb71a2cd5.js';

const state={boot:JSON.parse(document.querySelector('meta[name=boot]').content)};
const message=document.getElementById('x778e7e25373607c3a7a364ad');
const endpoints={login:x7e4d04035e832d1ae62b5731,logout:xf64743908db5e1121bf16d5e,catalog:x19bed12decf5ce9beb860f6e,create_order:x544de4f5b38ac59d7f5ddf1e,order:x9cf79c35ddcf4629323a9d93,orders:x2aa1b94ab53c1e9b18c08096,update_product:xe2d8d5c1eb6a285343aa561a};
async function api(operation,data={}){return endpoints[operation](data,state.boot.csrf);}
function identity(){document.getElementById('x10b0982e0e5bd1b0fe8ddfff').textContent=state.boot.user?state.boot.user.id:'방문자';}
function protect(callback){
  return async (...args)=>{
    try{await callback(...args);}
    catch(error){message.textContent=error.message;}
  };
}
function readForm(form){
  const raw=Object.fromEntries(new FormData(form));
  return {username:raw['xd56f7b63d1b9ae56df584910'],password:raw['x09f9adb0caa6e0eae067a385'],product_id:raw['x2a60c13d13bd00cba23c4ceb'],quantity:raw['x20e25f1d6b22482ed6590fdf'],price:raw['xeccf752413ed165693e8f08c'],stock:raw['xa62b531310050898708b718c']};
}
async function catalog(){
  const list=document.getElementById('x86ff37cd4a1a8709249b79c6');
  list.replaceChildren();
  for(const p of await api('catalog')){
    const li=document.createElement('li');
    li.textContent=p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock;
    list.append(li);
  }
  document.body.dataset.ready='yes';
}
async function orders(){
  const list=document.getElementById('xde810ee9e95ddedd3a013388');
  list.replaceChildren();
  for(const order of await api('orders')){
    const li=document.createElement('li');
    li.textContent=order.id+' · '+order.total+'원';
    list.append(li);
  }
}
async function signIn(data){
  state.boot=await api('login',data);
  identity();
  message.textContent='로그인되었습니다.';
}
async function purchase(data){
  const order=await api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()});
  message.textContent='주문 '+order.id+' · '+order.total+'원';
  await catalog();
  await orders();
}
async function changeProduct(data){
  await api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)});
  message.textContent='상품을 수정했습니다.';
  await catalog();
}
async function submit(form,data){
  if(form.dataset.action==='xa2cf1dd76e6e4d5854045a47') await signIn(data);
  if(form.dataset.action==='xf4d2c2c85dabf52d7322f1ce') await purchase(data);
  if(form.dataset.action==='x1be0d185c24779aaff8d8825') await changeProduct(data);
}
document.addEventListener('submit',protect(event=>{
  event.preventDefault();
  const form=event.target;
  return submit(form,readForm(form));
}));
document.getElementById('x762cb0c925fe776153268b7d').onclick=protect(async()=>{
  await api('logout');
  location.reload();
});
document.getElementById('xadf7212e3f049b6eabdf58ea').onclick=protect(orders);
identity();
protect(catalog)();
