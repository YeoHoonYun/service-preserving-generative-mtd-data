import {send} from './x8c0dcb0104e0ba88a39d425f.js';
export async function xd52c32949d32b5e4708e0fc1(data,csrf){const wire={"xfa0dd0b662343e28eeea8956":{}};const value=await send("/x8fdde0ad06ecd48db1c3f127",wire,csrf);return value[0];}
export async function x19ad85367a9e541f679723f4(data,csrf){const wire=[data["order_id"]];const value=await send("/x39390b52a61fd461a938d4ef",wire,csrf);return value["xa922966dab597aad21d1b454"];}
