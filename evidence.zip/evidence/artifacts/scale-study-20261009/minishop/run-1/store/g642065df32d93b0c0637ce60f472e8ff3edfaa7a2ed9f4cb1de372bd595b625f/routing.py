GRAPH = {'x13fe13705a033eafb4d375a0': {'kind': 'router', 'edges': {'/xc3aebbe29730350671cf5c0c': {'target': 'xf2f9b43f1c5b1c8348de6f3e', 'next_key': 'xa42acdcf01d8a6f5adaacc96'}, '/x8fdde0ad06ecd48db1c3f127': {'target': 'xf2f9b43f1c5b1c8348de6f3e', 'next_key': 'xdbc424c9ac23eae10ca51833'}, '/x08b461119a3ef3cde7f6c782': {'target': 'xf2f9b43f1c5b1c8348de6f3e', 'next_key': 'xb431eb1d00f4d187aab057b0'}, '/xd77ce254d3c7f2a51872f4cc': {'target': 'xf2f9b43f1c5b1c8348de6f3e', 'next_key': 'x344084b33d23954794c0c70f'}, '/x39390b52a61fd461a938d4ef': {'target': 'xf2f9b43f1c5b1c8348de6f3e', 'next_key': 'xcb12c98069ed6a882cf8bfdf'}, '/xa2b05b87c10ccc75c987ef83': {'target': 'xf2f9b43f1c5b1c8348de6f3e', 'next_key': 'xc6311423a5dc7dafa388172c'}, '/xe61db8cb2e4c8d7ea065bf08': {'target': 'xf2f9b43f1c5b1c8348de6f3e', 'next_key': 'xe33ad733f35d269e10b3e015'}}}, 'xf2f9b43f1c5b1c8348de6f3e': {'kind': 'router', 'edges': {'xa42acdcf01d8a6f5adaacc96': {'target': 'x2e46a5f14c534d2e6d0c333b', 'next_key': 'x7442d786e65493b1511917b6'}, 'xdbc424c9ac23eae10ca51833': {'target': 'x085053a3478e71c3e22f4cf1', 'next_key': 'xf4ea67814457d6408ecfd3d2'}, 'xb431eb1d00f4d187aab057b0': {'target': 'x2e46a5f14c534d2e6d0c333b', 'next_key': 'xa120f59857f8d8855281e2ce'}, 'x344084b33d23954794c0c70f': {'target': 'x085053a3478e71c3e22f4cf1', 'next_key': 'x502c85598b3ff7e320a2baae'}, 'xcb12c98069ed6a882cf8bfdf': {'target': 'x2e46a5f14c534d2e6d0c333b', 'next_key': 'x6cf6f099a1f9bf852c7c45fb'}, 'xc6311423a5dc7dafa388172c': {'target': 'x085053a3478e71c3e22f4cf1', 'next_key': 'xa499512e5d6847454e0653c2'}, 'xe33ad733f35d269e10b3e015': {'target': 'x2e46a5f14c534d2e6d0c333b', 'next_key': 'x09d016869e798a73d1ed8b0d'}}}, 'x085053a3478e71c3e22f4cf1': {'kind': 'router', 'edges': {'xf4ea67814457d6408ecfd3d2': {'target': 'xe29e30072cfef5c5f55b69c7', 'next_key': 'xfd031e21b2af4529a048d950'}, 'x502c85598b3ff7e320a2baae': {'target': 'xe29e30072cfef5c5f55b69c7', 'next_key': 'xa4459211e925ff30f8ac5272'}, 'xa499512e5d6847454e0653c2': {'target': 'xe29e30072cfef5c5f55b69c7', 'next_key': 'xb8d0fa3763239da08c4fc4f2'}}}, 'x2e46a5f14c534d2e6d0c333b': {'kind': 'router', 'edges': {'x7442d786e65493b1511917b6': {'target': 'xa993bd7d5a44f786ab6f8454', 'next_key': 'x7426d5856e7ca9c92fe57dd0'}, 'xa120f59857f8d8855281e2ce': {'target': 'xa993bd7d5a44f786ab6f8454', 'next_key': 'xc63f664f5d1d664acb14dbda'}, 'x6cf6f099a1f9bf852c7c45fb': {'target': 'xa993bd7d5a44f786ab6f8454', 'next_key': 'xd8ffa829fed60dfdd99f58ca'}, 'x09d016869e798a73d1ed8b0d': {'target': 'xa993bd7d5a44f786ab6f8454', 'next_key': 'x1d5032a028549c0d9a6e2bf9'}}}, 'xa993bd7d5a44f786ab6f8454': {'kind': 'router', 'edges': {'x7426d5856e7ca9c92fe57dd0': {'target': 'x0523df0ad237db6539ccb1f6', 'next_key': None}, 'xc63f664f5d1d664acb14dbda': {'target': 'xaab9b734434cda93f729c5b5', 'next_key': None}, 'xd8ffa829fed60dfdd99f58ca': {'target': 'x681ccf2b4c741d13396af6a6', 'next_key': None}, 'x1d5032a028549c0d9a6e2bf9': {'target': 'x302b3280203fda63d743483c', 'next_key': None}}}, 'xe29e30072cfef5c5f55b69c7': {'kind': 'router', 'edges': {'xfd031e21b2af4529a048d950': {'target': 'xc2298e6a24e918e40f1cf51e', 'next_key': None}, 'xa4459211e925ff30f8ac5272': {'target': 'xac0261d7a41ebe6598e36449', 'next_key': None}, 'xb8d0fa3763239da08c4fc4f2': {'target': 'x96892b07bd79175832ba6d78', 'next_key': None}}}, 'x0523df0ad237db6539ccb1f6': {'kind': 'service', 'operation': 'login', 'handler': 'x470e0faae3658dba7a9dfea5'}, 'xc2298e6a24e918e40f1cf51e': {'kind': 'service', 'operation': 'logout', 'handler': 'x44ecc39603ac7e58a498b88f'}, 'xaab9b734434cda93f729c5b5': {'kind': 'service', 'operation': 'catalog', 'handler': 'x53cabd2ac60cb2c16970462f'}, 'xac0261d7a41ebe6598e36449': {'kind': 'service', 'operation': 'create_order', 'handler': 'x6d06df37d44eb60338f31da6'}, 'x681ccf2b4c741d13396af6a6': {'kind': 'service', 'operation': 'order', 'handler': 'xc8db4cc688b7a1696a710548'}, 'x96892b07bd79175832ba6d78': {'kind': 'service', 'operation': 'orders', 'handler': 'x4e308c2bf7d7ba7933f77023'}, 'x302b3280203fda63d743483c': {'kind': 'service', 'operation': 'update_product', 'handler': 'xe3fa0ae87aaf8e3307974a82'}}
ENTRY = 'x13fe13705a033eafb4d375a0'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    bindings = []
    for path in graph[entry]['edges']:
        node, key = entry, path
        seen = set()
        while graph[node]['kind'] != 'service':
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        bindings.append((path, node))
    root = 'residue_entry'
    rebuilt = {root: {'kind': 'router', 'edges': {}}}
    leaves = {}
    for path, old_leaf in bindings:
        if old_leaf not in leaves:
            leaf = 'binding_' + str(len(leaves))
            leaves[old_leaf] = leaf
            rebuilt[leaf] = dict(graph[old_leaf])
        leaf = leaves[old_leaf]
        bucket = 'suffix_' + str(ord(path[-1]) % 2)
        residue = sum(ord(character) for character in path) % 3
        cell = bucket + '_sum_' + str(residue)
        for name in (bucket, cell):
            if name not in rebuilt:
                rebuilt[name] = {'kind': 'router', 'edges': {}}
        rebuilt[root]['edges'][path] = {'target': bucket, 'next_key': path}
        rebuilt[bucket]['edges'][path] = {'target': cell, 'next_key': path}
        rebuilt[cell]['edges'][path] = {'target': leaf, 'next_key': None}
    return rebuilt, root

def resolve(path):
    node, key = ENTRY, path
    visited, trace = set(), []
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
