import {send} from './x8c0dcb0104e0ba88a39d425f.js';
export async function xdbfa5d2e453c82cb4cae3501(data,csrf){const wire={"x736f7b255e4a44cd3584ecd0":[]};const value=await send("/x08b461119a3ef3cde7f6c782",wire,csrf);return value["x05cdeec28c7d1f37b3a6301d"];}
export async function xeb4c9ce825ae780b0428679d(data,csrf){const wire={"xb8d57ca5c1944d80de811900":[]};const value=await send("/xa2b05b87c10ccc75c987ef83",wire,csrf);return value[0];}
