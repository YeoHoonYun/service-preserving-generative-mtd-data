import {x17c180962c67f598662a80f5,xee83b4a044ad37c5bbaf04a9,x82510abbf2b8322f7894d36f} from './x35c1b73b5ef92f70547ee699.js';
import {xd52c32949d32b5e4708e0fc1,x19ad85367a9e541f679723f4} from './x47ff82abd287ea5c44aa0a7d.js';
import {xdbfa5d2e453c82cb4cae3501,xeb4c9ce825ae780b0428679d} from './x34a9542d2e299c01fa4d93aa.js';
let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('xc310fdd72ea54bf3bfc07f3a');
const endpoints={login:x17c180962c67f598662a80f5,logout:xd52c32949d32b5e4708e0fc1,catalog:xdbfa5d2e453c82cb4cae3501,create_order:xee83b4a044ad37c5bbaf04a9,order:x19ad85367a9e541f679723f4,orders:xeb4c9ce825ae780b0428679d,update_product:x82510abbf2b8322f7894d36f};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('x4e31373463a2f2f4e90403f1').textContent=boot.user?boot.user.id:'방문자';}
function run(promise){promise.catch(error=>message.textContent=error.message);}
const lists={
 catalog:{id:'xc79aafa06a58a5fc8a6d6ec5',text:p=>p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock},
 orders:{id:'xb8f48239a2c4616e3baa7f52',text:order=>order.id+' · '+order.total+'원'}
};
async function renderList(operation){
 const spec=lists[operation];
 const list=document.getElementById(spec.id);
 list.replaceChildren();
 for(const value of await api(operation)){
  const li=document.createElement('li');
  li.textContent=spec.text(value);
  list.append(li);
 }
 if(operation==='catalog')document.body.dataset.ready='yes';
}
function catalog(){return renderList('catalog');}
function orders(){return renderList('orders');}
async function executeSteps(steps,frame){
 for(const step of steps){
  const pending=step(frame);
  if(pending&&typeof pending.then==='function')frame.result=await pending;
 }
}
const formPlans=[
 ['x6d6ed08fb5fca5edb47ee31c',[
  frame=>api('login',frame.data),
  frame=>{boot=frame.result;identity();message.textContent='로그인되었습니다.';}
 ]],
 ['x11260762d5c0a1a775c5aa74',[
  frame=>api('create_order',{product_id:frame.data.product_id,quantity:Number(frame.data.quantity),request_id:crypto.randomUUID()}),
  frame=>{message.textContent='주문 '+frame.result.id+' · '+frame.result.total+'원';},
  ()=>catalog(),
  ()=>orders()
 ]],
 ['x02da99dc74aaa50203c0e3b0',[
  frame=>api('update_product',{product_id:'p1',price:Number(frame.data.price),stock:Number(frame.data.stock)}),
  ()=>{message.textContent='상품을 수정했습니다.';},
  ()=>catalog()
 ]]
];
async function submit(form){
 const raw=Object.fromEntries(new FormData(form));
 const data={username:raw['x009da67033711bd8b970424a'],password:raw['x0f585fdd1768cb0277f813f4'],product_id:raw['xb6b28d72a88a5c3ae74fdea4'],quantity:raw['x931379819c129fdf4e72d4ff'],price:raw['x05fa4f9cd3bad0a0375bac73'],stock:raw['xb3d04124306676f6a420b033']};
 for(const [action,steps] of formPlans){
  if(form.dataset.action===action)await executeSteps(steps,{data});
 }
}
const controller={handleEvent(event){event.preventDefault();run(submit(event.target));}};
document.addEventListener('submit',controller);
const buttonPlans=[
 ['x843ef7d8d2b16d04e57cfb8b',[()=>api('logout'),()=>location.reload()]],
 ['x96637bddb68de3fd5b3f2756',[()=>orders()]]
];
for(const [id,steps] of buttonPlans){
 document.getElementById(id).onclick=()=>run(executeSteps(steps,{}));
}
identity();
run(catalog());
