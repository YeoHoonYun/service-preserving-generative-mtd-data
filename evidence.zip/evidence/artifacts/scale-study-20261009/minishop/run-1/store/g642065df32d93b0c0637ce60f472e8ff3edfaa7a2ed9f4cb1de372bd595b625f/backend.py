# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/xc3aebbe29730350671cf5c0c', 'fields': ['password', 'username'], 'aliases': {'password': 'x43ffb061a2f4510c6f3422eb', 'username': 'xe94e8ced9d4a00853c1ea9fb'}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'xa65ee231d217c1dbd88b47f8', 'response_box': 'xa3ea0bac465117d0d4f8a72e', 'result_key': 'x1d18865a93e932cb4df048a9'}, 'logout': {'route': '/x8fdde0ad06ecd48db1c3f127', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'xfa0dd0b662343e28eeea8956', 'response_box': 'xe64a679de3f5d11b00c3b9e4', 'result_key': 'x8cbe2f916a5611d6a691fc86'}, 'catalog': {'route': '/x08b461119a3ef3cde7f6c782', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'x736f7b255e4a44cd3584ecd0', 'response_box': 'x71cf1ab022695aa68f1959ae', 'result_key': 'x05cdeec28c7d1f37b3a6301d'}, 'create_order': {'route': '/xd77ce254d3c7f2a51872f4cc', 'fields': ['request_id', 'quantity', 'product_id'], 'aliases': {'request_id': 'x7636542650d6ed8816191d6f', 'quantity': 'x338b2594101e32fc980f6449', 'product_id': 'x7e59125cd5e8da6c11dbeb1d'}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'xbe35b4560f908fb535ae80bd', 'response_box': 'x98ea1ecf70686d7c65678dd8', 'result_key': 'x72aed0f4f546b7e3ac815134'}, 'order': {'route': '/x39390b52a61fd461a938d4ef', 'fields': ['order_id'], 'aliases': {'order_id': 'x7929509493114aae638fe76f'}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'xc0e5cde00c0ec30cd6301068', 'response_box': 'x5de43ec7eb4df297ca914989', 'result_key': 'xa922966dab597aad21d1b454'}, 'orders': {'route': '/xa2b05b87c10ccc75c987ef83', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'xb8d57ca5c1944d80de811900', 'response_box': 'xc225b64a2b4f6d2857f69468', 'result_key': 'xa596aeb55220b1e1f3ef5b45'}, 'update_product': {'route': '/xe61db8cb2e4c8d7ea065bf08', 'fields': ['stock', 'price', 'product_id'], 'aliases': {'stock': 'x3e1b951358edc8ba03c59e13', 'price': 'x08141df9fee1a97bf077af42', 'product_id': 'xf8d18817c70c2fa520e31ebf'}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'x286a9e90e093a97920d579db', 'response_box': 'x0d290f581c9ba222682c4a3b', 'result_key': 'x1c8f0185c3d6bf81b1f29b25'}}
HANDLERS = {'login': 'x470e0faae3658dba7a9dfea5', 'logout': 'x44ecc39603ac7e58a498b88f', 'catalog': 'x53cabd2ac60cb2c16970462f', 'create_order': 'x6d06df37d44eb60338f31da6', 'order': 'xc8db4cc688b7a1696a710548', 'orders': 'x4e308c2bf7d7ba7933f77023', 'update_product': 'xe3fa0ae87aaf8e3307974a82'}
BACKEND_GRAPH = {'x470e0faae3658dba7a9dfea5': {'operation': 'login', 'target': 'xe58879c03bb7a2dcc7b90a69', 'kind': 'adapter'}, 'xe58879c03bb7a2dcc7b90a69': {'operation': 'login', 'target': 'xe683278ed8c680f74fe3f58a', 'kind': 'adapter'}, 'xe683278ed8c680f74fe3f58a': {'operation': 'login', 'target': 'x2e3441e5472539209965d785', 'kind': 'adapter'}, 'x2e3441e5472539209965d785': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x44ecc39603ac7e58a498b88f': {'operation': 'logout', 'target': 'x0dc325fa9220e64e2b175acd', 'kind': 'adapter'}, 'x0dc325fa9220e64e2b175acd': {'operation': 'logout', 'target': 'x96eb6b8e544ccd8a573c8434', 'kind': 'adapter'}, 'x96eb6b8e544ccd8a573c8434': {'operation': 'logout', 'target': 'xaf158ce4824aff4239860d87', 'kind': 'adapter'}, 'xaf158ce4824aff4239860d87': {'operation': 'logout', 'target': 'xe76bd4f0b02fa573b6492af5', 'kind': 'adapter'}, 'xe76bd4f0b02fa573b6492af5': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x53cabd2ac60cb2c16970462f': {'operation': 'catalog', 'target': 'x58bb9845433eea17a19fd534', 'kind': 'adapter'}, 'x58bb9845433eea17a19fd534': {'operation': 'catalog', 'target': 'xe828bfb7eddb8f0d6a328749', 'kind': 'adapter'}, 'xe828bfb7eddb8f0d6a328749': {'operation': 'catalog', 'target': 'xf3eb257d6245d508ffb8af9f', 'kind': 'adapter'}, 'xf3eb257d6245d508ffb8af9f': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x6d06df37d44eb60338f31da6': {'operation': 'create_order', 'target': 'x6f6be726f2a0c68c10e7570c', 'kind': 'adapter'}, 'x6f6be726f2a0c68c10e7570c': {'operation': 'create_order', 'target': 'x6cedad50fc371d20512bc847', 'kind': 'adapter'}, 'x6cedad50fc371d20512bc847': {'operation': 'create_order', 'target': 'x7db2986fd6b8d84d942e5120', 'kind': 'adapter'}, 'x7db2986fd6b8d84d942e5120': {'operation': 'create_order', 'target': 'xe070be9eef0114e0abadac34', 'kind': 'adapter'}, 'xe070be9eef0114e0abadac34': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'xc8db4cc688b7a1696a710548': {'operation': 'order', 'target': 'x6142a0fa742d59a3a8505348', 'kind': 'adapter'}, 'x6142a0fa742d59a3a8505348': {'operation': 'order', 'target': 'xe2d015efa691636ad254a602', 'kind': 'adapter'}, 'xe2d015efa691636ad254a602': {'operation': 'order', 'target': 'x0c12c8dae934ac7582192c43', 'kind': 'adapter'}, 'x0c12c8dae934ac7582192c43': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x4e308c2bf7d7ba7933f77023': {'operation': 'orders', 'target': 'x27eadce2df38bf4686bd9967', 'kind': 'adapter'}, 'x27eadce2df38bf4686bd9967': {'operation': 'orders', 'target': 'xd4f4a92866432d3c2f89e233', 'kind': 'adapter'}, 'xd4f4a92866432d3c2f89e233': {'operation': 'orders', 'target': 'x150398c462427ef8e3716628', 'kind': 'adapter'}, 'x150398c462427ef8e3716628': {'operation': 'orders', 'target': 'xbcbc5268f19a2944eb03ffd7', 'kind': 'adapter'}, 'xbcbc5268f19a2944eb03ffd7': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'xe3fa0ae87aaf8e3307974a82': {'operation': 'update_product', 'target': 'xf4817d62ddf30108e8b4cf91', 'kind': 'adapter'}, 'xf4817d62ddf30108e8b4cf91': {'operation': 'update_product', 'target': 'x2def2795a8043cd8d589cbcb', 'kind': 'adapter'}, 'x2def2795a8043cd8d589cbcb': {'operation': 'update_product', 'target': 'xd2d726abc6d00010a85e2504', 'kind': 'adapter'}, 'xd2d726abc6d00010a85e2504': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def x470e0faae3658dba7a9dfea5(core, operation, data, session, actor, trace):
    trace.append('x470e0faae3658dba7a9dfea5')
    return xe58879c03bb7a2dcc7b90a69(core, operation, data, session, actor, trace)

def xe58879c03bb7a2dcc7b90a69(core, operation, data, session, actor, trace):
    trace.append('xe58879c03bb7a2dcc7b90a69')
    return xe683278ed8c680f74fe3f58a(core, operation, data, session, actor, trace)

def xe683278ed8c680f74fe3f58a(core, operation, data, session, actor, trace):
    trace.append('xe683278ed8c680f74fe3f58a')
    return x2e3441e5472539209965d785(core, operation, data, session, actor, trace)

def x2e3441e5472539209965d785(core, operation, data, session, actor, trace):
    trace.append('x2e3441e5472539209965d785')
    return core.execute(operation, data, session, actor)

def x44ecc39603ac7e58a498b88f(core, operation, data, session, actor, trace):
    trace.append('x44ecc39603ac7e58a498b88f')
    return x0dc325fa9220e64e2b175acd(core, operation, data, session, actor, trace)

def x0dc325fa9220e64e2b175acd(core, operation, data, session, actor, trace):
    trace.append('x0dc325fa9220e64e2b175acd')
    return x96eb6b8e544ccd8a573c8434(core, operation, data, session, actor, trace)

def x96eb6b8e544ccd8a573c8434(core, operation, data, session, actor, trace):
    trace.append('x96eb6b8e544ccd8a573c8434')
    return xaf158ce4824aff4239860d87(core, operation, data, session, actor, trace)

def xaf158ce4824aff4239860d87(core, operation, data, session, actor, trace):
    trace.append('xaf158ce4824aff4239860d87')
    return xe76bd4f0b02fa573b6492af5(core, operation, data, session, actor, trace)

def xe76bd4f0b02fa573b6492af5(core, operation, data, session, actor, trace):
    trace.append('xe76bd4f0b02fa573b6492af5')
    return core.execute(operation, data, session, actor)

def x53cabd2ac60cb2c16970462f(core, operation, data, session, actor, trace):
    trace.append('x53cabd2ac60cb2c16970462f')
    return x58bb9845433eea17a19fd534(core, operation, data, session, actor, trace)

def x58bb9845433eea17a19fd534(core, operation, data, session, actor, trace):
    trace.append('x58bb9845433eea17a19fd534')
    return xe828bfb7eddb8f0d6a328749(core, operation, data, session, actor, trace)

def xe828bfb7eddb8f0d6a328749(core, operation, data, session, actor, trace):
    trace.append('xe828bfb7eddb8f0d6a328749')
    return xf3eb257d6245d508ffb8af9f(core, operation, data, session, actor, trace)

def xf3eb257d6245d508ffb8af9f(core, operation, data, session, actor, trace):
    trace.append('xf3eb257d6245d508ffb8af9f')
    return core.execute(operation, data, session, actor)

def x6d06df37d44eb60338f31da6(core, operation, data, session, actor, trace):
    trace.append('x6d06df37d44eb60338f31da6')
    return x6f6be726f2a0c68c10e7570c(core, operation, data, session, actor, trace)

def x6f6be726f2a0c68c10e7570c(core, operation, data, session, actor, trace):
    trace.append('x6f6be726f2a0c68c10e7570c')
    return x6cedad50fc371d20512bc847(core, operation, data, session, actor, trace)

def x6cedad50fc371d20512bc847(core, operation, data, session, actor, trace):
    trace.append('x6cedad50fc371d20512bc847')
    return x7db2986fd6b8d84d942e5120(core, operation, data, session, actor, trace)

def x7db2986fd6b8d84d942e5120(core, operation, data, session, actor, trace):
    trace.append('x7db2986fd6b8d84d942e5120')
    return xe070be9eef0114e0abadac34(core, operation, data, session, actor, trace)

def xe070be9eef0114e0abadac34(core, operation, data, session, actor, trace):
    trace.append('xe070be9eef0114e0abadac34')
    return core.execute(operation, data, session, actor)

def xc8db4cc688b7a1696a710548(core, operation, data, session, actor, trace):
    trace.append('xc8db4cc688b7a1696a710548')
    return x6142a0fa742d59a3a8505348(core, operation, data, session, actor, trace)

def x6142a0fa742d59a3a8505348(core, operation, data, session, actor, trace):
    trace.append('x6142a0fa742d59a3a8505348')
    return xe2d015efa691636ad254a602(core, operation, data, session, actor, trace)

def xe2d015efa691636ad254a602(core, operation, data, session, actor, trace):
    trace.append('xe2d015efa691636ad254a602')
    return x0c12c8dae934ac7582192c43(core, operation, data, session, actor, trace)

def x0c12c8dae934ac7582192c43(core, operation, data, session, actor, trace):
    trace.append('x0c12c8dae934ac7582192c43')
    return core.execute(operation, data, session, actor)

def x4e308c2bf7d7ba7933f77023(core, operation, data, session, actor, trace):
    trace.append('x4e308c2bf7d7ba7933f77023')
    return x27eadce2df38bf4686bd9967(core, operation, data, session, actor, trace)

def x27eadce2df38bf4686bd9967(core, operation, data, session, actor, trace):
    trace.append('x27eadce2df38bf4686bd9967')
    return xd4f4a92866432d3c2f89e233(core, operation, data, session, actor, trace)

def xd4f4a92866432d3c2f89e233(core, operation, data, session, actor, trace):
    trace.append('xd4f4a92866432d3c2f89e233')
    return x150398c462427ef8e3716628(core, operation, data, session, actor, trace)

def x150398c462427ef8e3716628(core, operation, data, session, actor, trace):
    trace.append('x150398c462427ef8e3716628')
    return xbcbc5268f19a2944eb03ffd7(core, operation, data, session, actor, trace)

def xbcbc5268f19a2944eb03ffd7(core, operation, data, session, actor, trace):
    trace.append('xbcbc5268f19a2944eb03ffd7')
    return core.execute(operation, data, session, actor)

def xe3fa0ae87aaf8e3307974a82(core, operation, data, session, actor, trace):
    trace.append('xe3fa0ae87aaf8e3307974a82')
    return xf4817d62ddf30108e8b4cf91(core, operation, data, session, actor, trace)

def xf4817d62ddf30108e8b4cf91(core, operation, data, session, actor, trace):
    trace.append('xf4817d62ddf30108e8b4cf91')
    return x2def2795a8043cd8d589cbcb(core, operation, data, session, actor, trace)

def x2def2795a8043cd8d589cbcb(core, operation, data, session, actor, trace):
    trace.append('x2def2795a8043cd8d589cbcb')
    return xd2d726abc6d00010a85e2504(core, operation, data, session, actor, trace)

def xd2d726abc6d00010a85e2504(core, operation, data, session, actor, trace):
    trace.append('xd2d726abc6d00010a85e2504')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def adapter_miss(operation, arguments):
    raise KeyError(None)

def adapter_case(expected, handler, fallback):
    def dispatch(operation, arguments):
        if operation == expected:
            return handler(*arguments)
        return fallback(operation, arguments)
    return dispatch

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    cases = (
        ('login', x470e0faae3658dba7a9dfea5),
        ('logout', x44ecc39603ac7e58a498b88f),
        ('catalog', x53cabd2ac60cb2c16970462f),
        ('create_order', x6d06df37d44eb60338f31da6),
        ('order', xc8db4cc688b7a1696a710548),
        ('orders', x4e308c2bf7d7ba7933f77023),
        ('update_product', xe3fa0ae87aaf8e3307974a82),
    )
    dispatch = adapter_miss
    for expected, handler in reversed(cases):
        dispatch = adapter_case(expected, handler, dispatch)
    trace = []
    arguments = (core, operation, data, session, actor, trace)
    status, result, cookie = dispatch(operation, arguments)
    return status, result, cookie, trace

