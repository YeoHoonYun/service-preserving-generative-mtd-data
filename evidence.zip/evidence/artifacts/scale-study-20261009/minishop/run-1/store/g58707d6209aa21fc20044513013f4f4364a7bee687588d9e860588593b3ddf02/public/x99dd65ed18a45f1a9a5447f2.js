import {x74168ad9d8c27e88b62d604a,xd0224188b3e43032646ac6e3,x9012711cb8f5e58a34198910,x8be2cde3232120f27d086b6d} from './xfc060fdb0c576f77e424fa2c.js';
import {xa23cf00b819060e6ab6dc393,x09dd9b17622209c219cdcaf5,xa2010fc2f855ceb99e8a56fb} from './xd86c24d217aaf52ceeecb697.js';

class ShopController {
  constructor() {
    this.boot = JSON.parse(document.querySelector('meta[name=boot]').content);
    this.message = document.getElementById('x3df5c6cbed59281a687f7d54');
    this.endpoints = {
      login: x74168ad9d8c27e88b62d604a,
      logout: xa23cf00b819060e6ab6dc393,
      catalog: xd0224188b3e43032646ac6e3,
      create_order: x09dd9b17622209c219cdcaf5,
      order: x9012711cb8f5e58a34198910,
      orders: xa2010fc2f855ceb99e8a56fb,
      update_product: x8be2cde3232120f27d086b6d
    };
    this.actions = new Map([
      ['xca1181ad3f9653d5fea115cb', this.login.bind(this)],
      ['xadc12da579a10846b4cd9efb', this.purchase.bind(this)],
      ['xcf1888e5c4ffdda4c0090336', this.editProduct.bind(this)]
    ]);
    this.lists = {
      catalog: {
        id: 'x24fb0c52911452c0a9129ae9',
        label: p => p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock
      },
      orders: {
        id: 'x7cd551542782b6525ef86816',
        label: order => order.id+' · '+order.total+'원'
      }
    };
  }
  async api(operation, data = {}) {
    const endpoint = this.endpoints[operation];
    return endpoint(data, this.boot.csrf);
  }
  identity() {
    document.getElementById('x42e1066aaf1d89ecc110b6ee').textContent = this.boot.user ? this.boot.user.id : '방문자';
  }
  watch(promise) {
    promise.catch(error => { this.message.textContent = error.message; });
  }
  async refresh(operation) {
    const view = this.lists[operation];
    const list = document.getElementById(view.id);
    list.replaceChildren();
    for (const record of await this.api(operation)) {
      const li = document.createElement('li');
      li.textContent = view.label(record);
      list.append(li);
    }
    if (operation === 'catalog') document.body.dataset.ready = 'yes';
  }
  async login(data) {
    this.boot = await this.api('login', data);
    this.identity();
    this.message.textContent = '로그인되었습니다.';
  }
  async purchase(data) {
    const order = await this.api('create_order', {
      product_id: data.product_id,
      quantity: Number(data.quantity),
      request_id: crypto.randomUUID()
    });
    this.message.textContent = '주문 '+order.id+' · '+order.total+'원';
    await this.refresh('catalog');
    await this.refresh('orders');
  }
  async editProduct(data) {
    await this.api('update_product', {
      product_id: 'p1', price: Number(data.price), stock: Number(data.stock)
    });
    this.message.textContent = '상품을 수정했습니다.';
    await this.refresh('catalog');
  }
  async submit(form) {
    const raw = Object.fromEntries(new FormData(form));
    const data = {
      username: raw['xdc5b1069ccae86e7043230ce'],
      password: raw['x08f2286b66886c81c2b42995'],
      product_id: raw['x3aef7ae9ec9916fa2d6c34dd'],
      quantity: raw['xa6e0b641999f1bdf2c90e511'],
      price: raw['x95b0aed7f55e4c026325d4e5'],
      stock: raw['xbb5a0d3b3c0c2a38d88dbcf6']
    };
    for (const action of this.actions.keys()) {
      if (form.dataset.action === action) await this.actions.get(action)(data);
    }
  }
  mount() {
    document.addEventListener('submit', event => {
      event.preventDefault();
      this.watch(this.submit(event.target));
    });
    document.getElementById('x407e086212407f951c99adc1').onclick = () =>
      this.watch(this.api('logout').then(() => location.reload()));
    document.getElementById('xac77aa6b10d06bcbad8c0202').onclick = () =>
      this.watch(this.refresh('orders'));
    this.identity();
    this.watch(this.refresh('catalog'));
  }
}
new ShopController().mount();
