# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x0d18ee2042e7ac6ee333812b', 'fields': ['password', 'username'], 'aliases': {'password': 'x03c1a9cc1033c5a522a9abae', 'username': 'x806546aba65a0b6a2ba3088e'}, 'request_shape': 'wrapped', 'response_shape': 'object', 'request_box': 'x4216ceb038129b6a5528b5c8', 'response_box': 'xa7ab4f65b95f74c7dd8171d8', 'result_key': 'xe44fd9566c7f1e8665dd79d0'}, 'logout': {'route': '/x4fe64801645287794bc2f934', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'xc1c77c389d1629820a03ccc5', 'response_box': 'xf2ae3edf1c77de685ee73451', 'result_key': 'x42d60fd06d8541753cb7737a'}, 'catalog': {'route': '/x35db737a8aba18472e59b457', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x5e533befac15c352405a49ff', 'response_box': 'x45a6f7dc6bfa7cd51d99f9fe', 'result_key': 'x2f49d9adf50936223ae37957'}, 'create_order': {'route': '/x2e5d2b0206e696d3b8a2e74b', 'fields': ['request_id', 'quantity', 'product_id'], 'aliases': {'request_id': 'x6557806c28ae081eafc60aa6', 'quantity': 'x2064d516c2a92b56b99508fc', 'product_id': 'x6b493ee5b57098edaf70016b'}, 'request_shape': 'wrapped', 'response_shape': 'object', 'request_box': 'x1122a7fab2191425ea8c9abf', 'response_box': 'x4027f3d6de9facf26f191dd0', 'result_key': 'x1d1ca67314f6dc943c6dd5d7'}, 'order': {'route': '/x9d97fe47db00002ff75b1b08', 'fields': ['order_id'], 'aliases': {'order_id': 'x7d2ab03c6fac21ca65caa64b'}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x9e271105d5aa9419a8491713', 'response_box': 'x1a9298bfffba2b33b90eaa26', 'result_key': 'x44106f061aa29793e72c6125'}, 'orders': {'route': '/xd89d3f5e876f724660e61374', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x606bc1beef27c07cbfea4a48', 'response_box': 'x7156587b1b91bf096fb8f183', 'result_key': 'x4f989e3d71c09b99a6acf565'}, 'update_product': {'route': '/x56e4a31e6ba9145e735f6f5f', 'fields': ['product_id', 'price', 'stock'], 'aliases': {'product_id': 'xc076a1a5ab34d28edd2e6d54', 'price': 'xe37e58cde93d56316192a535', 'stock': 'xb726aae2b5406b394c9fce50'}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'xd1128dbdcacdfdd6b1222dc8', 'response_box': 'xbcd3bc08cf5908051be083b1', 'result_key': 'x387b9ca15845ffdd08800960'}}
HANDLERS = {'login': 'x38531a74f5399552c34ffd9f', 'logout': 'xafe986229206065d4362e2b9', 'catalog': 'x6221ec43848921572f1474c7', 'create_order': 'x592baf88ccb043638b793a1f', 'order': 'xd10f41746bf458e9408776b1', 'orders': 'x5e5de0b053a7bdd438f75935', 'update_product': 'xc261592e87437a6c480ffac2'}
BACKEND_GRAPH = {'x38531a74f5399552c34ffd9f': {'operation': 'login', 'target': 'x8a83c9d0158518b767edd98a', 'kind': 'adapter'}, 'x8a83c9d0158518b767edd98a': {'operation': 'login', 'target': 'x99bae7061739be6d21dde1a9', 'kind': 'adapter'}, 'x99bae7061739be6d21dde1a9': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'xafe986229206065d4362e2b9': {'operation': 'logout', 'target': 'x51d369f2b88e958666a5d86c', 'kind': 'adapter'}, 'x51d369f2b88e958666a5d86c': {'operation': 'logout', 'target': 'x8a401bd80c1c23c8eada4272', 'kind': 'adapter'}, 'x8a401bd80c1c23c8eada4272': {'operation': 'logout', 'target': 'x19ec42a900065795bc2a4c2c', 'kind': 'adapter'}, 'x19ec42a900065795bc2a4c2c': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x6221ec43848921572f1474c7': {'operation': 'catalog', 'target': 'x8ebc61aeebaa99628628f1a2', 'kind': 'adapter'}, 'x8ebc61aeebaa99628628f1a2': {'operation': 'catalog', 'target': 'x869ef85bb6c4c4e9fcbb6008', 'kind': 'adapter'}, 'x869ef85bb6c4c4e9fcbb6008': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x592baf88ccb043638b793a1f': {'operation': 'create_order', 'target': 'xa77bea4c0da27ef8f0a93abe', 'kind': 'adapter'}, 'xa77bea4c0da27ef8f0a93abe': {'operation': 'create_order', 'target': 'x30243045b51abb45418f857a', 'kind': 'adapter'}, 'x30243045b51abb45418f857a': {'operation': 'create_order', 'target': 'x9fb2318df823dc009a9a5308', 'kind': 'adapter'}, 'x9fb2318df823dc009a9a5308': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'xd10f41746bf458e9408776b1': {'operation': 'order', 'target': 'x8fc92b14b5c46bba3c3b830c', 'kind': 'adapter'}, 'x8fc92b14b5c46bba3c3b830c': {'operation': 'order', 'target': 'xc20d65d4f47676c6d7f30cda', 'kind': 'adapter'}, 'xc20d65d4f47676c6d7f30cda': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x5e5de0b053a7bdd438f75935': {'operation': 'orders', 'target': 'x1bb7cc98d33cfe19af2eaa98', 'kind': 'adapter'}, 'x1bb7cc98d33cfe19af2eaa98': {'operation': 'orders', 'target': 'x4e762530e828ca9ef9c11a0f', 'kind': 'adapter'}, 'x4e762530e828ca9ef9c11a0f': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'xc261592e87437a6c480ffac2': {'operation': 'update_product', 'target': 'x0252e7045c39803431260b13', 'kind': 'adapter'}, 'x0252e7045c39803431260b13': {'operation': 'update_product', 'target': 'xc35bd5961e9d9ad0f47e1d1a', 'kind': 'adapter'}, 'xc35bd5961e9d9ad0f47e1d1a': {'operation': 'update_product', 'target': 'x086a5086624efa029299ac79', 'kind': 'adapter'}, 'x086a5086624efa029299ac79': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def x38531a74f5399552c34ffd9f(core, operation, data, session, actor, trace):
    trace.append('x38531a74f5399552c34ffd9f')
    return x8a83c9d0158518b767edd98a(core, operation, data, session, actor, trace)

def x8a83c9d0158518b767edd98a(core, operation, data, session, actor, trace):
    trace.append('x8a83c9d0158518b767edd98a')
    return x99bae7061739be6d21dde1a9(core, operation, data, session, actor, trace)

def x99bae7061739be6d21dde1a9(core, operation, data, session, actor, trace):
    trace.append('x99bae7061739be6d21dde1a9')
    return core.execute(operation, data, session, actor)

def xafe986229206065d4362e2b9(core, operation, data, session, actor, trace):
    trace.append('xafe986229206065d4362e2b9')
    return x51d369f2b88e958666a5d86c(core, operation, data, session, actor, trace)

def x51d369f2b88e958666a5d86c(core, operation, data, session, actor, trace):
    trace.append('x51d369f2b88e958666a5d86c')
    return x8a401bd80c1c23c8eada4272(core, operation, data, session, actor, trace)

def x8a401bd80c1c23c8eada4272(core, operation, data, session, actor, trace):
    trace.append('x8a401bd80c1c23c8eada4272')
    return x19ec42a900065795bc2a4c2c(core, operation, data, session, actor, trace)

def x19ec42a900065795bc2a4c2c(core, operation, data, session, actor, trace):
    trace.append('x19ec42a900065795bc2a4c2c')
    return core.execute(operation, data, session, actor)

def x6221ec43848921572f1474c7(core, operation, data, session, actor, trace):
    trace.append('x6221ec43848921572f1474c7')
    return x8ebc61aeebaa99628628f1a2(core, operation, data, session, actor, trace)

def x8ebc61aeebaa99628628f1a2(core, operation, data, session, actor, trace):
    trace.append('x8ebc61aeebaa99628628f1a2')
    return x869ef85bb6c4c4e9fcbb6008(core, operation, data, session, actor, trace)

def x869ef85bb6c4c4e9fcbb6008(core, operation, data, session, actor, trace):
    trace.append('x869ef85bb6c4c4e9fcbb6008')
    return core.execute(operation, data, session, actor)

def x592baf88ccb043638b793a1f(core, operation, data, session, actor, trace):
    trace.append('x592baf88ccb043638b793a1f')
    return xa77bea4c0da27ef8f0a93abe(core, operation, data, session, actor, trace)

def xa77bea4c0da27ef8f0a93abe(core, operation, data, session, actor, trace):
    trace.append('xa77bea4c0da27ef8f0a93abe')
    return x30243045b51abb45418f857a(core, operation, data, session, actor, trace)

def x30243045b51abb45418f857a(core, operation, data, session, actor, trace):
    trace.append('x30243045b51abb45418f857a')
    return x9fb2318df823dc009a9a5308(core, operation, data, session, actor, trace)

def x9fb2318df823dc009a9a5308(core, operation, data, session, actor, trace):
    trace.append('x9fb2318df823dc009a9a5308')
    return core.execute(operation, data, session, actor)

def xd10f41746bf458e9408776b1(core, operation, data, session, actor, trace):
    trace.append('xd10f41746bf458e9408776b1')
    return x8fc92b14b5c46bba3c3b830c(core, operation, data, session, actor, trace)

def x8fc92b14b5c46bba3c3b830c(core, operation, data, session, actor, trace):
    trace.append('x8fc92b14b5c46bba3c3b830c')
    return xc20d65d4f47676c6d7f30cda(core, operation, data, session, actor, trace)

def xc20d65d4f47676c6d7f30cda(core, operation, data, session, actor, trace):
    trace.append('xc20d65d4f47676c6d7f30cda')
    return core.execute(operation, data, session, actor)

def x5e5de0b053a7bdd438f75935(core, operation, data, session, actor, trace):
    trace.append('x5e5de0b053a7bdd438f75935')
    return x1bb7cc98d33cfe19af2eaa98(core, operation, data, session, actor, trace)

def x1bb7cc98d33cfe19af2eaa98(core, operation, data, session, actor, trace):
    trace.append('x1bb7cc98d33cfe19af2eaa98')
    return x4e762530e828ca9ef9c11a0f(core, operation, data, session, actor, trace)

def x4e762530e828ca9ef9c11a0f(core, operation, data, session, actor, trace):
    trace.append('x4e762530e828ca9ef9c11a0f')
    return core.execute(operation, data, session, actor)

def xc261592e87437a6c480ffac2(core, operation, data, session, actor, trace):
    trace.append('xc261592e87437a6c480ffac2')
    return x0252e7045c39803431260b13(core, operation, data, session, actor, trace)

def x0252e7045c39803431260b13(core, operation, data, session, actor, trace):
    trace.append('x0252e7045c39803431260b13')
    return xc35bd5961e9d9ad0f47e1d1a(core, operation, data, session, actor, trace)

def xc35bd5961e9d9ad0f47e1d1a(core, operation, data, session, actor, trace):
    trace.append('xc35bd5961e9d9ad0f47e1d1a')
    return x086a5086624efa029299ac79(core, operation, data, session, actor, trace)

def x086a5086624efa029299ac79(core, operation, data, session, actor, trace):
    trace.append('x086a5086624efa029299ac79')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def invoke_columns(requests):
    statuses, results, cookies, traces = [], [], [], []
    columns = (statuses, results, cookies, traces)
    for request in requests:
        handler_name, core, operation, data, session, actor = request
        outcome = ORIGINAL_INVOKE(handler_name, core, operation, data, session, actor)
        for column, value in zip(columns, outcome):
            column.append(value)
    return columns

def invocation_row(columns, index):
    statuses, results, cookies, traces = columns
    return statuses[index], results[index], cookies[index], traces[index]

def invoke(handler_name, core, operation, data, session, actor):
    requests = ((handler_name, core, operation, data, session, actor),)
    return invocation_row(invoke_columns(requests), 0)

