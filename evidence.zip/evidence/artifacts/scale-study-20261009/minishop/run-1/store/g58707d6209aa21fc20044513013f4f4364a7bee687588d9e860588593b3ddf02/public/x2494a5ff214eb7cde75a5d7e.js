
export async function send(path, wire, csrf) {
 const generation=document.querySelector('meta[name=generation]').content;
 const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF':csrf,'X-Generation':generation},body:JSON.stringify(wire)});
 const result=await response.json();
 if(!response.ok)throw Error(result.error+' ('+response.status+')');
 return result;
}
