GRAPH = {'xf43e807f136f9e3ac21c8f9f': {'kind': 'router', 'edges': {'/x0d18ee2042e7ac6ee333812b': {'target': 'x9b43242261c7d7c0c9b66f36', 'next_key': 'xa3e1aa34d8a9f367c9267c40'}, '/x4fe64801645287794bc2f934': {'target': 'x9b43242261c7d7c0c9b66f36', 'next_key': 'xb8289d912566d463357cf71b'}, '/x35db737a8aba18472e59b457': {'target': 'x9b43242261c7d7c0c9b66f36', 'next_key': 'xf034460dda095c80886eeb38'}, '/x2e5d2b0206e696d3b8a2e74b': {'target': 'x9b43242261c7d7c0c9b66f36', 'next_key': 'x39a022bcad70a959a0a8986b'}, '/x9d97fe47db00002ff75b1b08': {'target': 'x9b43242261c7d7c0c9b66f36', 'next_key': 'xe82bbed170e3c1acefb5500c'}, '/xd89d3f5e876f724660e61374': {'target': 'x9b43242261c7d7c0c9b66f36', 'next_key': 'x5112c9592cd6f1937ea47a46'}, '/x56e4a31e6ba9145e735f6f5f': {'target': 'x9b43242261c7d7c0c9b66f36', 'next_key': 'xd7897cf512efcb205a350789'}}}, 'x9b43242261c7d7c0c9b66f36': {'kind': 'router', 'edges': {'xa3e1aa34d8a9f367c9267c40': {'target': 'xcfc51db9be624233aad31ac1', 'next_key': 'xf059d8b355e6f1c75f27fce1'}, 'xb8289d912566d463357cf71b': {'target': 'xcfc51db9be624233aad31ac1', 'next_key': 'xfd56a94932b57fef21d23cf2'}, 'xf034460dda095c80886eeb38': {'target': 'xcfc51db9be624233aad31ac1', 'next_key': 'xf0ef61d29c5ac1009acf757f'}, 'x39a022bcad70a959a0a8986b': {'target': 'xcfc51db9be624233aad31ac1', 'next_key': 'xf10c1299ae09f3cff556d4b6'}, 'xe82bbed170e3c1acefb5500c': {'target': 'xcfc51db9be624233aad31ac1', 'next_key': 'xf4da71934c16ccb2f21442d2'}, 'x5112c9592cd6f1937ea47a46': {'target': 'xcfc51db9be624233aad31ac1', 'next_key': 'x09443e1c5b68562602bd4d2c'}, 'xd7897cf512efcb205a350789': {'target': 'xcfc51db9be624233aad31ac1', 'next_key': 'x7431f0fb3307e0d9f40407aa'}}}, 'xcfc51db9be624233aad31ac1': {'kind': 'router', 'edges': {'xf059d8b355e6f1c75f27fce1': {'target': 'x33501e0c2312626918dffbef', 'next_key': None}, 'xfd56a94932b57fef21d23cf2': {'target': 'xa7d951be27771d5e1b944cef', 'next_key': None}, 'xf0ef61d29c5ac1009acf757f': {'target': 'xf5783f21e45e82beb4e7de9f', 'next_key': None}, 'xf10c1299ae09f3cff556d4b6': {'target': 'x71a3f1024fe9352f310ba4f4', 'next_key': None}, 'xf4da71934c16ccb2f21442d2': {'target': 'x1358f14e564c0fe649708c3b', 'next_key': None}, 'x09443e1c5b68562602bd4d2c': {'target': 'x2138c5b6b65f097a0bd4c3f3', 'next_key': None}, 'x7431f0fb3307e0d9f40407aa': {'target': 'x7b3beafb833ba73f60957b02', 'next_key': None}}}, 'x33501e0c2312626918dffbef': {'kind': 'service', 'operation': 'login', 'handler': 'x38531a74f5399552c34ffd9f'}, 'xa7d951be27771d5e1b944cef': {'kind': 'service', 'operation': 'logout', 'handler': 'xafe986229206065d4362e2b9'}, 'xf5783f21e45e82beb4e7de9f': {'kind': 'service', 'operation': 'catalog', 'handler': 'x6221ec43848921572f1474c7'}, 'x71a3f1024fe9352f310ba4f4': {'kind': 'service', 'operation': 'create_order', 'handler': 'x592baf88ccb043638b793a1f'}, 'x1358f14e564c0fe649708c3b': {'kind': 'service', 'operation': 'order', 'handler': 'xd10f41746bf458e9408776b1'}, 'x2138c5b6b65f097a0bd4c3f3': {'kind': 'service', 'operation': 'orders', 'handler': 'x5e5de0b053a7bdd438f75935'}, 'x7b3beafb833ba73f60957b02': {'kind': 'service', 'operation': 'update_product', 'handler': 'xc261592e87437a6c480ffac2'}}
ENTRY = 'xf43e807f136f9e3ac21c8f9f'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    records = []
    rebuilt = {}
    for path in graph[entry]['edges']:
        node, key = entry, path
        seen = set()
        while True:
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            item = graph[node]
            if item['kind'] == 'service':
                rebuilt[node] = dict(item)
                records.append((path, node, (item['handler'], item['operation'], path)))
                break
            edge = item['edges'][key]
            node, key = edge['target'], edge['next_key']
    left = [None for record in records]
    right = [None for record in records]
    for index in range(1, len(records)):
        cursor = 0
        while True:
            branch = left if records[index][2] < records[cursor][2] else right
            if branch[cursor] is None:
                branch[cursor] = index
                break
            cursor = branch[cursor]
    root = 'route.entry'
    rebuilt[root] = {'kind': 'router', 'edges': {}}
    for index in range(len(records)):
        rebuilt['route.search.' + str(index)] = {'kind': 'router', 'edges': {}}
    for index, record in enumerate(records):
        path, leaf, rank = record
        rebuilt[root]['edges'][path] = {'target': 'route.search.0', 'next_key': path}
        cursor = 0
        while True:
            edges = rebuilt['route.search.' + str(cursor)]['edges']
            if cursor == index:
                edges[path] = {'target': leaf, 'next_key': None}
                break
            child = left[cursor] if rank < records[cursor][2] else right[cursor]
            edges[path] = {'target': 'route.search.' + str(child), 'next_key': path}
            cursor = child
    return rebuilt, root

def resolve(path):
    node, key = ENTRY, path
    visited, trace = set(), []
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
