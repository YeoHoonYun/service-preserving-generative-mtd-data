GRAPH = {'x0b8cc087cc0b5e74e784a22e': {'kind': 'router', 'edges': {'/x97534e6979f8a8fa35e736bb': {'target': 'x64d8563e76f98be085dfdc97', 'next_key': 'x50e686e8b39ae9da534fe5db'}, '/x95a165fc08be9ab2c4f35b98': {'target': 'x64d8563e76f98be085dfdc97', 'next_key': 'x508edd25bb68c13e67b43fe8'}, '/x4d4db256d44f545b65bef36b': {'target': 'x64d8563e76f98be085dfdc97', 'next_key': 'xbfc898a70825934779a1ac64'}, '/xbf49f32bfb25d7eea36c1626': {'target': 'x64d8563e76f98be085dfdc97', 'next_key': 'x08b15de91c62d0be2ac098eb'}, '/xc2678fb99c275bd4c59d43c6': {'target': 'x64d8563e76f98be085dfdc97', 'next_key': 'x2775a0762014648cfe76a578'}, '/x26c97885f9ae5c5d653d83a1': {'target': 'x64d8563e76f98be085dfdc97', 'next_key': 'xab19a29c939cd6e1d6a3e4cd'}, '/x04dadf6f2868602c68a4d793': {'target': 'x64d8563e76f98be085dfdc97', 'next_key': 'x7a7b245680a956466b440d04'}}}, 'x64d8563e76f98be085dfdc97': {'kind': 'router', 'edges': {'x50e686e8b39ae9da534fe5db': {'target': 'x8fb21ac9a1eba2494cb6f17a', 'next_key': 'x0e0aa25578c5f994b036da61'}, 'x508edd25bb68c13e67b43fe8': {'target': 'x8fb21ac9a1eba2494cb6f17a', 'next_key': 'xae570d1e623fc017322882d8'}, 'xbfc898a70825934779a1ac64': {'target': 'x8fb21ac9a1eba2494cb6f17a', 'next_key': 'xabf4217c55e39b5367bb0fdf'}, 'x08b15de91c62d0be2ac098eb': {'target': 'x8fb21ac9a1eba2494cb6f17a', 'next_key': 'x3ac04b6fcc991f39ee65d2f2'}, 'x2775a0762014648cfe76a578': {'target': 'x8fb21ac9a1eba2494cb6f17a', 'next_key': 'xb41ebe9f069dec8a5c9906bc'}, 'xab19a29c939cd6e1d6a3e4cd': {'target': 'x8fb21ac9a1eba2494cb6f17a', 'next_key': 'xf9b2b02306a59a3c389ba897'}, 'x7a7b245680a956466b440d04': {'target': 'x8fb21ac9a1eba2494cb6f17a', 'next_key': 'xd07ee11e57429d572cb12410'}}}, 'x8fb21ac9a1eba2494cb6f17a': {'kind': 'router', 'edges': {'x0e0aa25578c5f994b036da61': {'target': 'x51743a7e849cdffb3d9fa79d', 'next_key': None}, 'xae570d1e623fc017322882d8': {'target': 'x58243c4bc6ff37f6121d39f0', 'next_key': None}, 'xabf4217c55e39b5367bb0fdf': {'target': 'x0aa39aaa9320038db29a7f47', 'next_key': None}, 'x3ac04b6fcc991f39ee65d2f2': {'target': 'x3cb66f2b1733daa40280a67b', 'next_key': None}, 'xb41ebe9f069dec8a5c9906bc': {'target': 'x1ff8f4f9db8945017cece966', 'next_key': None}, 'xf9b2b02306a59a3c389ba897': {'target': 'x833eece2e10ee5521c6ea852', 'next_key': None}, 'xd07ee11e57429d572cb12410': {'target': 'xe988014539e0ba1fbf666aa3', 'next_key': None}}}, 'x51743a7e849cdffb3d9fa79d': {'kind': 'service', 'operation': 'login', 'handler': 'xe181fad5bb71cafd67328081'}, 'x58243c4bc6ff37f6121d39f0': {'kind': 'service', 'operation': 'logout', 'handler': 'x5897fe8428192d458edeade2'}, 'x0aa39aaa9320038db29a7f47': {'kind': 'service', 'operation': 'catalog', 'handler': 'xc9b9255378ac0f6c13b7be85'}, 'x3cb66f2b1733daa40280a67b': {'kind': 'service', 'operation': 'create_order', 'handler': 'x5ab5ba0054f8659baa95804a'}, 'x1ff8f4f9db8945017cece966': {'kind': 'service', 'operation': 'order', 'handler': 'x7eb56c7fb39bc2addd6026a3'}, 'x833eece2e10ee5521c6ea852': {'kind': 'service', 'operation': 'orders', 'handler': 'x489a567e8b26688d6587df89'}, 'xe988014539e0ba1fbf666aa3': {'kind': 'service', 'operation': 'update_product', 'handler': 'x7645239b50f06fc70b947519'}}
ENTRY = 'x0b8cc087cc0b5e74e784a22e'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    rebuilt = {'route_entry': {'kind': 'router', 'edges': {}}}
    services = {}
    for index, path in enumerate(sorted(graph[entry]['edges'])):
        node, key = entry, path
        visited = set()
        while graph[node]['kind'] != 'service':
            if node in visited:
                raise ValueError('routing cycle')
            visited.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        if node not in services:
            service = 'route_service_' + str(len(services))
            services[node] = service
            rebuilt[service] = dict(graph[node])
        branch = 'route_partition_' + str(index % 3)
        if branch not in rebuilt:
            rebuilt[branch] = {'kind': 'router', 'edges': {}}
        rebuilt['route_entry']['edges'][path] = {'target': branch, 'next_key': path}
        rebuilt[branch]['edges'][path] = {'target': services[node], 'next_key': None}
    return rebuilt, 'route_entry'

def resolve(path):
    node, key = ENTRY, path
    visited, trace = set(), []
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
