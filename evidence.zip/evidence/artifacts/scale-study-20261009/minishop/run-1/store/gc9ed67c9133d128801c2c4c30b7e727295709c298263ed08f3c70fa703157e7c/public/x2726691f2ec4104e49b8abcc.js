import {x6a891f11118c74f618a1bfe0,x5855e590b26af9392a7d2508,x0666a7a4be4e0023175072fe,x32f15206d81e7122e010859e} from './x7f7b87dfb60600143f0f6067.js';
import {x3941fa17aab75f1f4fdf4709,x464a3fe7cc07d32e9b406a7e,xc89db91ab6940958d5a997a6} from './x44d22f1874fea1ed5c2cf78c.js';
let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('xf30b899b20facee796da1da6');
const endpoints={login:x6a891f11118c74f618a1bfe0,logout:x3941fa17aab75f1f4fdf4709,catalog:x5855e590b26af9392a7d2508,create_order:x464a3fe7cc07d32e9b406a7e,order:x0666a7a4be4e0023175072fe,orders:xc89db91ab6940958d5a997a6,update_product:x32f15206d81e7122e010859e};
const fields={username:'x0484c76d63f3a714dd03304d',password:'x406b828c105e03e7c0936974',product_id:'x7c25e9a8382b5d47aec37c05',quantity:'x966c95bf0f5b6fed5ff8b75d',price:'x78c85397a1825c6105dd05e4',stock:'xaba98bbb0361f6e4cbeeb3a0'};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('xe9faf6c493607045484e1449').textContent=boot.user?boot.user.id:'방문자';}
function run(promise){promise.catch(error=>message.textContent=error.message);}
const lists={
 catalog:{id:'x584fd34209f8b3ae6fdeec74',text:p=>p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock},
 orders:{id:'x65361e1f283f31253c64fcae',text:order=>order.id+' · '+order.total+'원'}
};
async function refresh(operation){
 const view=lists[operation];
 const list=document.getElementById(view.id);
 list.replaceChildren();
 for(const item of await api(operation)){
  const li=document.createElement('li');
  li.textContent=view.text(item);
  list.append(li);
 }
 if(operation==='catalog')document.body.dataset.ready='yes';
}
const controllers=[
 ['x38e9ab867696bf16510cdb1c',async data=>{
  boot=await api('login',data);
  identity();
  message.textContent='로그인되었습니다.';
 }],
 ['xf9cf9435dbc7d14b05638fa5',async data=>{
  const order=await api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()});
  message.textContent='주문 '+order.id+' · '+order.total+'원';
  await refresh('catalog');
  await refresh('orders');
 }],
 ['x95ac58debd5345050b0157dd',async data=>{
  await api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)});
  message.textContent='상품을 수정했습니다.';
  await refresh('catalog');
 }]
];
async function submit(form){
 const raw=Object.fromEntries(new FormData(form));
 const data=Object.fromEntries(Object.entries(fields).map(([name,field])=>[name,raw[field]]));
 for(const [action,controller] of controllers){
  if(form.dataset.action===action)await controller(data);
 }
}
document.addEventListener('submit',event=>{
 event.preventDefault();
 run(submit(event.target));
});
document.getElementById('xfc442a693c551f4e297492fb').onclick=()=>run(api('logout').then(()=>location.reload()));
document.getElementById('xe8a3cfbfa132e20c664db383').onclick=()=>run(refresh('orders'));
identity();
run(refresh('catalog'));
