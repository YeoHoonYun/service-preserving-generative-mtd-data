# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x97534e6979f8a8fa35e736bb', 'fields': ['username', 'password'], 'aliases': {'username': 'xb12619af28634da5f1309210', 'password': 'xbb28a67bbb52742534d1c950'}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'xdfbb79cf6cf9c4245c84b397', 'response_box': 'x1e365e74063b3cad2fb9969a', 'result_key': 'x0f1ddfa784249b314f4fbfd0'}, 'logout': {'route': '/x95a165fc08be9ab2c4f35b98', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'xa46824142da5e38b32cb19e5', 'response_box': 'x97d513757a620496babf722d', 'result_key': 'x15718e2b18f3548fdd201384'}, 'catalog': {'route': '/x4d4db256d44f545b65bef36b', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'x55992575d6ec9ba67e519ef8', 'response_box': 'xb80dbae1f65817b328224276', 'result_key': 'x52ff4a1d7c78490ac1c2478e'}, 'create_order': {'route': '/xbf49f32bfb25d7eea36c1626', 'fields': ['product_id', 'quantity', 'request_id'], 'aliases': {'product_id': 'xff9d518a972f805ec9fe8846', 'quantity': 'xc001f7026f84b5a02b4d3e67', 'request_id': 'x0a3511bba1efba2418b7aa42'}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'xd75f3ebb0249f7ec3ef496bd', 'response_box': 'x91f0078564884f414dc912f8', 'result_key': 'x30189f3c8a02cddde7567a4b'}, 'order': {'route': '/xc2678fb99c275bd4c59d43c6', 'fields': ['order_id'], 'aliases': {'order_id': 'x7b494a3ae88e745187115c82'}, 'request_shape': 'positional', 'response_shape': 'array', 'request_box': 'x8d361d94b2aa9796017f662d', 'response_box': 'x459bbd5f8326d0d82548aa70', 'result_key': 'x14c779a1a15212a702bb52d8'}, 'orders': {'route': '/x26c97885f9ae5c5d653d83a1', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'array', 'request_box': 'x7a03b5eea16cf18459b409de', 'response_box': 'xb3a7556bc22a2ce5fb6da7d3', 'result_key': 'x1579673067baca266c7f4add'}, 'update_product': {'route': '/x04dadf6f2868602c68a4d793', 'fields': ['product_id', 'price', 'stock'], 'aliases': {'product_id': 'x0a503f605447f8dade2d9f70', 'price': 'x6b3c5edf7e094a3ee931871a', 'stock': 'x40880442fac42ea74e3346cc'}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'xd874a7a29a86899668e71395', 'response_box': 'xab859510ade79af83e719331', 'result_key': 'x8f2e27b4af386f33bd08fc1a'}}
HANDLERS = {'login': 'xe181fad5bb71cafd67328081', 'logout': 'x5897fe8428192d458edeade2', 'catalog': 'xc9b9255378ac0f6c13b7be85', 'create_order': 'x5ab5ba0054f8659baa95804a', 'order': 'x7eb56c7fb39bc2addd6026a3', 'orders': 'x489a567e8b26688d6587df89', 'update_product': 'x7645239b50f06fc70b947519'}
BACKEND_GRAPH = {'xe181fad5bb71cafd67328081': {'operation': 'login', 'target': 'xa5f72da18394a6502682594f', 'kind': 'adapter'}, 'xa5f72da18394a6502682594f': {'operation': 'login', 'target': 'x230c4abc8d9b6d582d0c2e2d', 'kind': 'adapter'}, 'x230c4abc8d9b6d582d0c2e2d': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x5897fe8428192d458edeade2': {'operation': 'logout', 'target': 'xf73c25ec54a86884f480793b', 'kind': 'adapter'}, 'xf73c25ec54a86884f480793b': {'operation': 'logout', 'target': 'xba891ebb366502d2690a534b', 'kind': 'adapter'}, 'xba891ebb366502d2690a534b': {'operation': 'logout', 'target': 'x74b457ffa5b2bae69d004eda', 'kind': 'adapter'}, 'x74b457ffa5b2bae69d004eda': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'xc9b9255378ac0f6c13b7be85': {'operation': 'catalog', 'target': 'x74a23ab2975b6c88d7da6854', 'kind': 'adapter'}, 'x74a23ab2975b6c88d7da6854': {'operation': 'catalog', 'target': 'x8ec4c37d6da4ea7910a68dbc', 'kind': 'adapter'}, 'x8ec4c37d6da4ea7910a68dbc': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x5ab5ba0054f8659baa95804a': {'operation': 'create_order', 'target': 'x13769e321b0f01a34c2d9ff0', 'kind': 'adapter'}, 'x13769e321b0f01a34c2d9ff0': {'operation': 'create_order', 'target': 'xc6282027f6d5fdd7880075b8', 'kind': 'adapter'}, 'xc6282027f6d5fdd7880075b8': {'operation': 'create_order', 'target': 'x05148f6f0090e38bafb4bb22', 'kind': 'adapter'}, 'x05148f6f0090e38bafb4bb22': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x7eb56c7fb39bc2addd6026a3': {'operation': 'order', 'target': 'x0309c1a324f76d3c15f41c8b', 'kind': 'adapter'}, 'x0309c1a324f76d3c15f41c8b': {'operation': 'order', 'target': 'xc30dc59bb39db05f1d1b1252', 'kind': 'adapter'}, 'xc30dc59bb39db05f1d1b1252': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x489a567e8b26688d6587df89': {'operation': 'orders', 'target': 'x7cc93dcac905b6adb6b20ca6', 'kind': 'adapter'}, 'x7cc93dcac905b6adb6b20ca6': {'operation': 'orders', 'target': 'x01d174fedc9213fead3cc2d5', 'kind': 'adapter'}, 'x01d174fedc9213fead3cc2d5': {'operation': 'orders', 'target': 'x6f6e32ff05796a0041293e2e', 'kind': 'adapter'}, 'x6f6e32ff05796a0041293e2e': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x7645239b50f06fc70b947519': {'operation': 'update_product', 'target': 'x460786d3af5ddf79e63c2338', 'kind': 'adapter'}, 'x460786d3af5ddf79e63c2338': {'operation': 'update_product', 'target': 'x7a4cd897346e2981173b6aa6', 'kind': 'adapter'}, 'x7a4cd897346e2981173b6aa6': {'operation': 'update_product', 'target': 'x1266cff2792e19ea4e91eb92', 'kind': 'adapter'}, 'x1266cff2792e19ea4e91eb92': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xe181fad5bb71cafd67328081(core, operation, data, session, actor, trace):
    trace.append('xe181fad5bb71cafd67328081')
    return xa5f72da18394a6502682594f(core, operation, data, session, actor, trace)

def xa5f72da18394a6502682594f(core, operation, data, session, actor, trace):
    trace.append('xa5f72da18394a6502682594f')
    return x230c4abc8d9b6d582d0c2e2d(core, operation, data, session, actor, trace)

def x230c4abc8d9b6d582d0c2e2d(core, operation, data, session, actor, trace):
    trace.append('x230c4abc8d9b6d582d0c2e2d')
    return core.execute(operation, data, session, actor)

def x5897fe8428192d458edeade2(core, operation, data, session, actor, trace):
    trace.append('x5897fe8428192d458edeade2')
    return xf73c25ec54a86884f480793b(core, operation, data, session, actor, trace)

def xf73c25ec54a86884f480793b(core, operation, data, session, actor, trace):
    trace.append('xf73c25ec54a86884f480793b')
    return xba891ebb366502d2690a534b(core, operation, data, session, actor, trace)

def xba891ebb366502d2690a534b(core, operation, data, session, actor, trace):
    trace.append('xba891ebb366502d2690a534b')
    return x74b457ffa5b2bae69d004eda(core, operation, data, session, actor, trace)

def x74b457ffa5b2bae69d004eda(core, operation, data, session, actor, trace):
    trace.append('x74b457ffa5b2bae69d004eda')
    return core.execute(operation, data, session, actor)

def xc9b9255378ac0f6c13b7be85(core, operation, data, session, actor, trace):
    trace.append('xc9b9255378ac0f6c13b7be85')
    return x74a23ab2975b6c88d7da6854(core, operation, data, session, actor, trace)

def x74a23ab2975b6c88d7da6854(core, operation, data, session, actor, trace):
    trace.append('x74a23ab2975b6c88d7da6854')
    return x8ec4c37d6da4ea7910a68dbc(core, operation, data, session, actor, trace)

def x8ec4c37d6da4ea7910a68dbc(core, operation, data, session, actor, trace):
    trace.append('x8ec4c37d6da4ea7910a68dbc')
    return core.execute(operation, data, session, actor)

def x5ab5ba0054f8659baa95804a(core, operation, data, session, actor, trace):
    trace.append('x5ab5ba0054f8659baa95804a')
    return x13769e321b0f01a34c2d9ff0(core, operation, data, session, actor, trace)

def x13769e321b0f01a34c2d9ff0(core, operation, data, session, actor, trace):
    trace.append('x13769e321b0f01a34c2d9ff0')
    return xc6282027f6d5fdd7880075b8(core, operation, data, session, actor, trace)

def xc6282027f6d5fdd7880075b8(core, operation, data, session, actor, trace):
    trace.append('xc6282027f6d5fdd7880075b8')
    return x05148f6f0090e38bafb4bb22(core, operation, data, session, actor, trace)

def x05148f6f0090e38bafb4bb22(core, operation, data, session, actor, trace):
    trace.append('x05148f6f0090e38bafb4bb22')
    return core.execute(operation, data, session, actor)

def x7eb56c7fb39bc2addd6026a3(core, operation, data, session, actor, trace):
    trace.append('x7eb56c7fb39bc2addd6026a3')
    return x0309c1a324f76d3c15f41c8b(core, operation, data, session, actor, trace)

def x0309c1a324f76d3c15f41c8b(core, operation, data, session, actor, trace):
    trace.append('x0309c1a324f76d3c15f41c8b')
    return xc30dc59bb39db05f1d1b1252(core, operation, data, session, actor, trace)

def xc30dc59bb39db05f1d1b1252(core, operation, data, session, actor, trace):
    trace.append('xc30dc59bb39db05f1d1b1252')
    return core.execute(operation, data, session, actor)

def x489a567e8b26688d6587df89(core, operation, data, session, actor, trace):
    trace.append('x489a567e8b26688d6587df89')
    return x7cc93dcac905b6adb6b20ca6(core, operation, data, session, actor, trace)

def x7cc93dcac905b6adb6b20ca6(core, operation, data, session, actor, trace):
    trace.append('x7cc93dcac905b6adb6b20ca6')
    return x01d174fedc9213fead3cc2d5(core, operation, data, session, actor, trace)

def x01d174fedc9213fead3cc2d5(core, operation, data, session, actor, trace):
    trace.append('x01d174fedc9213fead3cc2d5')
    return x6f6e32ff05796a0041293e2e(core, operation, data, session, actor, trace)

def x6f6e32ff05796a0041293e2e(core, operation, data, session, actor, trace):
    trace.append('x6f6e32ff05796a0041293e2e')
    return core.execute(operation, data, session, actor)

def x7645239b50f06fc70b947519(core, operation, data, session, actor, trace):
    trace.append('x7645239b50f06fc70b947519')
    return x460786d3af5ddf79e63c2338(core, operation, data, session, actor, trace)

def x460786d3af5ddf79e63c2338(core, operation, data, session, actor, trace):
    trace.append('x460786d3af5ddf79e63c2338')
    return x7a4cd897346e2981173b6aa6(core, operation, data, session, actor, trace)

def x7a4cd897346e2981173b6aa6(core, operation, data, session, actor, trace):
    trace.append('x7a4cd897346e2981173b6aa6')
    return x1266cff2792e19ea4e91eb92(core, operation, data, session, actor, trace)

def x1266cff2792e19ea4e91eb92(core, operation, data, session, actor, trace):
    trace.append('x1266cff2792e19ea4e91eb92')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def select_adapter(handler_name, operation):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    adapters = {
        'xe181fad5bb71cafd67328081': xe181fad5bb71cafd67328081,
        'x5897fe8428192d458edeade2': x5897fe8428192d458edeade2,
        'xc9b9255378ac0f6c13b7be85': xc9b9255378ac0f6c13b7be85,
        'x5ab5ba0054f8659baa95804a': x5ab5ba0054f8659baa95804a,
        'x7eb56c7fb39bc2addd6026a3': x7eb56c7fb39bc2addd6026a3,
        'x489a567e8b26688d6587df89': x489a567e8b26688d6587df89,
        'x7645239b50f06fc70b947519': x7645239b50f06fc70b947519
    }
    return adapters[handler_name]

def execute_adapter(adapter, core, operation, data, session, actor):
    trace = []
    status, result, cookie = adapter(core, operation, data, session, actor, trace)
    return status, result, cookie, trace

def invoke(handler_name, core, operation, data, session, actor):
    adapter = select_adapter(handler_name, operation)
    return execute_adapter(adapter, core, operation, data, session, actor)

