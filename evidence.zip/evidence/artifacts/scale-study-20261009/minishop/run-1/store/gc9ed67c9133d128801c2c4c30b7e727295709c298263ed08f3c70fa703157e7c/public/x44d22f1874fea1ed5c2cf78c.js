import {send} from './xfa21413cea24438a44d3a63c.js';
export async function x3941fa17aab75f1f4fdf4709(data,csrf){const wire={};const value=await send("/x95a165fc08be9ab2c4f35b98",wire,csrf);return value["x97d513757a620496babf722d"]["x15718e2b18f3548fdd201384"];}
export async function x464a3fe7cc07d32e9b406a7e(data,csrf){const wire={"xd75f3ebb0249f7ec3ef496bd":[["xff9d518a972f805ec9fe8846",data["product_id"]],["xc001f7026f84b5a02b4d3e67",data["quantity"]],["x0a3511bba1efba2418b7aa42",data["request_id"]]]};const value=await send("/xbf49f32bfb25d7eea36c1626",wire,csrf);return value[0];}
export async function xc89db91ab6940958d5a997a6(data,csrf){const wire=[];const value=await send("/x26c97885f9ae5c5d653d83a1",wire,csrf);return value[0];}
