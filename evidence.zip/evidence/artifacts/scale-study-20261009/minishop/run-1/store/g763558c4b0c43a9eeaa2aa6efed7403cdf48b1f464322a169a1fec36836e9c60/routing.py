GRAPH = {'xa50ab0114e2890c3166405e6': {'kind': 'router', 'edges': {'/x8551546e384fa15be747461a': {'target': 'x2a065c29b779d48abb1dfcae', 'next_key': 'x67d937a4525eade257268e8f'}, '/xd994bde4424700e86e396091': {'target': 'x54dc0a0945457e97d6115e1a', 'next_key': 'x415a580c50c8ad167fa19f66'}, '/xf947661c791f7345d01b3986': {'target': 'x2a065c29b779d48abb1dfcae', 'next_key': 'x5169475332004b6cdd2edbd6'}, '/x25460bbf636e35b255df5c0b': {'target': 'x54dc0a0945457e97d6115e1a', 'next_key': 'xcd2724cb00190f04a7840c99'}, '/x1901c7359b4da376aa947922': {'target': 'x2a065c29b779d48abb1dfcae', 'next_key': 'xee5c10c0f9da14f1a8abf319'}, '/x2772b670b3d371c8d63b8de4': {'target': 'x54dc0a0945457e97d6115e1a', 'next_key': 'x411f17771e2dc0c0e25b7381'}, '/x1c4e49040a510f67cdc605d4': {'target': 'x2a065c29b779d48abb1dfcae', 'next_key': 'xf39807b657d19c8d7149ec63'}}}, 'x2a065c29b779d48abb1dfcae': {'kind': 'router', 'edges': {'x67d937a4525eade257268e8f': {'target': 'x082dbffd52978ab517e6bfe5', 'next_key': 'xdd488eac6ac6d9cbf7c0dd3b'}, 'x5169475332004b6cdd2edbd6': {'target': 'x082dbffd52978ab517e6bfe5', 'next_key': 'x98ed53e3ead38fb6682ccfa5'}, 'xee5c10c0f9da14f1a8abf319': {'target': 'x082dbffd52978ab517e6bfe5', 'next_key': 'x0ad1e2b1dd11c478bcd1f5fb'}, 'xf39807b657d19c8d7149ec63': {'target': 'x082dbffd52978ab517e6bfe5', 'next_key': 'xf97c5eede65d9462d291c257'}}}, 'x54dc0a0945457e97d6115e1a': {'kind': 'router', 'edges': {'x415a580c50c8ad167fa19f66': {'target': 'x082dbffd52978ab517e6bfe5', 'next_key': 'xde93f83150118adf59ede288'}, 'xcd2724cb00190f04a7840c99': {'target': 'x082dbffd52978ab517e6bfe5', 'next_key': 'xbe717f1c74366c009a26cf7f'}, 'x411f17771e2dc0c0e25b7381': {'target': 'x082dbffd52978ab517e6bfe5', 'next_key': 'xdea819cce94df3c89b92ba97'}}}, 'x082dbffd52978ab517e6bfe5': {'kind': 'router', 'edges': {'xdd488eac6ac6d9cbf7c0dd3b': {'target': 'x47ac94473ac8f5392f51a519', 'next_key': 'x408947766be1ce0a8836b6fa'}, 'xde93f83150118adf59ede288': {'target': 'x47ac94473ac8f5392f51a519', 'next_key': 'x92724ff2ec7a242f78c56eb5'}, 'x98ed53e3ead38fb6682ccfa5': {'target': 'x47ac94473ac8f5392f51a519', 'next_key': 'xb3b7fcb064eae04c3e861fc2'}, 'xbe717f1c74366c009a26cf7f': {'target': 'x47ac94473ac8f5392f51a519', 'next_key': 'xc9f332e0b9253ab471d0b805'}, 'x0ad1e2b1dd11c478bcd1f5fb': {'target': 'x47ac94473ac8f5392f51a519', 'next_key': 'x7c19cbd2f1a2fe19528ee865'}, 'xdea819cce94df3c89b92ba97': {'target': 'x47ac94473ac8f5392f51a519', 'next_key': 'x4b1e3a99fac75efb68aff38d'}, 'xf97c5eede65d9462d291c257': {'target': 'x47ac94473ac8f5392f51a519', 'next_key': 'xf345ce92072d99f7062b2456'}}}, 'x47ac94473ac8f5392f51a519': {'kind': 'router', 'edges': {'x408947766be1ce0a8836b6fa': {'target': 'x76e8bd712ebec39c0b55dc81', 'next_key': 'xd4fe6811a444bb247143d80e'}, 'x92724ff2ec7a242f78c56eb5': {'target': 'x76e8bd712ebec39c0b55dc81', 'next_key': 'x2cd35512e58ce207e1f29c63'}, 'xb3b7fcb064eae04c3e861fc2': {'target': 'x76e8bd712ebec39c0b55dc81', 'next_key': 'x50579f383408873523b7320d'}, 'xc9f332e0b9253ab471d0b805': {'target': 'x76e8bd712ebec39c0b55dc81', 'next_key': 'xd1506f4c4173861bc0f01463'}, 'x7c19cbd2f1a2fe19528ee865': {'target': 'x76e8bd712ebec39c0b55dc81', 'next_key': 'x7027668c50eec97e2ab505ed'}, 'x4b1e3a99fac75efb68aff38d': {'target': 'x76e8bd712ebec39c0b55dc81', 'next_key': 'x9d0fed7ec8089673200c3c53'}, 'xf345ce92072d99f7062b2456': {'target': 'x76e8bd712ebec39c0b55dc81', 'next_key': 'xafcdd624343d8d07cdd1debd'}}}, 'x76e8bd712ebec39c0b55dc81': {'kind': 'router', 'edges': {'xd4fe6811a444bb247143d80e': {'target': 'xfb8208bcc1122c05c3ac3730', 'next_key': None}, 'x2cd35512e58ce207e1f29c63': {'target': 'x30d6ffc68e8e2547b7256e95', 'next_key': None}, 'x50579f383408873523b7320d': {'target': 'x9dbd8089ff62637a0b8b8812', 'next_key': None}, 'xd1506f4c4173861bc0f01463': {'target': 'x5b3c8b2f693bb3492b30ec34', 'next_key': None}, 'x7027668c50eec97e2ab505ed': {'target': 'x8be714fff7cee3eaaef3abfc', 'next_key': None}, 'x9d0fed7ec8089673200c3c53': {'target': 'x55aef5751539d7bffd709796', 'next_key': None}, 'xafcdd624343d8d07cdd1debd': {'target': 'x3e33a27dfc4c317f96efc343', 'next_key': None}}}, 'xfb8208bcc1122c05c3ac3730': {'kind': 'service', 'operation': 'login', 'handler': 'xe64e081f6ae99570ea3159c2'}, 'x30d6ffc68e8e2547b7256e95': {'kind': 'service', 'operation': 'logout', 'handler': 'x850efeee2da6b781acdbf4d4'}, 'x9dbd8089ff62637a0b8b8812': {'kind': 'service', 'operation': 'catalog', 'handler': 'x8b00ed0d52ce9d51c11247ca'}, 'x5b3c8b2f693bb3492b30ec34': {'kind': 'service', 'operation': 'create_order', 'handler': 'x48ce58ff55c33de0a0d6a120'}, 'x8be714fff7cee3eaaef3abfc': {'kind': 'service', 'operation': 'order', 'handler': 'x47d01fdc9c37700853bfcab1'}, 'x55aef5751539d7bffd709796': {'kind': 'service', 'operation': 'orders', 'handler': 'x5e1cfe33502cf3006a55dd6a'}, 'x3e33a27dfc4c317f96efc343': {'kind': 'service', 'operation': 'update_product', 'handler': 'x7854181f4980b250faa84d13'}}
ENTRY = 'xa50ab0114e2890c3166405e6'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    rebuilt = {}
    forest = []
    for index, path in enumerate(graph[entry]['edges']):
        node, key = entry, path
        visited = set()
        while graph[node]['kind'] != 'service':
            if node in visited:
                raise ValueError('routing cycle')
            visited.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        rebuilt[node] = dict(graph[node])
        gate = 'route_gate_' + str(index)
        rebuilt[gate] = {'kind': 'router', 'edges': {path: {'target': node, 'next_key': None}}}
        weight = len(path) + len(graph[node]['operation'])
        forest.append((weight, gate, [path]))
    if not forest:
        return {'route_empty': {'kind': 'router', 'edges': {}}}, 'route_empty'
    serial = 0
    while len(forest) > 1:
        forest.sort(key=lambda item: (item[0], item[1]))
        left, right = forest[0], forest[1]
        forest = forest[2:]
        parent = 'route_merge_' + str(serial)
        serial += 1
        edges = {}
        paths = []
        for weight, child, members in (left, right):
            for path in members:
                edges[path] = {'target': child, 'next_key': path}
                paths.append(path)
        rebuilt[parent] = {'kind': 'router', 'edges': edges}
        forest.append((left[0] + right[0], parent, paths))
    return rebuilt, forest[0][1]

def resolve(path):
    node, key = ENTRY, path
    visited, trace = set(), []
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
