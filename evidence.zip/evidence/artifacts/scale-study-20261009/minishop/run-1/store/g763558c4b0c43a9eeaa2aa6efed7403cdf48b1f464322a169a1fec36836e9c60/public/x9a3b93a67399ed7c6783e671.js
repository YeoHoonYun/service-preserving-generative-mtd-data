import {send} from './x10ad0092b782643b2b08505e.js';
export async function x19327626de448b8926a33523(data,csrf){const wire={};const value=await send("/xd994bde4424700e86e396091",wire,csrf);return value[0];}
export async function x915c89c96c29bdec250098fb(data,csrf){const wire={"x4907437ad01ce487f6a1c1bd":{}};const value=await send("/x2772b670b3d371c8d63b8de4",wire,csrf);return value[0];}
