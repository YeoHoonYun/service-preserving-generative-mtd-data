import {x00771573dc408024afaf035f,xfe99329eae42b261ce38edc8} from './xa5fe346a44231b1a58dad759.js';
import {x19327626de448b8926a33523,x915c89c96c29bdec250098fb} from './x9a3b93a67399ed7c6783e671.js';
import {x40df693c7509b247eac909cf,xe5602ac9c3fbaa15959e543a} from './xba7aeba3c4fac0babfd6ba89.js';
import {x14bf16c9aef3fb35e977230a} from './xf9f80473822f9f4da0e5c362.js';

let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('x2bc9d399c19570b37adeb7fa');
const endpoints={login:x00771573dc408024afaf035f,logout:x19327626de448b8926a33523,catalog:x40df693c7509b247eac909cf,create_order:x14bf16c9aef3fb35e977230a,order:xfe99329eae42b261ce38edc8,orders:x915c89c96c29bdec250098fb,update_product:xe5602ac9c3fbaa15959e543a};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('xcee2380fd140e4a41efb78c8').textContent=boot.user?boot.user.id:'방문자';}
function run(promise){promise.catch(error=>message.textContent=error.message);}

async function renderList(operation){
  const products=operation==='catalog';
  const list=document.getElementById(products?'xb121958fb49d19e538561a33':'x8def49476a00455ea1d62ef2');
  list.replaceChildren();
  for(const item of await api(operation)){
    const li=document.createElement('li');
    li.textContent=products?item.id+' · '+item.name+' · '+item.price+'원 · 재고 '+item.stock:item.id+' · '+item.total+'원';
    list.append(li);
  }
  if(products)document.body.dataset.ready='yes';
}
function catalog(){return renderList('catalog');}
function orders(){return renderList('orders');}

async function submitForm(form){
  const raw=Object.fromEntries(new FormData(form));
  const data={username:raw['xd814ac5a1ec3f29fb7c9bf96'],password:raw['x7f5b8ff30f9f5b6a9a85bde8'],product_id:raw['xb0b3959d73e2c14ec80019c1'],quantity:raw['xbcd6486e14a1315e1e1c12d4'],price:raw['x68210bcd987fde4dc49e44f9'],stock:raw['x1d00572e903ab85dc0f9bcb1']};
  let phase=0;
  while(phase!==6){
    switch(phase){
      case 0:
        if(form.dataset.action==='x3be6f79cff8224a97c7bc5c8'){
          boot=await api('login',data);
          identity();
          message.textContent='로그인되었습니다.';
        }
        phase=1;
        break;
      case 1:
        if(form.dataset.action==='xba109943a259e08f96b46d9e'){
          const order=await api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()});
          message.textContent='주문 '+order.id+' · '+order.total+'원';
          phase=2;
        }else phase=4;
        break;
      case 2:
        await catalog();
        phase=3;
        break;
      case 3:
        await orders();
        phase=4;
        break;
      case 4:
        if(form.dataset.action==='x77950a9462ff82ed2c39181c'){
          await api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)});
          message.textContent='상품을 수정했습니다.';
          phase=5;
        }else phase=6;
        break;
      case 5:
        await catalog();
        phase=6;
        break;
    }
  }
}
function receiveSubmit(event){event.preventDefault();run(submitForm(event.target));}
document.addEventListener('submit',receiveSubmit);
document.getElementById('x4f291d6647312360f90c5cc7').onclick=()=>run(api('logout').then(()=>location.reload()));
document.getElementById('x29382d902e0a76af369af795').onclick=()=>run(orders());
identity();
run(catalog());
