import {send} from './x10ad0092b782643b2b08505e.js';
export async function x40df693c7509b247eac909cf(data,csrf){const wire={"x052bfdc2e73c0259fb99c1dc":[]};const value=await send("/xf947661c791f7345d01b3986",wire,csrf);return value[0];}
export async function xe5602ac9c3fbaa15959e543a(data,csrf){const wire={"xa454e4dd5e6ef966d3fe5a45":[["xe019cfaa2e6113072a7277f5",data["product_id"]],["x8a8c6617a231bea92c304aa6",data["stock"]],["x96c6d17fdfe30a2b22a259f6",data["price"]]]};const value=await send("/x1c4e49040a510f67cdc605d4",wire,csrf);return value[0];}
