import {send} from './x10ad0092b782643b2b08505e.js';
export async function x00771573dc408024afaf035f(data,csrf){const wire={"x88ceeef748f5d2cda828248a":data["password"],"x9585347381b040da168506b2":data["username"]};const value=await send("/x8551546e384fa15be747461a",wire,csrf);return value[0];}
export async function xfe99329eae42b261ce38edc8(data,csrf){const wire=[data["order_id"]];const value=await send("/x1901c7359b4da376aa947922",wire,csrf);return value["x7b486725ab45d02350a2523c"]["xc5383a57d027a04ebb0fe78f"];}
