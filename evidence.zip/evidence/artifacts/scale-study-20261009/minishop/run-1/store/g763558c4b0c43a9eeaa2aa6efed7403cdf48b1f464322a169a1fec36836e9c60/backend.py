# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x8551546e384fa15be747461a', 'fields': ['password', 'username'], 'aliases': {'password': 'x88ceeef748f5d2cda828248a', 'username': 'x9585347381b040da168506b2'}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'x20a29de9a0a48cbb743a21ef', 'response_box': 'x58947c540e07141d941b97fe', 'result_key': 'x915019a29930ded7df821bb3'}, 'logout': {'route': '/xd994bde4424700e86e396091', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'x56d271806f8b01ae44f246b9', 'response_box': 'x4bb4df8c917bfb4f8d2cc2ca', 'result_key': 'x52233ef09b2c7fafd8b960db'}, 'catalog': {'route': '/xf947661c791f7345d01b3986', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'x052bfdc2e73c0259fb99c1dc', 'response_box': 'xa3ffe87bdb1f049a965eea8d', 'result_key': 'x4326a775c1bd5ac646004c71'}, 'create_order': {'route': '/x25460bbf636e35b255df5c0b', 'fields': ['product_id', 'quantity', 'request_id'], 'aliases': {'product_id': 'xbd34eba2784214906d3c1de6', 'quantity': 'x375f49a8fa1fb6f3976c675c', 'request_id': 'x87a72bde293ef644de4a432b'}, 'request_shape': 'wrapped', 'response_shape': 'object', 'request_box': 'x69e740173e61586cf4407347', 'response_box': 'x7e17e4ed9c7fcc718d343450', 'result_key': 'x5737bf033689962fdf95dbf4'}, 'order': {'route': '/x1901c7359b4da376aa947922', 'fields': ['order_id'], 'aliases': {'order_id': 'x522ad6ea1a5cd844d48a1650'}, 'request_shape': 'positional', 'response_shape': 'wrapped', 'request_box': 'xe56ff8495f86ebc566a10f91', 'response_box': 'x7b486725ab45d02350a2523c', 'result_key': 'xc5383a57d027a04ebb0fe78f'}, 'orders': {'route': '/x2772b670b3d371c8d63b8de4', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x4907437ad01ce487f6a1c1bd', 'response_box': 'x5612c52baea1bdecc90f5e02', 'result_key': 'xb5782302c64e6d1f6fcd2a4b'}, 'update_product': {'route': '/x1c4e49040a510f67cdc605d4', 'fields': ['product_id', 'stock', 'price'], 'aliases': {'product_id': 'xe019cfaa2e6113072a7277f5', 'stock': 'x8a8c6617a231bea92c304aa6', 'price': 'x96c6d17fdfe30a2b22a259f6'}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'xa454e4dd5e6ef966d3fe5a45', 'response_box': 'x7a66fa6042f3ac2195a29294', 'result_key': 'x9bac82ef0cb9bfc182d0bfa6'}}
HANDLERS = {'login': 'xe64e081f6ae99570ea3159c2', 'logout': 'x850efeee2da6b781acdbf4d4', 'catalog': 'x8b00ed0d52ce9d51c11247ca', 'create_order': 'x48ce58ff55c33de0a0d6a120', 'order': 'x47d01fdc9c37700853bfcab1', 'orders': 'x5e1cfe33502cf3006a55dd6a', 'update_product': 'x7854181f4980b250faa84d13'}
BACKEND_GRAPH = {'xe64e081f6ae99570ea3159c2': {'operation': 'login', 'target': 'x8fc40c4a6f5bd8d669e9dca6', 'kind': 'adapter'}, 'x8fc40c4a6f5bd8d669e9dca6': {'operation': 'login', 'target': 'x8c1ec994347728084b670db2', 'kind': 'adapter'}, 'x8c1ec994347728084b670db2': {'operation': 'login', 'target': 'xb1447c5ff316e0d546e9c781', 'kind': 'adapter'}, 'xb1447c5ff316e0d546e9c781': {'operation': 'login', 'target': 'xa70b95830ddbd27a6cb83aa0', 'kind': 'adapter'}, 'xa70b95830ddbd27a6cb83aa0': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x850efeee2da6b781acdbf4d4': {'operation': 'logout', 'target': 'xc11d4582943d3d9f1deac7ef', 'kind': 'adapter'}, 'xc11d4582943d3d9f1deac7ef': {'operation': 'logout', 'target': 'x3821627de6944f8fa59f486b', 'kind': 'adapter'}, 'x3821627de6944f8fa59f486b': {'operation': 'logout', 'target': 'x7c19754b1b0a1a8b2dc4d7d1', 'kind': 'adapter'}, 'x7c19754b1b0a1a8b2dc4d7d1': {'operation': 'logout', 'target': 'x58dc9dc9b1edfeefa831b583', 'kind': 'adapter'}, 'x58dc9dc9b1edfeefa831b583': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x8b00ed0d52ce9d51c11247ca': {'operation': 'catalog', 'target': 'x2683877bc527ecd22f185356', 'kind': 'adapter'}, 'x2683877bc527ecd22f185356': {'operation': 'catalog', 'target': 'xe613ee0297ced1c43d306b3d', 'kind': 'adapter'}, 'xe613ee0297ced1c43d306b3d': {'operation': 'catalog', 'target': 'x6b44167139377a158561f829', 'kind': 'adapter'}, 'x6b44167139377a158561f829': {'operation': 'catalog', 'target': 'x78e25b15ee9d1e26ef000d19', 'kind': 'adapter'}, 'x78e25b15ee9d1e26ef000d19': {'operation': 'catalog', 'target': 'x86eedb0e4f37df2693ce3e84', 'kind': 'adapter'}, 'x86eedb0e4f37df2693ce3e84': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x48ce58ff55c33de0a0d6a120': {'operation': 'create_order', 'target': 'x12121e2620db1270d522a90e', 'kind': 'adapter'}, 'x12121e2620db1270d522a90e': {'operation': 'create_order', 'target': 'x69d72fb072f9c19d0636f85f', 'kind': 'adapter'}, 'x69d72fb072f9c19d0636f85f': {'operation': 'create_order', 'target': 'x83f1bbe180570ea15dc37c8e', 'kind': 'adapter'}, 'x83f1bbe180570ea15dc37c8e': {'operation': 'create_order', 'target': 'x8a778c21094b428ab0121a41', 'kind': 'adapter'}, 'x8a778c21094b428ab0121a41': {'operation': 'create_order', 'target': 'x91bced1820f3c445de7b9b3f', 'kind': 'adapter'}, 'x91bced1820f3c445de7b9b3f': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x47d01fdc9c37700853bfcab1': {'operation': 'order', 'target': 'x63ee1723551541684140274c', 'kind': 'adapter'}, 'x63ee1723551541684140274c': {'operation': 'order', 'target': 'x6ecd1218c0c49a407a0ba8c7', 'kind': 'adapter'}, 'x6ecd1218c0c49a407a0ba8c7': {'operation': 'order', 'target': 'xd3fd30813fd109fb7b3bd4dd', 'kind': 'adapter'}, 'xd3fd30813fd109fb7b3bd4dd': {'operation': 'order', 'target': 'x7265aa9b0d70594887d9277b', 'kind': 'adapter'}, 'x7265aa9b0d70594887d9277b': {'operation': 'order', 'target': 'xc403d31d420b4e74d808df40', 'kind': 'adapter'}, 'xc403d31d420b4e74d808df40': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x5e1cfe33502cf3006a55dd6a': {'operation': 'orders', 'target': 'xf7971ad0a4260abfd26b5aaa', 'kind': 'adapter'}, 'xf7971ad0a4260abfd26b5aaa': {'operation': 'orders', 'target': 'xcc7bde9ad1a26eea415ae514', 'kind': 'adapter'}, 'xcc7bde9ad1a26eea415ae514': {'operation': 'orders', 'target': 'x65eda12b9da624b427003267', 'kind': 'adapter'}, 'x65eda12b9da624b427003267': {'operation': 'orders', 'target': 'x1e3316e75fe7e8b8b5e0a947', 'kind': 'adapter'}, 'x1e3316e75fe7e8b8b5e0a947': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x7854181f4980b250faa84d13': {'operation': 'update_product', 'target': 'x1880b5ecdcd53b958aa797d1', 'kind': 'adapter'}, 'x1880b5ecdcd53b958aa797d1': {'operation': 'update_product', 'target': 'xd91316bc6236dcea42216a9c', 'kind': 'adapter'}, 'xd91316bc6236dcea42216a9c': {'operation': 'update_product', 'target': 'xabfdf5e61d2e9d3028614571', 'kind': 'adapter'}, 'xabfdf5e61d2e9d3028614571': {'operation': 'update_product', 'target': 'xe1d14294c4208f31a450bbc9', 'kind': 'adapter'}, 'xe1d14294c4208f31a450bbc9': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xe64e081f6ae99570ea3159c2(core, operation, data, session, actor, trace):
    trace.append('xe64e081f6ae99570ea3159c2')
    return x8fc40c4a6f5bd8d669e9dca6(core, operation, data, session, actor, trace)

def x8fc40c4a6f5bd8d669e9dca6(core, operation, data, session, actor, trace):
    trace.append('x8fc40c4a6f5bd8d669e9dca6')
    return x8c1ec994347728084b670db2(core, operation, data, session, actor, trace)

def x8c1ec994347728084b670db2(core, operation, data, session, actor, trace):
    trace.append('x8c1ec994347728084b670db2')
    return xb1447c5ff316e0d546e9c781(core, operation, data, session, actor, trace)

def xb1447c5ff316e0d546e9c781(core, operation, data, session, actor, trace):
    trace.append('xb1447c5ff316e0d546e9c781')
    return xa70b95830ddbd27a6cb83aa0(core, operation, data, session, actor, trace)

def xa70b95830ddbd27a6cb83aa0(core, operation, data, session, actor, trace):
    trace.append('xa70b95830ddbd27a6cb83aa0')
    return core.execute(operation, data, session, actor)

def x850efeee2da6b781acdbf4d4(core, operation, data, session, actor, trace):
    trace.append('x850efeee2da6b781acdbf4d4')
    return xc11d4582943d3d9f1deac7ef(core, operation, data, session, actor, trace)

def xc11d4582943d3d9f1deac7ef(core, operation, data, session, actor, trace):
    trace.append('xc11d4582943d3d9f1deac7ef')
    return x3821627de6944f8fa59f486b(core, operation, data, session, actor, trace)

def x3821627de6944f8fa59f486b(core, operation, data, session, actor, trace):
    trace.append('x3821627de6944f8fa59f486b')
    return x7c19754b1b0a1a8b2dc4d7d1(core, operation, data, session, actor, trace)

def x7c19754b1b0a1a8b2dc4d7d1(core, operation, data, session, actor, trace):
    trace.append('x7c19754b1b0a1a8b2dc4d7d1')
    return x58dc9dc9b1edfeefa831b583(core, operation, data, session, actor, trace)

def x58dc9dc9b1edfeefa831b583(core, operation, data, session, actor, trace):
    trace.append('x58dc9dc9b1edfeefa831b583')
    return core.execute(operation, data, session, actor)

def x8b00ed0d52ce9d51c11247ca(core, operation, data, session, actor, trace):
    trace.append('x8b00ed0d52ce9d51c11247ca')
    return x2683877bc527ecd22f185356(core, operation, data, session, actor, trace)

def x2683877bc527ecd22f185356(core, operation, data, session, actor, trace):
    trace.append('x2683877bc527ecd22f185356')
    return xe613ee0297ced1c43d306b3d(core, operation, data, session, actor, trace)

def xe613ee0297ced1c43d306b3d(core, operation, data, session, actor, trace):
    trace.append('xe613ee0297ced1c43d306b3d')
    return x6b44167139377a158561f829(core, operation, data, session, actor, trace)

def x6b44167139377a158561f829(core, operation, data, session, actor, trace):
    trace.append('x6b44167139377a158561f829')
    return x78e25b15ee9d1e26ef000d19(core, operation, data, session, actor, trace)

def x78e25b15ee9d1e26ef000d19(core, operation, data, session, actor, trace):
    trace.append('x78e25b15ee9d1e26ef000d19')
    return x86eedb0e4f37df2693ce3e84(core, operation, data, session, actor, trace)

def x86eedb0e4f37df2693ce3e84(core, operation, data, session, actor, trace):
    trace.append('x86eedb0e4f37df2693ce3e84')
    return core.execute(operation, data, session, actor)

def x48ce58ff55c33de0a0d6a120(core, operation, data, session, actor, trace):
    trace.append('x48ce58ff55c33de0a0d6a120')
    return x12121e2620db1270d522a90e(core, operation, data, session, actor, trace)

def x12121e2620db1270d522a90e(core, operation, data, session, actor, trace):
    trace.append('x12121e2620db1270d522a90e')
    return x69d72fb072f9c19d0636f85f(core, operation, data, session, actor, trace)

def x69d72fb072f9c19d0636f85f(core, operation, data, session, actor, trace):
    trace.append('x69d72fb072f9c19d0636f85f')
    return x83f1bbe180570ea15dc37c8e(core, operation, data, session, actor, trace)

def x83f1bbe180570ea15dc37c8e(core, operation, data, session, actor, trace):
    trace.append('x83f1bbe180570ea15dc37c8e')
    return x8a778c21094b428ab0121a41(core, operation, data, session, actor, trace)

def x8a778c21094b428ab0121a41(core, operation, data, session, actor, trace):
    trace.append('x8a778c21094b428ab0121a41')
    return x91bced1820f3c445de7b9b3f(core, operation, data, session, actor, trace)

def x91bced1820f3c445de7b9b3f(core, operation, data, session, actor, trace):
    trace.append('x91bced1820f3c445de7b9b3f')
    return core.execute(operation, data, session, actor)

def x47d01fdc9c37700853bfcab1(core, operation, data, session, actor, trace):
    trace.append('x47d01fdc9c37700853bfcab1')
    return x63ee1723551541684140274c(core, operation, data, session, actor, trace)

def x63ee1723551541684140274c(core, operation, data, session, actor, trace):
    trace.append('x63ee1723551541684140274c')
    return x6ecd1218c0c49a407a0ba8c7(core, operation, data, session, actor, trace)

def x6ecd1218c0c49a407a0ba8c7(core, operation, data, session, actor, trace):
    trace.append('x6ecd1218c0c49a407a0ba8c7')
    return xd3fd30813fd109fb7b3bd4dd(core, operation, data, session, actor, trace)

def xd3fd30813fd109fb7b3bd4dd(core, operation, data, session, actor, trace):
    trace.append('xd3fd30813fd109fb7b3bd4dd')
    return x7265aa9b0d70594887d9277b(core, operation, data, session, actor, trace)

def x7265aa9b0d70594887d9277b(core, operation, data, session, actor, trace):
    trace.append('x7265aa9b0d70594887d9277b')
    return xc403d31d420b4e74d808df40(core, operation, data, session, actor, trace)

def xc403d31d420b4e74d808df40(core, operation, data, session, actor, trace):
    trace.append('xc403d31d420b4e74d808df40')
    return core.execute(operation, data, session, actor)

def x5e1cfe33502cf3006a55dd6a(core, operation, data, session, actor, trace):
    trace.append('x5e1cfe33502cf3006a55dd6a')
    return xf7971ad0a4260abfd26b5aaa(core, operation, data, session, actor, trace)

def xf7971ad0a4260abfd26b5aaa(core, operation, data, session, actor, trace):
    trace.append('xf7971ad0a4260abfd26b5aaa')
    return xcc7bde9ad1a26eea415ae514(core, operation, data, session, actor, trace)

def xcc7bde9ad1a26eea415ae514(core, operation, data, session, actor, trace):
    trace.append('xcc7bde9ad1a26eea415ae514')
    return x65eda12b9da624b427003267(core, operation, data, session, actor, trace)

def x65eda12b9da624b427003267(core, operation, data, session, actor, trace):
    trace.append('x65eda12b9da624b427003267')
    return x1e3316e75fe7e8b8b5e0a947(core, operation, data, session, actor, trace)

def x1e3316e75fe7e8b8b5e0a947(core, operation, data, session, actor, trace):
    trace.append('x1e3316e75fe7e8b8b5e0a947')
    return core.execute(operation, data, session, actor)

def x7854181f4980b250faa84d13(core, operation, data, session, actor, trace):
    trace.append('x7854181f4980b250faa84d13')
    return x1880b5ecdcd53b958aa797d1(core, operation, data, session, actor, trace)

def x1880b5ecdcd53b958aa797d1(core, operation, data, session, actor, trace):
    trace.append('x1880b5ecdcd53b958aa797d1')
    return xd91316bc6236dcea42216a9c(core, operation, data, session, actor, trace)

def xd91316bc6236dcea42216a9c(core, operation, data, session, actor, trace):
    trace.append('xd91316bc6236dcea42216a9c')
    return xabfdf5e61d2e9d3028614571(core, operation, data, session, actor, trace)

def xabfdf5e61d2e9d3028614571(core, operation, data, session, actor, trace):
    trace.append('xabfdf5e61d2e9d3028614571')
    return xe1d14294c4208f31a450bbc9(core, operation, data, session, actor, trace)

def xe1d14294c4208f31a450bbc9(core, operation, data, session, actor, trace):
    trace.append('xe1d14294c4208f31a450bbc9')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def bind_adapter(adapter, arguments):
    def deliver(continuation):
        trace = []
        response = adapter(*(arguments + (trace,)))
        return continuation(response, trace)
    return deliver

def finish_adapter(response, trace):
    status, result, cookie = response
    return status, result, cookie, trace

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    adapters = {
        'login': xe64e081f6ae99570ea3159c2,
        'logout': x850efeee2da6b781acdbf4d4,
        'catalog': x8b00ed0d52ce9d51c11247ca,
        'create_order': x48ce58ff55c33de0a0d6a120,
        'order': x47d01fdc9c37700853bfcab1,
        'orders': x5e1cfe33502cf3006a55dd6a,
        'update_product': x7854181f4980b250faa84d13
    }
    if operation not in adapters:
        return ORIGINAL_INVOKE(handler_name, core, operation, data, session, actor)
    delivery = bind_adapter(adapters[operation], (core, operation, data, session, actor))
    return delivery(finish_adapter)

