import {xb6bc75e5044b78e7d0779446,x40f6494a028a24780b7b84c1,x1f26d72ed0721ce4d457c71d,x6f3f44b79d6f00d8bd5618b3} from './x5a577604a7f51b3c8ccc6192.js';
import {xbd4f63ad5c4ce7f1710002d0,x373319e9214f99172c0682ca,xec5df5a2acd7c80767c17471} from './xc4af56bafa2fdc4a8c9185af.js';
let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('x58e15504073be43342599fbd');
const endpoints={login:xb6bc75e5044b78e7d0779446,logout:xbd4f63ad5c4ce7f1710002d0,catalog:x40f6494a028a24780b7b84c1,create_order:x373319e9214f99172c0682ca,order:x1f26d72ed0721ce4d457c71d,orders:xec5df5a2acd7c80767c17471,update_product:x6f3f44b79d6f00d8bd5618b3};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('x9345f5030c54abb7fac1bbc5').textContent=boot.user?boot.user.id:'방문자';}
function run(promise){promise.catch(error=>message.textContent=error.message);}
async function catalog(){
 const list=document.getElementById('xd20d98eb51a1ab343d5f30b1');
 list.replaceChildren();
 for(const p of await api('catalog')){
  const li=document.createElement('li');
  li.textContent=p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock;
  list.append(li);
 }
 document.body.dataset.ready='yes';
}
async function orders(){
 const list=document.getElementById('xad06bd8069b8714e621280fd');
 list.replaceChildren();
 for(const order of await api('orders')){
  const li=document.createElement('li');
  li.textContent=order.id+' · '+order.total+'원';
  list.append(li);
 }
}
const tasks={
 login:{needs:[],perform:async data=>{boot=await api('login',data);identity();message.textContent='로그인되었습니다.';}},
 place:{needs:[],perform:data=>api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()})},
 receipt:{needs:['place'],perform:(data,[order])=>{message.textContent='주문 '+order.id+' · '+order.total+'원';}},
 purchaseCatalog:{needs:['receipt'],perform:()=>catalog()},
 purchaseDone:{needs:['purchaseCatalog'],perform:()=>orders()},
 save:{needs:[],perform:data=>api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)})},
 saveNotice:{needs:['save'],perform:()=>{message.textContent='상품을 수정했습니다.';}},
 saveDone:{needs:['saveNotice'],perform:()=>catalog()}
};
async function executeTask(name,data){
 const values=new Map();
 async function visit(key){
  if(values.has(key))return values.get(key);
  const task=tasks[key],inputs=[];
  for(const dependency of task.needs)inputs.push(await visit(dependency));
  const value=await task.perform(data,inputs);
  values.set(key,value);
  return value;
 }
 return visit(name);
}
const submissions=[
 ['x71979967b354719395a04dea','login'],
 ['x20a6f76a24d7da914a6ab446','purchaseDone'],
 ['x49046b3b352437c2991cd370','saveDone']
];
async function submit(form){
 const raw=Object.fromEntries(new FormData(form));
 const data={username:raw['xa77f2ef128b9eed9a59524c4'],password:raw['x2ed1281b07bd43375f2e7521'],product_id:raw['xaa553821e21960775f61af23'],quantity:raw['x7a8cb85b0aeb7ee2cffe1c4e'],price:raw['x85c771f57fc4af98d122810e'],stock:raw['x9d1d18c387800cba00733f4b']};
 for(const [action,terminal] of submissions){
  if(form.dataset.action===action)await executeTask(terminal,data);
 }
}
document.addEventListener('submit',event=>{event.preventDefault();run(submit(event.target));});
document.getElementById('xed84b03d903d5a7855a2e922').onclick=()=>run(api('logout').then(()=>location.reload()));
document.getElementById('xe52b6be9b2d7270b285385b8').onclick=()=>run(orders());
identity();run(catalog());
