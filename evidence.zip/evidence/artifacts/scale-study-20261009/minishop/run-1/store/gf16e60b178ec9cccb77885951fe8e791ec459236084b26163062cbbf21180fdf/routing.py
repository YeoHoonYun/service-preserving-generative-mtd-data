GRAPH = {'x8fdc754626da0d9056f36eb2': {'kind': 'router', 'edges': {'/xcf2f4a7310b986cebb8998dc': {'target': 'x04405d02d3aa6413c86b84a1', 'next_key': 'x2af7136dd960c6f3eb04830e'}, '/x83625694bb15f88f68773a0a': {'target': 'x7bef72f4c99db60c8d580ca1', 'next_key': 'x7b81ed0b574d7b7577244352'}, '/x5565bac525e23ee441b13461': {'target': 'x04405d02d3aa6413c86b84a1', 'next_key': 'x60a381c564c1ca5bc44edda0'}, '/x7bc11498d4ef4d89d41e30e7': {'target': 'x7bef72f4c99db60c8d580ca1', 'next_key': 'x1d0ef0cb4b0b865c812d139b'}, '/x6ffd972dca0cbe3f80b4ed29': {'target': 'x04405d02d3aa6413c86b84a1', 'next_key': 'xda81e1fb5369aa611273c48a'}, '/x6aa37ffef36ae345d554e995': {'target': 'x7bef72f4c99db60c8d580ca1', 'next_key': 'x240a2af57f8e25b2f4f4cb6e'}, '/x571b74d678e6bc098fdb5663': {'target': 'x04405d02d3aa6413c86b84a1', 'next_key': 'x0d15bc1bbb184885cfd9bfbd'}}}, 'x04405d02d3aa6413c86b84a1': {'kind': 'router', 'edges': {'x2af7136dd960c6f3eb04830e': {'target': 'x56a715164962d7d2c4d446e0', 'next_key': 'x6cdfdb64a24410d46f6bc8bc'}, 'x60a381c564c1ca5bc44edda0': {'target': 'x56a715164962d7d2c4d446e0', 'next_key': 'xdcc2b76a6ea456c21c2634d0'}, 'xda81e1fb5369aa611273c48a': {'target': 'x56a715164962d7d2c4d446e0', 'next_key': 'x722238141f7b64ad93ebd858'}, 'x0d15bc1bbb184885cfd9bfbd': {'target': 'x56a715164962d7d2c4d446e0', 'next_key': 'x816e8f797c374281498c2eb4'}}}, 'x7bef72f4c99db60c8d580ca1': {'kind': 'router', 'edges': {'x7b81ed0b574d7b7577244352': {'target': 'x56a715164962d7d2c4d446e0', 'next_key': 'x134fb025f92a45c71402c8de'}, 'x1d0ef0cb4b0b865c812d139b': {'target': 'x56a715164962d7d2c4d446e0', 'next_key': 'x1946f9db58252ea9fe0459fb'}, 'x240a2af57f8e25b2f4f4cb6e': {'target': 'x56a715164962d7d2c4d446e0', 'next_key': 'xecd95dfd46a32685e6ab3e14'}}}, 'x56a715164962d7d2c4d446e0': {'kind': 'router', 'edges': {'x6cdfdb64a24410d46f6bc8bc': {'target': 'x6448c1265f164feb977d1cd3', 'next_key': None}, 'x134fb025f92a45c71402c8de': {'target': 'x9d3731a385e342f07c808e23', 'next_key': None}, 'xdcc2b76a6ea456c21c2634d0': {'target': 'x71bad902a68a846f926da2d0', 'next_key': None}, 'x1946f9db58252ea9fe0459fb': {'target': 'x81dd5a885881e8976413d60c', 'next_key': None}, 'x722238141f7b64ad93ebd858': {'target': 'xe13e918b19c3313eb8f27644', 'next_key': None}, 'xecd95dfd46a32685e6ab3e14': {'target': 'x98d57a2abdc4b9a164b0abc1', 'next_key': None}, 'x816e8f797c374281498c2eb4': {'target': 'x7dc52afa739656e7b2611d51', 'next_key': None}}}, 'x6448c1265f164feb977d1cd3': {'kind': 'service', 'operation': 'login', 'handler': 'xa16ba6a31b995021a94b613b'}, 'x9d3731a385e342f07c808e23': {'kind': 'service', 'operation': 'logout', 'handler': 'x4874184d343e2f55f804d26b'}, 'x71bad902a68a846f926da2d0': {'kind': 'service', 'operation': 'catalog', 'handler': 'xe464de6e5a77fec63cbfe7b3'}, 'x81dd5a885881e8976413d60c': {'kind': 'service', 'operation': 'create_order', 'handler': 'x6fca747f1425a47ad3861b77'}, 'xe13e918b19c3313eb8f27644': {'kind': 'service', 'operation': 'order', 'handler': 'x4b7789d4fc6fd103cb1609f6'}, 'x98d57a2abdc4b9a164b0abc1': {'kind': 'service', 'operation': 'orders', 'handler': 'x425f2e98d419f472752530bd'}, 'x7dc52afa739656e7b2611d51': {'kind': 'service', 'operation': 'update_product', 'handler': 'x12dca9dc39b7b91406a6ca2f'}}
ENTRY = 'x8fdc754626da0d9056f36eb2'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    bindings = []
    for path in sorted(graph[entry]['edges']):
        node, key, seen = entry, path, set()
        while True:
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            item = graph[node]
            if item['kind'] == 'service':
                bindings.append((path, dict(item)))
                break
            edge = item['edges'][key]
            node, key = edge['target'], edge['next_key']
    root = 'rebuilt:root'
    result = {root: {'kind': 'router', 'edges': {}}}
    count = len(bindings)
    for index, binding in enumerate(bindings):
        result['rebuilt:service:' + str(index)] = binding[1]
    middle = (count + 1) // 2
    for low, high in ((0, middle), (middle, count)):
        if low == high:
            continue
        head = 'rebuilt:ladder:' + str(low)
        for index in range(low, high):
            path = bindings[index][0]
            result[root]['edges'][path] = {'target': head, 'next_key': path}
        for position in range(low, max(low + 1, high - 1)):
            edges = {}
            for index in range(position, high):
                path = bindings[index][0]
                if index == position or high - position <= 2:
                    edges[path] = {'target': 'rebuilt:service:' + str(index), 'next_key': None}
                else:
                    edges[path] = {'target': 'rebuilt:ladder:' + str(position + 1), 'next_key': path}
            result['rebuilt:ladder:' + str(position)] = {'kind': 'router', 'edges': edges}
    return result, root

def resolve(path):
    node, key = ENTRY, path
    visited, trace = set(), []
    while node not in visited:
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
