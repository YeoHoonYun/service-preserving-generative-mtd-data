import {send} from './x5a6bc4dc87b507b86689eb7c.js';
export async function xbd4f63ad5c4ce7f1710002d0(data,csrf){const wire={};const value=await send("/x83625694bb15f88f68773a0a",wire,csrf);return value["x7cae5710e8be8282a2547598"]["x6eab778b9dea7261f028ce3e"];}
export async function x373319e9214f99172c0682ca(data,csrf){const wire={"x5c45e438c3f05a800ad171a6":{"xf0f963509736da90c11fd40e":data["quantity"],"x2b8b9db8f3a4af811dc2dbb3":data["product_id"],"x8b35b8bd96a48f93d447523a":data["request_id"]}};const value=await send("/x7bc11498d4ef4d89d41e30e7",wire,csrf);return value["x64a2597df02fa88ff95faca4"];}
export async function xec5df5a2acd7c80767c17471(data,csrf){const wire={"x2bd81a2f60c600cf2c40480f":{}};const value=await send("/x6aa37ffef36ae345d554e995",wire,csrf);return value[0];}
