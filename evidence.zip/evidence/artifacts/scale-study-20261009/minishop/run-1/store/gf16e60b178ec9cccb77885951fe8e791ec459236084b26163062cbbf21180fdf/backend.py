# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/xcf2f4a7310b986cebb8998dc', 'fields': ['password', 'username'], 'aliases': {'password': 'xcf0079d8165d7953d20037e1', 'username': 'x6754ff485b1925bd7dc5759c'}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'xfc983a92be464d43a443a041', 'response_box': 'x60ee12f28ea558d382af2004', 'result_key': 'xfd473dc928273a4b310095dd'}, 'logout': {'route': '/x83625694bb15f88f68773a0a', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'x9f9459de3c63b46e382d4ba5', 'response_box': 'x7cae5710e8be8282a2547598', 'result_key': 'x6eab778b9dea7261f028ce3e'}, 'catalog': {'route': '/x5565bac525e23ee441b13461', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'array', 'request_box': 'xa77d02eb45310a608109975f', 'response_box': 'xa422dfa316578b200f233541', 'result_key': 'x9a2134ed0852c32e9e3948b4'}, 'create_order': {'route': '/x7bc11498d4ef4d89d41e30e7', 'fields': ['quantity', 'product_id', 'request_id'], 'aliases': {'quantity': 'xf0f963509736da90c11fd40e', 'product_id': 'x2b8b9db8f3a4af811dc2dbb3', 'request_id': 'x8b35b8bd96a48f93d447523a'}, 'request_shape': 'wrapped', 'response_shape': 'object', 'request_box': 'x5c45e438c3f05a800ad171a6', 'response_box': 'x4bdda0628bbf7d69ee1795c3', 'result_key': 'x64a2597df02fa88ff95faca4'}, 'order': {'route': '/x6ffd972dca0cbe3f80b4ed29', 'fields': ['order_id'], 'aliases': {'order_id': 'xac7ad67deebbab71af5e484d'}, 'request_shape': 'pairs', 'response_shape': 'wrapped', 'request_box': 'x72c6be032d1c9b166cb840f2', 'response_box': 'x9aa0a207bd503a6610755f31', 'result_key': 'x6cfe8b960efe4766ff8135e2'}, 'orders': {'route': '/x6aa37ffef36ae345d554e995', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x2bd81a2f60c600cf2c40480f', 'response_box': 'x4dec506270e6e59d71ed484f', 'result_key': 'xae67eaae859b08ca0ece8fb3'}, 'update_product': {'route': '/x571b74d678e6bc098fdb5663', 'fields': ['product_id', 'stock', 'price'], 'aliases': {'product_id': 'xa3ebed012eab2c6a64125366', 'stock': 'x793e5b1c69b6732ab1b3a14a', 'price': 'x85165b884588bf09da2de17b'}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'xa261687f33f6a8712315901c', 'response_box': 'x9d44a13c4656349e67c96365', 'result_key': 'x54e31c36d3f4ce953a93a30d'}}
HANDLERS = {'login': 'xa16ba6a31b995021a94b613b', 'logout': 'x4874184d343e2f55f804d26b', 'catalog': 'xe464de6e5a77fec63cbfe7b3', 'create_order': 'x6fca747f1425a47ad3861b77', 'order': 'x4b7789d4fc6fd103cb1609f6', 'orders': 'x425f2e98d419f472752530bd', 'update_product': 'x12dca9dc39b7b91406a6ca2f'}
BACKEND_GRAPH = {'xa16ba6a31b995021a94b613b': {'operation': 'login', 'target': 'x242805a7c3117ff4a8e5182a', 'kind': 'adapter'}, 'x242805a7c3117ff4a8e5182a': {'operation': 'login', 'target': 'xbb30b970c3f88931778599a0', 'kind': 'adapter'}, 'xbb30b970c3f88931778599a0': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x4874184d343e2f55f804d26b': {'operation': 'logout', 'target': 'xbf3abfa118ab56d4c4345208', 'kind': 'adapter'}, 'xbf3abfa118ab56d4c4345208': {'operation': 'logout', 'target': 'x6a29f0e4df3e0aa7a1e77598', 'kind': 'adapter'}, 'x6a29f0e4df3e0aa7a1e77598': {'operation': 'logout', 'target': 'x30ac86f1b0c30ec9f130203e', 'kind': 'adapter'}, 'x30ac86f1b0c30ec9f130203e': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'xe464de6e5a77fec63cbfe7b3': {'operation': 'catalog', 'target': 'xb63eed882a30178f7af93c94', 'kind': 'adapter'}, 'xb63eed882a30178f7af93c94': {'operation': 'catalog', 'target': 'xc456b386624f5f8047a69def', 'kind': 'adapter'}, 'xc456b386624f5f8047a69def': {'operation': 'catalog', 'target': 'x2e930329f9ee4cdc64b0fba0', 'kind': 'adapter'}, 'x2e930329f9ee4cdc64b0fba0': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x6fca747f1425a47ad3861b77': {'operation': 'create_order', 'target': 'x4015f9bb9b4847b1a747e5f2', 'kind': 'adapter'}, 'x4015f9bb9b4847b1a747e5f2': {'operation': 'create_order', 'target': 'x08979880bd913097b8b2cba6', 'kind': 'adapter'}, 'x08979880bd913097b8b2cba6': {'operation': 'create_order', 'target': 'x09903c1c98c943a41aae60d7', 'kind': 'adapter'}, 'x09903c1c98c943a41aae60d7': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x4b7789d4fc6fd103cb1609f6': {'operation': 'order', 'target': 'xd29dfb02d31e55002ce038cf', 'kind': 'adapter'}, 'xd29dfb02d31e55002ce038cf': {'operation': 'order', 'target': 'xa695a2ce857012ae7a8becaa', 'kind': 'adapter'}, 'xa695a2ce857012ae7a8becaa': {'operation': 'order', 'target': 'xb124d4435dd31acabcaa51ff', 'kind': 'adapter'}, 'xb124d4435dd31acabcaa51ff': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x425f2e98d419f472752530bd': {'operation': 'orders', 'target': 'xdfab6f38d994ef1894d7741c', 'kind': 'adapter'}, 'xdfab6f38d994ef1894d7741c': {'operation': 'orders', 'target': 'x3cf2eba424021f5376cbd772', 'kind': 'adapter'}, 'x3cf2eba424021f5376cbd772': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x12dca9dc39b7b91406a6ca2f': {'operation': 'update_product', 'target': 'xfcbb4729a6f99a5011b8068f', 'kind': 'adapter'}, 'xfcbb4729a6f99a5011b8068f': {'operation': 'update_product', 'target': 'x396acc678077c310af56ff94', 'kind': 'adapter'}, 'x396acc678077c310af56ff94': {'operation': 'update_product', 'target': 'x4781a51f3c2c1186ba34c9f5', 'kind': 'adapter'}, 'x4781a51f3c2c1186ba34c9f5': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xa16ba6a31b995021a94b613b(core, operation, data, session, actor, trace):
    trace.append('xa16ba6a31b995021a94b613b')
    return x242805a7c3117ff4a8e5182a(core, operation, data, session, actor, trace)

def x242805a7c3117ff4a8e5182a(core, operation, data, session, actor, trace):
    trace.append('x242805a7c3117ff4a8e5182a')
    return xbb30b970c3f88931778599a0(core, operation, data, session, actor, trace)

def xbb30b970c3f88931778599a0(core, operation, data, session, actor, trace):
    trace.append('xbb30b970c3f88931778599a0')
    return core.execute(operation, data, session, actor)

def x4874184d343e2f55f804d26b(core, operation, data, session, actor, trace):
    trace.append('x4874184d343e2f55f804d26b')
    return xbf3abfa118ab56d4c4345208(core, operation, data, session, actor, trace)

def xbf3abfa118ab56d4c4345208(core, operation, data, session, actor, trace):
    trace.append('xbf3abfa118ab56d4c4345208')
    return x6a29f0e4df3e0aa7a1e77598(core, operation, data, session, actor, trace)

def x6a29f0e4df3e0aa7a1e77598(core, operation, data, session, actor, trace):
    trace.append('x6a29f0e4df3e0aa7a1e77598')
    return x30ac86f1b0c30ec9f130203e(core, operation, data, session, actor, trace)

def x30ac86f1b0c30ec9f130203e(core, operation, data, session, actor, trace):
    trace.append('x30ac86f1b0c30ec9f130203e')
    return core.execute(operation, data, session, actor)

def xe464de6e5a77fec63cbfe7b3(core, operation, data, session, actor, trace):
    trace.append('xe464de6e5a77fec63cbfe7b3')
    return xb63eed882a30178f7af93c94(core, operation, data, session, actor, trace)

def xb63eed882a30178f7af93c94(core, operation, data, session, actor, trace):
    trace.append('xb63eed882a30178f7af93c94')
    return xc456b386624f5f8047a69def(core, operation, data, session, actor, trace)

def xc456b386624f5f8047a69def(core, operation, data, session, actor, trace):
    trace.append('xc456b386624f5f8047a69def')
    return x2e930329f9ee4cdc64b0fba0(core, operation, data, session, actor, trace)

def x2e930329f9ee4cdc64b0fba0(core, operation, data, session, actor, trace):
    trace.append('x2e930329f9ee4cdc64b0fba0')
    return core.execute(operation, data, session, actor)

def x6fca747f1425a47ad3861b77(core, operation, data, session, actor, trace):
    trace.append('x6fca747f1425a47ad3861b77')
    return x4015f9bb9b4847b1a747e5f2(core, operation, data, session, actor, trace)

def x4015f9bb9b4847b1a747e5f2(core, operation, data, session, actor, trace):
    trace.append('x4015f9bb9b4847b1a747e5f2')
    return x08979880bd913097b8b2cba6(core, operation, data, session, actor, trace)

def x08979880bd913097b8b2cba6(core, operation, data, session, actor, trace):
    trace.append('x08979880bd913097b8b2cba6')
    return x09903c1c98c943a41aae60d7(core, operation, data, session, actor, trace)

def x09903c1c98c943a41aae60d7(core, operation, data, session, actor, trace):
    trace.append('x09903c1c98c943a41aae60d7')
    return core.execute(operation, data, session, actor)

def x4b7789d4fc6fd103cb1609f6(core, operation, data, session, actor, trace):
    trace.append('x4b7789d4fc6fd103cb1609f6')
    return xd29dfb02d31e55002ce038cf(core, operation, data, session, actor, trace)

def xd29dfb02d31e55002ce038cf(core, operation, data, session, actor, trace):
    trace.append('xd29dfb02d31e55002ce038cf')
    return xa695a2ce857012ae7a8becaa(core, operation, data, session, actor, trace)

def xa695a2ce857012ae7a8becaa(core, operation, data, session, actor, trace):
    trace.append('xa695a2ce857012ae7a8becaa')
    return xb124d4435dd31acabcaa51ff(core, operation, data, session, actor, trace)

def xb124d4435dd31acabcaa51ff(core, operation, data, session, actor, trace):
    trace.append('xb124d4435dd31acabcaa51ff')
    return core.execute(operation, data, session, actor)

def x425f2e98d419f472752530bd(core, operation, data, session, actor, trace):
    trace.append('x425f2e98d419f472752530bd')
    return xdfab6f38d994ef1894d7741c(core, operation, data, session, actor, trace)

def xdfab6f38d994ef1894d7741c(core, operation, data, session, actor, trace):
    trace.append('xdfab6f38d994ef1894d7741c')
    return x3cf2eba424021f5376cbd772(core, operation, data, session, actor, trace)

def x3cf2eba424021f5376cbd772(core, operation, data, session, actor, trace):
    trace.append('x3cf2eba424021f5376cbd772')
    return core.execute(operation, data, session, actor)

def x12dca9dc39b7b91406a6ca2f(core, operation, data, session, actor, trace):
    trace.append('x12dca9dc39b7b91406a6ca2f')
    return xfcbb4729a6f99a5011b8068f(core, operation, data, session, actor, trace)

def xfcbb4729a6f99a5011b8068f(core, operation, data, session, actor, trace):
    trace.append('xfcbb4729a6f99a5011b8068f')
    return x396acc678077c310af56ff94(core, operation, data, session, actor, trace)

def x396acc678077c310af56ff94(core, operation, data, session, actor, trace):
    trace.append('x396acc678077c310af56ff94')
    return x4781a51f3c2c1186ba34c9f5(core, operation, data, session, actor, trace)

def x4781a51f3c2c1186ba34c9f5(core, operation, data, session, actor, trace):
    trace.append('x4781a51f3c2c1186ba34c9f5')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def adapter_index():
    bindings = (
        ('xa16ba6a31b995021a94b613b', xa16ba6a31b995021a94b613b),
        ('x4874184d343e2f55f804d26b', x4874184d343e2f55f804d26b),
        ('xe464de6e5a77fec63cbfe7b3', xe464de6e5a77fec63cbfe7b3),
        ('x6fca747f1425a47ad3861b77', x6fca747f1425a47ad3861b77),
        ('x4b7789d4fc6fd103cb1609f6', x4b7789d4fc6fd103cb1609f6),
        ('x425f2e98d419f472752530bd', x425f2e98d419f472752530bd),
        ('x12dca9dc39b7b91406a6ca2f', x12dca9dc39b7b91406a6ca2f)
    )
    root = {}
    for name, function in bindings:
        branch = root
        for character in name:
            if character not in branch:
                branch[character] = {}
            branch = branch[character]
        branch[None] = function
    return root

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    branch = adapter_index()
    for character in handler_name:
        branch = branch[character]
    trace = []
    status, result, cookie = branch[None](core, operation, data, session, actor, trace)
    return status, result, cookie, trace

