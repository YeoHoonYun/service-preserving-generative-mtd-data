import {send} from './x361cd73eede6f8d1044219c7.js';
export async function x7059682956d36978fab192c9(data,csrf){const wire=[data["password"],data["username"]];const value=await send("/x3d1b09f2ed22b4cf33f7d3d4",wire,csrf);return value[0];}
export async function x739abd100fa6fed164fdf4b4(data,csrf){const wire={"x551c2cefa9a34f112f9f7821":data["order_id"]};const value=await send("/xc19fa57d54d9617873686f80",wire,csrf);return value[0];}
