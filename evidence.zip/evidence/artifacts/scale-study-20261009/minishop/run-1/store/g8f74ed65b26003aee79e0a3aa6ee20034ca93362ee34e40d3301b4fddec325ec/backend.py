# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x3d1b09f2ed22b4cf33f7d3d4', 'fields': ['password', 'username'], 'aliases': {'password': 'xda7f839041d18eba3810b8a3', 'username': 'xe4cd79065e245a80e3632379'}, 'request_shape': 'positional', 'response_shape': 'array', 'request_box': 'x67e7bb0c7e3a18e4bb5456a5', 'response_box': 'x973a0c96ff61aadf968a5109', 'result_key': 'x57100874fed31ee1937052c9'}, 'logout': {'route': '/x012eb5c7244f57c6ac343b37', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'x380273e426959cb9364fa4c3', 'response_box': 'xef576f9009240bc0126f98f5', 'result_key': 'xf925a6f05e596bee2de4d310'}, 'catalog': {'route': '/x7843567d7b842d355f58858e', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'object', 'request_box': 'x7fcb9ad925362f3741d0cb2d', 'response_box': 'x6fde3c62427de17a1fd1fce4', 'result_key': 'xa7b9b061447db8871cb4e9a8'}, 'create_order': {'route': '/x759ff688f23921560d2d2a28', 'fields': ['request_id', 'quantity', 'product_id'], 'aliases': {'request_id': 'xd24f58612b683ffae71401fc', 'quantity': 'x78018211bcf24f3846dc8db0', 'product_id': 'x43d279427b41543f1f1b7cab'}, 'request_shape': 'positional', 'response_shape': 'wrapped', 'request_box': 'x47fd67205226388dba416da2', 'response_box': 'xf86b6c57cf3ad4127acc1300', 'result_key': 'xa8f2fab42b7222c71ffb931a'}, 'order': {'route': '/xc19fa57d54d9617873686f80', 'fields': ['order_id'], 'aliases': {'order_id': 'x551c2cefa9a34f112f9f7821'}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'x8254db6cabe0ebc7d755696a', 'response_box': 'xb27bb28f9e5b6420bd2d7d37', 'result_key': 'xd9cc83f045776a23481b6596'}, 'orders': {'route': '/x4dbe8cf1cc66a8a501f37d17', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'array', 'request_box': 'x743712b0b6fb6005fa58cdd4', 'response_box': 'xe3e12e548c82571d852a20f0', 'result_key': 'x2fe1cbe6665a835827913eab'}, 'update_product': {'route': '/x1cdd49f8e2153757fd10045c', 'fields': ['stock', 'product_id', 'price'], 'aliases': {'stock': 'xed8e4c5688abda9f708f4dab', 'product_id': 'xf976d1c45a68b9d01a55f93e', 'price': 'x9f4e86f80b707b875fdcfe5d'}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'xc479844d27b8010c2ea51c65', 'response_box': 'x5990a934987772f805280026', 'result_key': 'x0b272a8e4438ee237dca46ec'}}
HANDLERS = {'login': 'x3e64d290749909e7d13b3fd9', 'logout': 'xacc37e41736edccaec0e0778', 'catalog': 'x5c84d09d4d8990f3922327a3', 'create_order': 'x84391a1cac2f59ebe2292f7d', 'order': 'x69d4840f14159711083f1ecd', 'orders': 'x6ba1f1768de78b84b132623d', 'update_product': 'xfec77535b4d6b2126abec77c'}
BACKEND_GRAPH = {'x3e64d290749909e7d13b3fd9': {'operation': 'login', 'target': 'x8c79d1f086c675c56d4d8e1f', 'kind': 'adapter'}, 'x8c79d1f086c675c56d4d8e1f': {'operation': 'login', 'target': 'xdbf0a63944f2434bf851a132', 'kind': 'adapter'}, 'xdbf0a63944f2434bf851a132': {'operation': 'login', 'target': 'xe2e2729472dcaf916056bd78', 'kind': 'adapter'}, 'xe2e2729472dcaf916056bd78': {'operation': 'login', 'target': 'x198dda01ba019ecdb3027e65', 'kind': 'adapter'}, 'x198dda01ba019ecdb3027e65': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'xacc37e41736edccaec0e0778': {'operation': 'logout', 'target': 'x7d187db2a5e44bffbd0fc8ab', 'kind': 'adapter'}, 'x7d187db2a5e44bffbd0fc8ab': {'operation': 'logout', 'target': 'x030b87fd31457c32f2d86e91', 'kind': 'adapter'}, 'x030b87fd31457c32f2d86e91': {'operation': 'logout', 'target': 'xc9615c2c2afff62db81f3e5a', 'kind': 'adapter'}, 'xc9615c2c2afff62db81f3e5a': {'operation': 'logout', 'target': 'xdb5cbf8faf6f023c9e0599dc', 'kind': 'adapter'}, 'xdb5cbf8faf6f023c9e0599dc': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x5c84d09d4d8990f3922327a3': {'operation': 'catalog', 'target': 'x04e7d7ffe8ee50201cc7d96f', 'kind': 'adapter'}, 'x04e7d7ffe8ee50201cc7d96f': {'operation': 'catalog', 'target': 'xd245cc2720e82a7c0f09fa7e', 'kind': 'adapter'}, 'xd245cc2720e82a7c0f09fa7e': {'operation': 'catalog', 'target': 'xa95e8d36447ad9c889b20af6', 'kind': 'adapter'}, 'xa95e8d36447ad9c889b20af6': {'operation': 'catalog', 'target': 'xe8c595da58b996fd8b3147fc', 'kind': 'adapter'}, 'xe8c595da58b996fd8b3147fc': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x84391a1cac2f59ebe2292f7d': {'operation': 'create_order', 'target': 'xfaf6f24bfc34d4b79e4f1383', 'kind': 'adapter'}, 'xfaf6f24bfc34d4b79e4f1383': {'operation': 'create_order', 'target': 'x6d5b64fddfecd91f89d33dd2', 'kind': 'adapter'}, 'x6d5b64fddfecd91f89d33dd2': {'operation': 'create_order', 'target': 'xdda85b8f27fd6cbbabbc4fd3', 'kind': 'adapter'}, 'xdda85b8f27fd6cbbabbc4fd3': {'operation': 'create_order', 'target': 'xb075a124cefa225d59e4eafe', 'kind': 'adapter'}, 'xb075a124cefa225d59e4eafe': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x69d4840f14159711083f1ecd': {'operation': 'order', 'target': 'x22423d072d603b1b0b7c7e1b', 'kind': 'adapter'}, 'x22423d072d603b1b0b7c7e1b': {'operation': 'order', 'target': 'x18ea88942c4e457508d43908', 'kind': 'adapter'}, 'x18ea88942c4e457508d43908': {'operation': 'order', 'target': 'x1320fdde78de6fdf7c3cbd9f', 'kind': 'adapter'}, 'x1320fdde78de6fdf7c3cbd9f': {'operation': 'order', 'target': 'x29c7d4ac39759374b596e152', 'kind': 'adapter'}, 'x29c7d4ac39759374b596e152': {'operation': 'order', 'target': 'x26ebf17d4e074c407ec9b745', 'kind': 'adapter'}, 'x26ebf17d4e074c407ec9b745': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x6ba1f1768de78b84b132623d': {'operation': 'orders', 'target': 'xacdd89af1480181fbcc0ab6e', 'kind': 'adapter'}, 'xacdd89af1480181fbcc0ab6e': {'operation': 'orders', 'target': 'x31888d49b4a81d991d9a1bfd', 'kind': 'adapter'}, 'x31888d49b4a81d991d9a1bfd': {'operation': 'orders', 'target': 'x34022cc5a9c2066a73d7b788', 'kind': 'adapter'}, 'x34022cc5a9c2066a73d7b788': {'operation': 'orders', 'target': 'xb0f70a940a13c818160f899f', 'kind': 'adapter'}, 'xb0f70a940a13c818160f899f': {'operation': 'orders', 'target': 'x4455a6039fccd072e893bbb7', 'kind': 'adapter'}, 'x4455a6039fccd072e893bbb7': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'xfec77535b4d6b2126abec77c': {'operation': 'update_product', 'target': 'xeeec60ddb14c85be3adc11db', 'kind': 'adapter'}, 'xeeec60ddb14c85be3adc11db': {'operation': 'update_product', 'target': 'x2b98e37f9464080e2b7713d6', 'kind': 'adapter'}, 'x2b98e37f9464080e2b7713d6': {'operation': 'update_product', 'target': 'xd3d1dddbf9ae2f38a222d79a', 'kind': 'adapter'}, 'xd3d1dddbf9ae2f38a222d79a': {'operation': 'update_product', 'target': 'x9258564b8a4a1a96ec743bac', 'kind': 'adapter'}, 'x9258564b8a4a1a96ec743bac': {'operation': 'update_product', 'target': 'xb0909389bc0f77719d742bea', 'kind': 'adapter'}, 'xb0909389bc0f77719d742bea': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def x3e64d290749909e7d13b3fd9(core, operation, data, session, actor, trace):
    trace.append('x3e64d290749909e7d13b3fd9')
    return x8c79d1f086c675c56d4d8e1f(core, operation, data, session, actor, trace)

def x8c79d1f086c675c56d4d8e1f(core, operation, data, session, actor, trace):
    trace.append('x8c79d1f086c675c56d4d8e1f')
    return xdbf0a63944f2434bf851a132(core, operation, data, session, actor, trace)

def xdbf0a63944f2434bf851a132(core, operation, data, session, actor, trace):
    trace.append('xdbf0a63944f2434bf851a132')
    return xe2e2729472dcaf916056bd78(core, operation, data, session, actor, trace)

def xe2e2729472dcaf916056bd78(core, operation, data, session, actor, trace):
    trace.append('xe2e2729472dcaf916056bd78')
    return x198dda01ba019ecdb3027e65(core, operation, data, session, actor, trace)

def x198dda01ba019ecdb3027e65(core, operation, data, session, actor, trace):
    trace.append('x198dda01ba019ecdb3027e65')
    return core.execute(operation, data, session, actor)

def xacc37e41736edccaec0e0778(core, operation, data, session, actor, trace):
    trace.append('xacc37e41736edccaec0e0778')
    return x7d187db2a5e44bffbd0fc8ab(core, operation, data, session, actor, trace)

def x7d187db2a5e44bffbd0fc8ab(core, operation, data, session, actor, trace):
    trace.append('x7d187db2a5e44bffbd0fc8ab')
    return x030b87fd31457c32f2d86e91(core, operation, data, session, actor, trace)

def x030b87fd31457c32f2d86e91(core, operation, data, session, actor, trace):
    trace.append('x030b87fd31457c32f2d86e91')
    return xc9615c2c2afff62db81f3e5a(core, operation, data, session, actor, trace)

def xc9615c2c2afff62db81f3e5a(core, operation, data, session, actor, trace):
    trace.append('xc9615c2c2afff62db81f3e5a')
    return xdb5cbf8faf6f023c9e0599dc(core, operation, data, session, actor, trace)

def xdb5cbf8faf6f023c9e0599dc(core, operation, data, session, actor, trace):
    trace.append('xdb5cbf8faf6f023c9e0599dc')
    return core.execute(operation, data, session, actor)

def x5c84d09d4d8990f3922327a3(core, operation, data, session, actor, trace):
    trace.append('x5c84d09d4d8990f3922327a3')
    return x04e7d7ffe8ee50201cc7d96f(core, operation, data, session, actor, trace)

def x04e7d7ffe8ee50201cc7d96f(core, operation, data, session, actor, trace):
    trace.append('x04e7d7ffe8ee50201cc7d96f')
    return xd245cc2720e82a7c0f09fa7e(core, operation, data, session, actor, trace)

def xd245cc2720e82a7c0f09fa7e(core, operation, data, session, actor, trace):
    trace.append('xd245cc2720e82a7c0f09fa7e')
    return xa95e8d36447ad9c889b20af6(core, operation, data, session, actor, trace)

def xa95e8d36447ad9c889b20af6(core, operation, data, session, actor, trace):
    trace.append('xa95e8d36447ad9c889b20af6')
    return xe8c595da58b996fd8b3147fc(core, operation, data, session, actor, trace)

def xe8c595da58b996fd8b3147fc(core, operation, data, session, actor, trace):
    trace.append('xe8c595da58b996fd8b3147fc')
    return core.execute(operation, data, session, actor)

def x84391a1cac2f59ebe2292f7d(core, operation, data, session, actor, trace):
    trace.append('x84391a1cac2f59ebe2292f7d')
    return xfaf6f24bfc34d4b79e4f1383(core, operation, data, session, actor, trace)

def xfaf6f24bfc34d4b79e4f1383(core, operation, data, session, actor, trace):
    trace.append('xfaf6f24bfc34d4b79e4f1383')
    return x6d5b64fddfecd91f89d33dd2(core, operation, data, session, actor, trace)

def x6d5b64fddfecd91f89d33dd2(core, operation, data, session, actor, trace):
    trace.append('x6d5b64fddfecd91f89d33dd2')
    return xdda85b8f27fd6cbbabbc4fd3(core, operation, data, session, actor, trace)

def xdda85b8f27fd6cbbabbc4fd3(core, operation, data, session, actor, trace):
    trace.append('xdda85b8f27fd6cbbabbc4fd3')
    return xb075a124cefa225d59e4eafe(core, operation, data, session, actor, trace)

def xb075a124cefa225d59e4eafe(core, operation, data, session, actor, trace):
    trace.append('xb075a124cefa225d59e4eafe')
    return core.execute(operation, data, session, actor)

def x69d4840f14159711083f1ecd(core, operation, data, session, actor, trace):
    trace.append('x69d4840f14159711083f1ecd')
    return x22423d072d603b1b0b7c7e1b(core, operation, data, session, actor, trace)

def x22423d072d603b1b0b7c7e1b(core, operation, data, session, actor, trace):
    trace.append('x22423d072d603b1b0b7c7e1b')
    return x18ea88942c4e457508d43908(core, operation, data, session, actor, trace)

def x18ea88942c4e457508d43908(core, operation, data, session, actor, trace):
    trace.append('x18ea88942c4e457508d43908')
    return x1320fdde78de6fdf7c3cbd9f(core, operation, data, session, actor, trace)

def x1320fdde78de6fdf7c3cbd9f(core, operation, data, session, actor, trace):
    trace.append('x1320fdde78de6fdf7c3cbd9f')
    return x29c7d4ac39759374b596e152(core, operation, data, session, actor, trace)

def x29c7d4ac39759374b596e152(core, operation, data, session, actor, trace):
    trace.append('x29c7d4ac39759374b596e152')
    return x26ebf17d4e074c407ec9b745(core, operation, data, session, actor, trace)

def x26ebf17d4e074c407ec9b745(core, operation, data, session, actor, trace):
    trace.append('x26ebf17d4e074c407ec9b745')
    return core.execute(operation, data, session, actor)

def x6ba1f1768de78b84b132623d(core, operation, data, session, actor, trace):
    trace.append('x6ba1f1768de78b84b132623d')
    return xacdd89af1480181fbcc0ab6e(core, operation, data, session, actor, trace)

def xacdd89af1480181fbcc0ab6e(core, operation, data, session, actor, trace):
    trace.append('xacdd89af1480181fbcc0ab6e')
    return x31888d49b4a81d991d9a1bfd(core, operation, data, session, actor, trace)

def x31888d49b4a81d991d9a1bfd(core, operation, data, session, actor, trace):
    trace.append('x31888d49b4a81d991d9a1bfd')
    return x34022cc5a9c2066a73d7b788(core, operation, data, session, actor, trace)

def x34022cc5a9c2066a73d7b788(core, operation, data, session, actor, trace):
    trace.append('x34022cc5a9c2066a73d7b788')
    return xb0f70a940a13c818160f899f(core, operation, data, session, actor, trace)

def xb0f70a940a13c818160f899f(core, operation, data, session, actor, trace):
    trace.append('xb0f70a940a13c818160f899f')
    return x4455a6039fccd072e893bbb7(core, operation, data, session, actor, trace)

def x4455a6039fccd072e893bbb7(core, operation, data, session, actor, trace):
    trace.append('x4455a6039fccd072e893bbb7')
    return core.execute(operation, data, session, actor)

def xfec77535b4d6b2126abec77c(core, operation, data, session, actor, trace):
    trace.append('xfec77535b4d6b2126abec77c')
    return xeeec60ddb14c85be3adc11db(core, operation, data, session, actor, trace)

def xeeec60ddb14c85be3adc11db(core, operation, data, session, actor, trace):
    trace.append('xeeec60ddb14c85be3adc11db')
    return x2b98e37f9464080e2b7713d6(core, operation, data, session, actor, trace)

def x2b98e37f9464080e2b7713d6(core, operation, data, session, actor, trace):
    trace.append('x2b98e37f9464080e2b7713d6')
    return xd3d1dddbf9ae2f38a222d79a(core, operation, data, session, actor, trace)

def xd3d1dddbf9ae2f38a222d79a(core, operation, data, session, actor, trace):
    trace.append('xd3d1dddbf9ae2f38a222d79a')
    return x9258564b8a4a1a96ec743bac(core, operation, data, session, actor, trace)

def x9258564b8a4a1a96ec743bac(core, operation, data, session, actor, trace):
    trace.append('x9258564b8a4a1a96ec743bac')
    return xb0909389bc0f77719d742bea(core, operation, data, session, actor, trace)

def xb0909389bc0f77719d742bea(core, operation, data, session, actor, trace):
    trace.append('xb0909389bc0f77719d742bea')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def adapter_task(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    entries = {
        'login': x3e64d290749909e7d13b3fd9,
        'logout': xacc37e41736edccaec0e0778,
        'catalog': x5c84d09d4d8990f3922327a3,
        'create_order': x84391a1cac2f59ebe2292f7d,
        'order': x69d4840f14159711083f1ecd,
        'orders': x6ba1f1768de78b84b132623d,
        'update_product': xfec77535b4d6b2126abec77c
    }
    trace = []
    outcome = yield entries[operation], (core, operation, data, session, actor, trace)
    status, result, cookie = outcome
    return status, result, cookie, trace

def invoke(handler_name, core, operation, data, session, actor):
    task = adapter_task(handler_name, core, operation, data, session, actor)
    try:
        target, arguments = next(task)
        outcome = target(*arguments)
        try:
            task.send(outcome)
        except StopIteration as completed:
            return completed.value
    finally:
        task.close()

