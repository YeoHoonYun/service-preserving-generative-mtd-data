GRAPH = {'x71fe52b3b1d87ad6282df331': {'kind': 'router', 'edges': {'/x3d1b09f2ed22b4cf33f7d3d4': {'target': 'x363bd640a139341e70a5f0fc', 'next_key': 'x5186cc22b548aae76048861e'}, '/x012eb5c7244f57c6ac343b37': {'target': 'x363bd640a139341e70a5f0fc', 'next_key': 'x4e05ac4d8762ead825dc3712'}, '/x7843567d7b842d355f58858e': {'target': 'x363bd640a139341e70a5f0fc', 'next_key': 'x0fbe6501d81ab7e1adb55f3c'}, '/x759ff688f23921560d2d2a28': {'target': 'x363bd640a139341e70a5f0fc', 'next_key': 'x149f5841dc94ac3387305abc'}, '/xc19fa57d54d9617873686f80': {'target': 'x363bd640a139341e70a5f0fc', 'next_key': 'x825b81c2879f5738d2f39aa1'}, '/x4dbe8cf1cc66a8a501f37d17': {'target': 'x363bd640a139341e70a5f0fc', 'next_key': 'x88a2f58b09d55b91eef1efac'}, '/x1cdd49f8e2153757fd10045c': {'target': 'x363bd640a139341e70a5f0fc', 'next_key': 'x2f66de611b8299e74833f210'}}}, 'x363bd640a139341e70a5f0fc': {'kind': 'router', 'edges': {'x5186cc22b548aae76048861e': {'target': 'x992596bee5524200e1a3ac2c', 'next_key': 'x91839ceceef3ff564261299e'}, 'x4e05ac4d8762ead825dc3712': {'target': 'x58f977efe4b2dde37ee0c658', 'next_key': 'xe647c254c8e93b7e4bfdbf09'}, 'x0fbe6501d81ab7e1adb55f3c': {'target': 'x992596bee5524200e1a3ac2c', 'next_key': 'xe82ea74ac532d8fd1ea6daac'}, 'x149f5841dc94ac3387305abc': {'target': 'x58f977efe4b2dde37ee0c658', 'next_key': 'x2a899e77d7575844ea35aaac'}, 'x825b81c2879f5738d2f39aa1': {'target': 'x992596bee5524200e1a3ac2c', 'next_key': 'x08f735356296180c8d3fb4b8'}, 'x88a2f58b09d55b91eef1efac': {'target': 'x58f977efe4b2dde37ee0c658', 'next_key': 'xc2f12d78b60cb35ac5751505'}, 'x2f66de611b8299e74833f210': {'target': 'x992596bee5524200e1a3ac2c', 'next_key': 'x1c4504838ed71aeafed9540b'}}}, 'x58f977efe4b2dde37ee0c658': {'kind': 'router', 'edges': {'xe647c254c8e93b7e4bfdbf09': {'target': 'xf7ce1bb88c316ec41eebe631', 'next_key': 'x6fc567006dc06055bdca8737'}, 'x2a899e77d7575844ea35aaac': {'target': 'xf7ce1bb88c316ec41eebe631', 'next_key': 'xfb08a1320fd3fea7a4409577'}, 'xc2f12d78b60cb35ac5751505': {'target': 'xf7ce1bb88c316ec41eebe631', 'next_key': 'x534880d7ce0d75c9a8975697'}}}, 'x992596bee5524200e1a3ac2c': {'kind': 'router', 'edges': {'x91839ceceef3ff564261299e': {'target': 'xefda3ac9a89b0f33868de684', 'next_key': 'x9a087005a69c050cf9587fe4'}, 'xe82ea74ac532d8fd1ea6daac': {'target': 'xefda3ac9a89b0f33868de684', 'next_key': 'x78443e383bfe16519761d9e0'}, 'x08f735356296180c8d3fb4b8': {'target': 'xefda3ac9a89b0f33868de684', 'next_key': 'x2c5b7dc8830566d787f2f86a'}, 'x1c4504838ed71aeafed9540b': {'target': 'xefda3ac9a89b0f33868de684', 'next_key': 'x855869237aaea57ac9f3812f'}}}, 'xefda3ac9a89b0f33868de684': {'kind': 'router', 'edges': {'x9a087005a69c050cf9587fe4': {'target': 'xcef2384c2703e68c13be9f4b', 'next_key': 'x87b3ee2246834efe1c454a06'}, 'x78443e383bfe16519761d9e0': {'target': 'xcef2384c2703e68c13be9f4b', 'next_key': 'x882f45d1f368dc12042df1cc'}, 'x2c5b7dc8830566d787f2f86a': {'target': 'xcef2384c2703e68c13be9f4b', 'next_key': 'x7bc69768cfcea1f90de5abd4'}, 'x855869237aaea57ac9f3812f': {'target': 'xcef2384c2703e68c13be9f4b', 'next_key': 'x14b1b189a96c2d55aa48d771'}}}, 'xf7ce1bb88c316ec41eebe631': {'kind': 'router', 'edges': {'x6fc567006dc06055bdca8737': {'target': 'x54114a1d47a9c7215d7b09d4', 'next_key': 'xa17759fd786b97a7260cc5e1'}, 'xfb08a1320fd3fea7a4409577': {'target': 'x54114a1d47a9c7215d7b09d4', 'next_key': 'xfbeb22bd1c72449557a3a3d2'}, 'x534880d7ce0d75c9a8975697': {'target': 'x54114a1d47a9c7215d7b09d4', 'next_key': 'x4e26eb0eed364df785cc2a87'}}}, 'x54114a1d47a9c7215d7b09d4': {'kind': 'router', 'edges': {'xa17759fd786b97a7260cc5e1': {'target': 'x3e16cbc25c1ca6b1be77c831', 'next_key': None}, 'xfbeb22bd1c72449557a3a3d2': {'target': 'xaeac7e1529c1ae12a3ccc931', 'next_key': None}, 'x4e26eb0eed364df785cc2a87': {'target': 'xed8209e3b94b28e856d31247', 'next_key': None}}}, 'xcef2384c2703e68c13be9f4b': {'kind': 'router', 'edges': {'x87b3ee2246834efe1c454a06': {'target': 'xea0aa4414c68af4bd21c836e', 'next_key': None}, 'x882f45d1f368dc12042df1cc': {'target': 'xad822f0595ef9258e1f29ed7', 'next_key': None}, 'x7bc69768cfcea1f90de5abd4': {'target': 'x6088096b886ca0c8c6bfed2c', 'next_key': None}, 'x14b1b189a96c2d55aa48d771': {'target': 'x2d5252265c0cd8bbea5f90b8', 'next_key': None}}}, 'xea0aa4414c68af4bd21c836e': {'kind': 'service', 'operation': 'login', 'handler': 'x3e64d290749909e7d13b3fd9'}, 'x3e16cbc25c1ca6b1be77c831': {'kind': 'service', 'operation': 'logout', 'handler': 'xacc37e41736edccaec0e0778'}, 'xad822f0595ef9258e1f29ed7': {'kind': 'service', 'operation': 'catalog', 'handler': 'x5c84d09d4d8990f3922327a3'}, 'xaeac7e1529c1ae12a3ccc931': {'kind': 'service', 'operation': 'create_order', 'handler': 'x84391a1cac2f59ebe2292f7d'}, 'x6088096b886ca0c8c6bfed2c': {'kind': 'service', 'operation': 'order', 'handler': 'x69d4840f14159711083f1ecd'}, 'xed8209e3b94b28e856d31247': {'kind': 'service', 'operation': 'orders', 'handler': 'x6ba1f1768de78b84b132623d'}, 'x2d5252265c0cd8bbea5f90b8': {'kind': 'service', 'operation': 'update_product', 'handler': 'xfec77535b4d6b2126abec77c'}}
ENTRY = 'x71fe52b3b1d87ad6282df331'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def build_route_interval(result, bindings, start, stop):
    name = 'route_interval_' + str(start) + '_' + str(stop)
    edges = {}
    result[name] = {'kind': 'router', 'edges': edges}
    if stop - start <= 2:
        for index in range(start, stop):
            path, leaf = bindings[index]
            edges[path] = {'target': leaf, 'next_key': None}
    else:
        middle = (start + stop) // 2
        left = build_route_interval(result, bindings, start, middle)
        right = build_route_interval(result, bindings, middle, stop)
        for index in range(start, stop):
            path, leaf = bindings[index]
            edges[path] = {'target': left if index < middle else right, 'next_key': path}
    return name

def rewrite_graph(graph, entry):
    result = {}
    bindings = []
    leaves = {}
    for path in sorted(graph[entry]['edges']):
        node, key = entry, path
        seen = set()
        while graph[node]['kind'] != 'service':
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        if node not in leaves:
            leaf = 'route_service_' + str(len(leaves))
            leaves[node] = leaf
            result[leaf] = dict(graph[node])
        bindings.append((path, leaves[node]))
    root = build_route_interval(result, bindings, 0, len(bindings))
    return result, root

def resolve(path):
    current, key = ENTRY, path
    visited = set()
    trace = []
    while current not in visited:
        visited.add(current)
        trace.append(current)
        item = GRAPH[current]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        current, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
