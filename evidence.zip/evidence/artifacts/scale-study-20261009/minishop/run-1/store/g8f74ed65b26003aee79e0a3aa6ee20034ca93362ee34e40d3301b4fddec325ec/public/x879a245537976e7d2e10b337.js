import {send} from './x361cd73eede6f8d1044219c7.js';
export async function x955318a806467c13ae24b9b6(data,csrf){const wire={};const value=await send("/x012eb5c7244f57c6ac343b37",wire,csrf);return value["xef576f9009240bc0126f98f5"]["xf925a6f05e596bee2de4d310"];}
export async function xb34ab1aa3ea64abce1cddd18(data,csrf){const wire=[];const value=await send("/x4dbe8cf1cc66a8a501f37d17",wire,csrf);return value[0];}
