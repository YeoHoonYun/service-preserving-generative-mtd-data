import {send} from './x361cd73eede6f8d1044219c7.js';
export async function x153410b9db397a40cc37ea1f(data,csrf){const wire=[data["request_id"],data["quantity"],data["product_id"]];const value=await send("/x759ff688f23921560d2d2a28",wire,csrf);return value["xf86b6c57cf3ad4127acc1300"]["xa8f2fab42b7222c71ffb931a"];}
