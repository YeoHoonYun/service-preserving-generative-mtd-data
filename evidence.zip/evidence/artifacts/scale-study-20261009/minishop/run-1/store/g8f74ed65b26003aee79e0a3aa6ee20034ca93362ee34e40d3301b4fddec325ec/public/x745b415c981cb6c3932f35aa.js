import {x7059682956d36978fab192c9,x739abd100fa6fed164fdf4b4} from './xd007e744568568a91f85e15a.js';
import {x955318a806467c13ae24b9b6,xb34ab1aa3ea64abce1cddd18} from './x879a245537976e7d2e10b337.js';
import {xa3ec269e6e296a929bef8115,xda2df6d760f990e259f1ef56} from './x61bed4e746766bf49f1ca75b.js';
import {x153410b9db397a40cc37ea1f} from './xb4b1a9d0ada85bf493907224.js';

function mountShop(){
  let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
  const message=document.getElementById('x78bb87828c84578ac6dd0eb7');
  const endpoints={login:x7059682956d36978fab192c9,logout:x955318a806467c13ae24b9b6,catalog:xa3ec269e6e296a929bef8115,create_order:x153410b9db397a40cc37ea1f,order:x739abd100fa6fed164fdf4b4,orders:xb34ab1aa3ea64abce1cddd18,update_product:xda2df6d760f990e259f1ef56};
  async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
  function identity(){document.getElementById('x0afb6d65e5741e1e12095b18').textContent=boot.user?boot.user.id:'방문자';}
  function run(promise){promise.catch(error=>message.textContent=error.message);}
  async function catalog(){
    const list=document.getElementById('xcf829ffd7fb89de4e63a642e');
    list.replaceChildren();
    for(const p of await api('catalog')){
      const li=document.createElement('li');
      li.textContent=p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock;
      list.append(li);
    }
    document.body.dataset.ready='yes';
  }
  async function orders(){
    const list=document.getElementById('x5667d91a48fc5c7f0365c4de');
    list.replaceChildren();
    for(const order of await api('orders')){
      const li=document.createElement('li');
      li.textContent=order.id+' · '+order.total+'원';
      list.append(li);
    }
  }
  const commands=new Map([
    ['x9ac21cdcc4f1c7ee7d378af7',{
      operation:'login',
      prepare:data=>data,
      complete:result=>{
        boot=result;
        identity();
        message.textContent='로그인되었습니다.';
      }
    }],
    ['x3320e632067e608173761750',{
      operation:'create_order',
      prepare:data=>({product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()}),
      complete:async order=>{
        message.textContent='주문 '+order.id+' · '+order.total+'원';
        await catalog();
        await orders();
      }
    }],
    ['xcbe1713f8aadc2fc224c2037',{
      operation:'update_product',
      prepare:data=>({product_id:'p1',price:Number(data.price),stock:Number(data.stock)}),
      complete:async()=>{
        message.textContent='상품을 수정했습니다.';
        await catalog();
      }
    }]
  ]);
  async function submit(form){
    const raw=Object.fromEntries(new FormData(form));
    const data={username:raw['x970aa48b00cac2edf9445c88'],password:raw['xd86c6401fdffa0bde9c76e15'],product_id:raw['xd905ef6d7c5e04eb463689dd'],quantity:raw['x2de37caec3e3cbd72b4f8556'],price:raw['x9f1f09174ca81b791566b81f'],stock:raw['x63c6d785d3d650df81e9da36']};
    for(const [action,command] of commands){
      if(form.dataset.action===action){
        const result=await api(command.operation,command.prepare(data));
        const completion=command.complete(result);
        if(completion) await completion;
      }
    }
  }
  document.addEventListener('submit',event=>{
    event.preventDefault();
    run(submit(event.target));
  });
  const clicks=[
    ['x70367cfe78b3c0357a86c947',()=>api('logout').then(()=>location.reload())],
    ['x08dfb1d8bb069222343c0e74',orders]
  ];
  for(const [id,action] of clicks){document.getElementById(id).onclick=()=>run(action());}
  identity();
  run(catalog());
}
mountShop();
