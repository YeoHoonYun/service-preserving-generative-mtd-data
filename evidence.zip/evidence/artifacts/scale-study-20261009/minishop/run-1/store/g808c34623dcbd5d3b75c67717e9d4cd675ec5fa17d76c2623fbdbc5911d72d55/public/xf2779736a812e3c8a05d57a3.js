import {send} from './x874f292b6b1a53bcb6262a24.js';
export async function xbd50d53bd399f80d1609f112(data,csrf){const wire={};const value=await send("/xd83dbf5481e2123486705aff",wire,csrf);return value["xd17f2f305402b4abeeac84b3"]["xbd6c13f2d5e8ada101f8ecee"];}
export async function xcb8ad058e7b7770d1dd7cc6b(data,csrf){const wire={"xef5f162ba8a3dc488c474ac3":{}};const value=await send("/xf593ef84a8cd74779bd7c098",wire,csrf);return value["x386308e35442f54836ff2c2b"];}
