import {send} from './x874f292b6b1a53bcb6262a24.js';
export async function x8b6a4209657085da4bc7fc18(data,csrf){const wire={};const value=await send("/x277f5ba00a7c75539a67cbb4",wire,csrf);return value[0];}
export async function x018d74f0a1a0703ef75c96c8(data,csrf){const wire=[data["order_id"]];const value=await send("/xf08b412d84e340a46ccbecfa",wire,csrf);return value["x6eb9b99c1c4ef4f7967160de"]["x0397395970ae4e3bc3651570"];}
