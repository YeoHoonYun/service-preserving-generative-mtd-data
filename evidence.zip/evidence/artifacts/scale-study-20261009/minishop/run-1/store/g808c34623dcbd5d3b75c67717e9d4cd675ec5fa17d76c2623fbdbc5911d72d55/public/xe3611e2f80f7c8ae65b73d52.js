import {xeb10c7965433899b89f6e2cd,x48a8b5a11961b9fd3c1d0a02,x10b50a34a981226bdbe060bf} from './xc331428ad1475373826fc832.js';
import {x8b6a4209657085da4bc7fc18,x018d74f0a1a0703ef75c96c8} from './x3bb85bb4f8842898a79a174f.js';
import {xbd50d53bd399f80d1609f112,xcb8ad058e7b7770d1dd7cc6b} from './xf2779736a812e3c8a05d57a3.js';

let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('x2af837d23c24e84f96f71b31');
const endpoints={login:xeb10c7965433899b89f6e2cd,logout:x8b6a4209657085da4bc7fc18,catalog:xbd50d53bd399f80d1609f112,create_order:x48a8b5a11961b9fd3c1d0a02,order:x018d74f0a1a0703ef75c96c8,orders:xcb8ad058e7b7770d1dd7cc6b,update_product:x10b50a34a981226bdbe060bf};
const lists={
  catalog:{id:'x37cca1cfb7c3d446cb7b643d',text:p=>p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock},
  orders:{id:'x42544c35bdd6d13512ccdcaa',text:order=>order.id+' · '+order.total+'원'}
};
function identity(){
  document.getElementById('x5d7ec96d31d4b5b4fa098034').textContent=boot.user?boot.user.id:'방문자';
}
async function api(operation,data={}){
  return endpoints[operation](data,boot.csrf);
}
async function refresh(operation){
  const view=lists[operation];
  const list=document.getElementById(view.id);
  list.replaceChildren();
  return api(operation).then(rows=>{
    for(const row of rows){
      const li=document.createElement('li');
      li.textContent=view.text(row);
      list.append(li);
    }
    if(operation==='catalog') document.body.dataset.ready='yes';
  });
}
function run(promise){
  promise.catch(error=>message.textContent=error.message);
}
function makeCommands(data){
  return {
    login:()=>api('login',data).then(result=>{
      boot=result;
      identity();
      message.textContent='로그인되었습니다.';
    }),
    purchase:()=>api('create_order',{
      product_id:data.product_id,
      quantity:Number(data.quantity),
      request_id:crypto.randomUUID()
    }).then(order=>{
      message.textContent='주문 '+order.id+' · '+order.total+'원';
      return refresh('catalog');
    }).then(()=>refresh('orders')),
    edit:()=>api('update_product',{
      product_id:'p1',price:Number(data.price),stock:Number(data.stock)
    }).then(()=>{
      message.textContent='상품을 수정했습니다.';
      return refresh('catalog');
    })
  };
}
async function submitForm(form){
  const raw=Object.fromEntries(new FormData(form));
  const commands=makeCommands({
    username:raw['xed65d94e7972ba3560db76b3'],
    password:raw['x2bad77d83ea69d332f6ae44b'],
    product_id:raw['x36c9f66a38563036d2a010b9'],
    quantity:raw['x67db16d17b1b47ecc70327d8'],
    price:raw['x3609100239fb38f97f498e7f'],
    stock:raw['xb0719a1c3439e48fd3d07fb6']
  });
  if(form.dataset.action==='xc717fc5ff7bde8179b8650c1') await commands.login();
  if(form.dataset.action==='x4ecbf5bac17aa275746a0665') await commands.purchase();
  if(form.dataset.action==='xe5f32bb165ab5cf9f6ed20a2') await commands.edit();
}
function onSubmit(event){
  event.preventDefault();
  run(submitForm(event.target));
}
document.addEventListener('submit',onSubmit);
document.getElementById('xa00798a3c51b03c9927b4814').onclick=()=>run(api('logout').then(()=>location.reload()));
document.getElementById('x38e823c1741912850f6ac3f0').onclick=()=>run(refresh('orders'));
identity();
run(refresh('catalog'));
