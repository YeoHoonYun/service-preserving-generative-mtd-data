# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/xa12422664d4a1da0d978976d', 'fields': ['username', 'password'], 'aliases': {'username': 'x0b3e77746fe5403a13557072', 'password': 'x1cc02366ef8658b8f74c7e32'}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'x5ab945dbc1a02ab3ea4ad5c2', 'response_box': 'x0f732f61b0dd21ac2d71dce2', 'result_key': 'x0bda8579b4ca4fbcd4c4bddc'}, 'logout': {'route': '/x277f5ba00a7c75539a67cbb4', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'x51ee5530a66559873d48d563', 'response_box': 'xeddbd94f729c0ade3514cece', 'result_key': 'xf834dca0049cb2e1f428e827'}, 'catalog': {'route': '/xd83dbf5481e2123486705aff', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'x5bbb7523fea99a86b0c18912', 'response_box': 'xd17f2f305402b4abeeac84b3', 'result_key': 'xbd6c13f2d5e8ada101f8ecee'}, 'create_order': {'route': '/x338320636e1422ee86720bea', 'fields': ['quantity', 'request_id', 'product_id'], 'aliases': {'quantity': 'x8ea5e416430d7b3f555a5748', 'request_id': 'x2bc4fdcbe564d10b3dcbd58f', 'product_id': 'x4a13673676a300e5adb484e2'}, 'request_shape': 'pairs', 'response_shape': 'wrapped', 'request_box': 'x505c50b5f3e90967886501fe', 'response_box': 'x0e4e220d4c319615d433b170', 'result_key': 'xc992e7f19dc4a45c2ebd028f'}, 'order': {'route': '/xf08b412d84e340a46ccbecfa', 'fields': ['order_id'], 'aliases': {'order_id': 'x995e13742126dcfe7bab41b0'}, 'request_shape': 'positional', 'response_shape': 'wrapped', 'request_box': 'x1704ec407b45f94bfe39fce2', 'response_box': 'x6eb9b99c1c4ef4f7967160de', 'result_key': 'x0397395970ae4e3bc3651570'}, 'orders': {'route': '/xf593ef84a8cd74779bd7c098', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'object', 'request_box': 'xef5f162ba8a3dc488c474ac3', 'response_box': 'xe593f7c84cc092a26824316b', 'result_key': 'x386308e35442f54836ff2c2b'}, 'update_product': {'route': '/x07985ed7f9161a79412ae31f', 'fields': ['stock', 'product_id', 'price'], 'aliases': {'stock': 'xed94728b380b0df913d84d95', 'product_id': 'x2289ffa92862c65304c25d17', 'price': 'x74f64365e24e6111ff5d8947'}, 'request_shape': 'positional', 'response_shape': 'array', 'request_box': 'x2d6f2719598f818c34c3eec8', 'response_box': 'xac5584795267e1cbd9f65fd8', 'result_key': 'xc4d3b2c811cb02c1fb3d2e90'}}
HANDLERS = {'login': 'x9470fe9ca0c81e2a2cd891d6', 'logout': 'x61e4f9cb7f3b38f08cbb285b', 'catalog': 'x6649ab85e2f3296bbfb2cef6', 'create_order': 'x25068b5938e5f1e466abce5a', 'order': 'x094f73b0dbe292c4d43352dc', 'orders': 'x740575e1fd98c1552b10902b', 'update_product': 'xdc7e16c666b4116b6e3e0859'}
BACKEND_GRAPH = {'x9470fe9ca0c81e2a2cd891d6': {'operation': 'login', 'target': 'xfae732481dcd9407b9907388', 'kind': 'adapter'}, 'xfae732481dcd9407b9907388': {'operation': 'login', 'target': 'x3fe392d79aafffbc2224a0a0', 'kind': 'adapter'}, 'x3fe392d79aafffbc2224a0a0': {'operation': 'login', 'target': 'x5fd953fe27e2b2e66e3e8038', 'kind': 'adapter'}, 'x5fd953fe27e2b2e66e3e8038': {'operation': 'login', 'target': 'x5b797aeb597a77ab754fb7bb', 'kind': 'adapter'}, 'x5b797aeb597a77ab754fb7bb': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x61e4f9cb7f3b38f08cbb285b': {'operation': 'logout', 'target': 'xdfaea5c670b9724c2e532655', 'kind': 'adapter'}, 'xdfaea5c670b9724c2e532655': {'operation': 'logout', 'target': 'xa725e1447c16ff817e986c53', 'kind': 'adapter'}, 'xa725e1447c16ff817e986c53': {'operation': 'logout', 'target': 'xb00e6288daaf62eed054177a', 'kind': 'adapter'}, 'xb00e6288daaf62eed054177a': {'operation': 'logout', 'target': 'x9e374b290845d17f761f399b', 'kind': 'adapter'}, 'x9e374b290845d17f761f399b': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x6649ab85e2f3296bbfb2cef6': {'operation': 'catalog', 'target': 'x775e1b21d5d2e1db2ef922d5', 'kind': 'adapter'}, 'x775e1b21d5d2e1db2ef922d5': {'operation': 'catalog', 'target': 'x448b3ff142e50564fe821e43', 'kind': 'adapter'}, 'x448b3ff142e50564fe821e43': {'operation': 'catalog', 'target': 'xacf6f20eae888203a5dfe835', 'kind': 'adapter'}, 'xacf6f20eae888203a5dfe835': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x25068b5938e5f1e466abce5a': {'operation': 'create_order', 'target': 'x62af50ec53fc26c881a7b73f', 'kind': 'adapter'}, 'x62af50ec53fc26c881a7b73f': {'operation': 'create_order', 'target': 'x16298b7f6219d81a8fe112c3', 'kind': 'adapter'}, 'x16298b7f6219d81a8fe112c3': {'operation': 'create_order', 'target': 'x813f77075890cdfcc9034369', 'kind': 'adapter'}, 'x813f77075890cdfcc9034369': {'operation': 'create_order', 'target': 'x2fd80957a164dfbedbfa09aa', 'kind': 'adapter'}, 'x2fd80957a164dfbedbfa09aa': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x094f73b0dbe292c4d43352dc': {'operation': 'order', 'target': 'x573f544eceb1d731ab9b2bfa', 'kind': 'adapter'}, 'x573f544eceb1d731ab9b2bfa': {'operation': 'order', 'target': 'xfe10c02d8160a5461d4a00d0', 'kind': 'adapter'}, 'xfe10c02d8160a5461d4a00d0': {'operation': 'order', 'target': 'xf06e3af524f38acba1c7bec7', 'kind': 'adapter'}, 'xf06e3af524f38acba1c7bec7': {'operation': 'order', 'target': 'x6a7b4cbc5cbf5f35c30e9c51', 'kind': 'adapter'}, 'x6a7b4cbc5cbf5f35c30e9c51': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x740575e1fd98c1552b10902b': {'operation': 'orders', 'target': 'x476aa49c88f4692e1f44babc', 'kind': 'adapter'}, 'x476aa49c88f4692e1f44babc': {'operation': 'orders', 'target': 'xaec274efc470d74cdfd6a015', 'kind': 'adapter'}, 'xaec274efc470d74cdfd6a015': {'operation': 'orders', 'target': 'xe5bf58e55e2dde5f673180a8', 'kind': 'adapter'}, 'xe5bf58e55e2dde5f673180a8': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'xdc7e16c666b4116b6e3e0859': {'operation': 'update_product', 'target': 'x2dd0d81db1e62efd98e04a7a', 'kind': 'adapter'}, 'x2dd0d81db1e62efd98e04a7a': {'operation': 'update_product', 'target': 'xcdbbc8a4961ec32ac79ce3e5', 'kind': 'adapter'}, 'xcdbbc8a4961ec32ac79ce3e5': {'operation': 'update_product', 'target': 'xa910bcfaadb23e5479b0640e', 'kind': 'adapter'}, 'xa910bcfaadb23e5479b0640e': {'operation': 'update_product', 'target': 'x249411d4ae68d7b05c9e4fd9', 'kind': 'adapter'}, 'x249411d4ae68d7b05c9e4fd9': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def x9470fe9ca0c81e2a2cd891d6(core, operation, data, session, actor, trace):
    trace.append('x9470fe9ca0c81e2a2cd891d6')
    return xfae732481dcd9407b9907388(core, operation, data, session, actor, trace)

def xfae732481dcd9407b9907388(core, operation, data, session, actor, trace):
    trace.append('xfae732481dcd9407b9907388')
    return x3fe392d79aafffbc2224a0a0(core, operation, data, session, actor, trace)

def x3fe392d79aafffbc2224a0a0(core, operation, data, session, actor, trace):
    trace.append('x3fe392d79aafffbc2224a0a0')
    return x5fd953fe27e2b2e66e3e8038(core, operation, data, session, actor, trace)

def x5fd953fe27e2b2e66e3e8038(core, operation, data, session, actor, trace):
    trace.append('x5fd953fe27e2b2e66e3e8038')
    return x5b797aeb597a77ab754fb7bb(core, operation, data, session, actor, trace)

def x5b797aeb597a77ab754fb7bb(core, operation, data, session, actor, trace):
    trace.append('x5b797aeb597a77ab754fb7bb')
    return core.execute(operation, data, session, actor)

def x61e4f9cb7f3b38f08cbb285b(core, operation, data, session, actor, trace):
    trace.append('x61e4f9cb7f3b38f08cbb285b')
    return xdfaea5c670b9724c2e532655(core, operation, data, session, actor, trace)

def xdfaea5c670b9724c2e532655(core, operation, data, session, actor, trace):
    trace.append('xdfaea5c670b9724c2e532655')
    return xa725e1447c16ff817e986c53(core, operation, data, session, actor, trace)

def xa725e1447c16ff817e986c53(core, operation, data, session, actor, trace):
    trace.append('xa725e1447c16ff817e986c53')
    return xb00e6288daaf62eed054177a(core, operation, data, session, actor, trace)

def xb00e6288daaf62eed054177a(core, operation, data, session, actor, trace):
    trace.append('xb00e6288daaf62eed054177a')
    return x9e374b290845d17f761f399b(core, operation, data, session, actor, trace)

def x9e374b290845d17f761f399b(core, operation, data, session, actor, trace):
    trace.append('x9e374b290845d17f761f399b')
    return core.execute(operation, data, session, actor)

def x6649ab85e2f3296bbfb2cef6(core, operation, data, session, actor, trace):
    trace.append('x6649ab85e2f3296bbfb2cef6')
    return x775e1b21d5d2e1db2ef922d5(core, operation, data, session, actor, trace)

def x775e1b21d5d2e1db2ef922d5(core, operation, data, session, actor, trace):
    trace.append('x775e1b21d5d2e1db2ef922d5')
    return x448b3ff142e50564fe821e43(core, operation, data, session, actor, trace)

def x448b3ff142e50564fe821e43(core, operation, data, session, actor, trace):
    trace.append('x448b3ff142e50564fe821e43')
    return xacf6f20eae888203a5dfe835(core, operation, data, session, actor, trace)

def xacf6f20eae888203a5dfe835(core, operation, data, session, actor, trace):
    trace.append('xacf6f20eae888203a5dfe835')
    return core.execute(operation, data, session, actor)

def x25068b5938e5f1e466abce5a(core, operation, data, session, actor, trace):
    trace.append('x25068b5938e5f1e466abce5a')
    return x62af50ec53fc26c881a7b73f(core, operation, data, session, actor, trace)

def x62af50ec53fc26c881a7b73f(core, operation, data, session, actor, trace):
    trace.append('x62af50ec53fc26c881a7b73f')
    return x16298b7f6219d81a8fe112c3(core, operation, data, session, actor, trace)

def x16298b7f6219d81a8fe112c3(core, operation, data, session, actor, trace):
    trace.append('x16298b7f6219d81a8fe112c3')
    return x813f77075890cdfcc9034369(core, operation, data, session, actor, trace)

def x813f77075890cdfcc9034369(core, operation, data, session, actor, trace):
    trace.append('x813f77075890cdfcc9034369')
    return x2fd80957a164dfbedbfa09aa(core, operation, data, session, actor, trace)

def x2fd80957a164dfbedbfa09aa(core, operation, data, session, actor, trace):
    trace.append('x2fd80957a164dfbedbfa09aa')
    return core.execute(operation, data, session, actor)

def x094f73b0dbe292c4d43352dc(core, operation, data, session, actor, trace):
    trace.append('x094f73b0dbe292c4d43352dc')
    return x573f544eceb1d731ab9b2bfa(core, operation, data, session, actor, trace)

def x573f544eceb1d731ab9b2bfa(core, operation, data, session, actor, trace):
    trace.append('x573f544eceb1d731ab9b2bfa')
    return xfe10c02d8160a5461d4a00d0(core, operation, data, session, actor, trace)

def xfe10c02d8160a5461d4a00d0(core, operation, data, session, actor, trace):
    trace.append('xfe10c02d8160a5461d4a00d0')
    return xf06e3af524f38acba1c7bec7(core, operation, data, session, actor, trace)

def xf06e3af524f38acba1c7bec7(core, operation, data, session, actor, trace):
    trace.append('xf06e3af524f38acba1c7bec7')
    return x6a7b4cbc5cbf5f35c30e9c51(core, operation, data, session, actor, trace)

def x6a7b4cbc5cbf5f35c30e9c51(core, operation, data, session, actor, trace):
    trace.append('x6a7b4cbc5cbf5f35c30e9c51')
    return core.execute(operation, data, session, actor)

def x740575e1fd98c1552b10902b(core, operation, data, session, actor, trace):
    trace.append('x740575e1fd98c1552b10902b')
    return x476aa49c88f4692e1f44babc(core, operation, data, session, actor, trace)

def x476aa49c88f4692e1f44babc(core, operation, data, session, actor, trace):
    trace.append('x476aa49c88f4692e1f44babc')
    return xaec274efc470d74cdfd6a015(core, operation, data, session, actor, trace)

def xaec274efc470d74cdfd6a015(core, operation, data, session, actor, trace):
    trace.append('xaec274efc470d74cdfd6a015')
    return xe5bf58e55e2dde5f673180a8(core, operation, data, session, actor, trace)

def xe5bf58e55e2dde5f673180a8(core, operation, data, session, actor, trace):
    trace.append('xe5bf58e55e2dde5f673180a8')
    return core.execute(operation, data, session, actor)

def xdc7e16c666b4116b6e3e0859(core, operation, data, session, actor, trace):
    trace.append('xdc7e16c666b4116b6e3e0859')
    return x2dd0d81db1e62efd98e04a7a(core, operation, data, session, actor, trace)

def x2dd0d81db1e62efd98e04a7a(core, operation, data, session, actor, trace):
    trace.append('x2dd0d81db1e62efd98e04a7a')
    return xcdbbc8a4961ec32ac79ce3e5(core, operation, data, session, actor, trace)

def xcdbbc8a4961ec32ac79ce3e5(core, operation, data, session, actor, trace):
    trace.append('xcdbbc8a4961ec32ac79ce3e5')
    return xa910bcfaadb23e5479b0640e(core, operation, data, session, actor, trace)

def xa910bcfaadb23e5479b0640e(core, operation, data, session, actor, trace):
    trace.append('xa910bcfaadb23e5479b0640e')
    return x249411d4ae68d7b05c9e4fd9(core, operation, data, session, actor, trace)

def x249411d4ae68d7b05c9e4fd9(core, operation, data, session, actor, trace):
    trace.append('x249411d4ae68d7b05c9e4fd9')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

ADAPTER_ENTRIES = {
    'login': x9470fe9ca0c81e2a2cd891d6,
    'logout': x61e4f9cb7f3b38f08cbb285b,
    'catalog': x6649ab85e2f3296bbfb2cef6,
    'create_order': x25068b5938e5f1e466abce5a,
    'order': x094f73b0dbe292c4d43352dc,
    'orders': x740575e1fd98c1552b10902b,
    'update_product': xdc7e16c666b4116b6e3e0859
}

def prepare_adapter(handler_name, operation):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    cursor = handler_name
    visited = set()
    while cursor != 'core.execute':
        if cursor in visited:
            raise ValueError('adapter cycle')
        visited.add(cursor)
        node = BACKEND_GRAPH[cursor]
        if node['operation'] != operation:
            raise ValueError('handler')
        cursor = node['target']
    return ADAPTER_ENTRIES[operation]

def execute_adapter(adapter, core, operation, data, session, actor):
    trace = []
    status, result, cookie = adapter(core, operation, data, session, actor, trace)
    return status, result, cookie, trace

def invoke(handler_name, core, operation, data, session, actor):
    adapter = prepare_adapter(handler_name, operation)
    return execute_adapter(adapter, core, operation, data, session, actor)

