GRAPH = {'xf24b6bdc83e06cd8442cd799': {'kind': 'router', 'edges': {'/xa12422664d4a1da0d978976d': {'target': 'x80eaada66a600589a15c8e06', 'next_key': 'x68b0b8e2d9ae56a80e726296'}, '/x277f5ba00a7c75539a67cbb4': {'target': 'x74e23a5d5ef7dc5c634e429d', 'next_key': 'x7b42f0ce032be6041d5daf4d'}, '/xd83dbf5481e2123486705aff': {'target': 'x80eaada66a600589a15c8e06', 'next_key': 'xbed3d37ac0791dfb5d58514d'}, '/x338320636e1422ee86720bea': {'target': 'x74e23a5d5ef7dc5c634e429d', 'next_key': 'xe8ad435eee6e16894a20f706'}, '/xf08b412d84e340a46ccbecfa': {'target': 'x80eaada66a600589a15c8e06', 'next_key': 'xa2ba5b96e2f3a3fb958fb794'}, '/xf593ef84a8cd74779bd7c098': {'target': 'x74e23a5d5ef7dc5c634e429d', 'next_key': 'x855b002de629a387e439cd6e'}, '/x07985ed7f9161a79412ae31f': {'target': 'x80eaada66a600589a15c8e06', 'next_key': 'x7590357a88d2a1d54498be46'}}}, 'x74e23a5d5ef7dc5c634e429d': {'kind': 'router', 'edges': {'x7b42f0ce032be6041d5daf4d': {'target': 'xfb892e4138ffdbdc31014b15', 'next_key': 'x57710997712f4055a491b623'}, 'xe8ad435eee6e16894a20f706': {'target': 'xfb892e4138ffdbdc31014b15', 'next_key': 'xa45ce1dfb6a4c428d788721f'}, 'x855b002de629a387e439cd6e': {'target': 'xfb892e4138ffdbdc31014b15', 'next_key': 'x9cc757d808ba036bc507b4f5'}}}, 'x80eaada66a600589a15c8e06': {'kind': 'router', 'edges': {'x68b0b8e2d9ae56a80e726296': {'target': 'xfb892e4138ffdbdc31014b15', 'next_key': 'x561fc17d3bd3094de0f15535'}, 'xbed3d37ac0791dfb5d58514d': {'target': 'xfb892e4138ffdbdc31014b15', 'next_key': 'x6b77fb08fc3f464ea2f5e44c'}, 'xa2ba5b96e2f3a3fb958fb794': {'target': 'xfb892e4138ffdbdc31014b15', 'next_key': 'xa8925bf8b361c89fd523b1ac'}, 'x7590357a88d2a1d54498be46': {'target': 'xfb892e4138ffdbdc31014b15', 'next_key': 'x7827a704fed51cc4f378c419'}}}, 'xfb892e4138ffdbdc31014b15': {'kind': 'router', 'edges': {'x561fc17d3bd3094de0f15535': {'target': 'x24f8b0b49d45ab05251f028f', 'next_key': 'xf8227b8dcbf5d76a786aab12'}, 'x57710997712f4055a491b623': {'target': 'xa451e76c6efd0b3a6625e1fc', 'next_key': 'x543a635fafbcbc08593b59bd'}, 'x6b77fb08fc3f464ea2f5e44c': {'target': 'x24f8b0b49d45ab05251f028f', 'next_key': 'xae0cdc9050e2751852865eb3'}, 'xa45ce1dfb6a4c428d788721f': {'target': 'xa451e76c6efd0b3a6625e1fc', 'next_key': 'x11660faaa84554aa4776346b'}, 'xa8925bf8b361c89fd523b1ac': {'target': 'x24f8b0b49d45ab05251f028f', 'next_key': 'xb7a581d1c097ea13072d6e2f'}, 'x9cc757d808ba036bc507b4f5': {'target': 'xa451e76c6efd0b3a6625e1fc', 'next_key': 'x166735a25d7d1b2665a1e6b5'}, 'x7827a704fed51cc4f378c419': {'target': 'x24f8b0b49d45ab05251f028f', 'next_key': 'xb9d2a2cee370db8b17ebd58e'}}}, 'xa451e76c6efd0b3a6625e1fc': {'kind': 'router', 'edges': {'x543a635fafbcbc08593b59bd': {'target': 'x151af0f56c2e571ad54ce4c0', 'next_key': None}, 'x11660faaa84554aa4776346b': {'target': 'xe446c395107ce8dc649d892f', 'next_key': None}, 'x166735a25d7d1b2665a1e6b5': {'target': 'x831c0784668468cec8221a4c', 'next_key': None}}}, 'x24f8b0b49d45ab05251f028f': {'kind': 'router', 'edges': {'xf8227b8dcbf5d76a786aab12': {'target': 'x2c8a7430eb99835ec9c1f89a', 'next_key': None}, 'xae0cdc9050e2751852865eb3': {'target': 'xb8a0c27e528a4982759c420f', 'next_key': None}, 'xb7a581d1c097ea13072d6e2f': {'target': 'x313b5b86d916cc93c4deeac8', 'next_key': None}, 'xb9d2a2cee370db8b17ebd58e': {'target': 'xd6e6985eb2ec3a62b2a6b7a5', 'next_key': None}}}, 'x2c8a7430eb99835ec9c1f89a': {'kind': 'service', 'operation': 'login', 'handler': 'x9470fe9ca0c81e2a2cd891d6'}, 'x151af0f56c2e571ad54ce4c0': {'kind': 'service', 'operation': 'logout', 'handler': 'x61e4f9cb7f3b38f08cbb285b'}, 'xb8a0c27e528a4982759c420f': {'kind': 'service', 'operation': 'catalog', 'handler': 'x6649ab85e2f3296bbfb2cef6'}, 'xe446c395107ce8dc649d892f': {'kind': 'service', 'operation': 'create_order', 'handler': 'x25068b5938e5f1e466abce5a'}, 'x313b5b86d916cc93c4deeac8': {'kind': 'service', 'operation': 'order', 'handler': 'x094f73b0dbe292c4d43352dc'}, 'x831c0784668468cec8221a4c': {'kind': 'service', 'operation': 'orders', 'handler': 'x740575e1fd98c1552b10902b'}, 'xd6e6985eb2ec3a62b2a6b7a5': {'kind': 'service', 'operation': 'update_product', 'handler': 'xdc7e16c666b4116b6e3e0859'}}
ENTRY = 'xf24b6bdc83e06cd8442cd799'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def assemble_router(bindings, rebuilt, original):
    name = 'decision_' + str(len(rebuilt))
    while name in original or name in rebuilt:
        name += 'r'
    edges = {}
    rebuilt[name] = {'kind': 'router', 'edges': edges}
    if not bindings:
        return name
    if len(bindings) == 1:
        path, leaf, operation = bindings[0]
        rebuilt[leaf] = dict(original[leaf])
        edges[path] = {'target': leaf, 'next_key': None}
        return name
    best = len(bindings)
    selected = None
    width = max(len(row[2]) for row in bindings)
    for position in range(width):
        symbols = sorted(set(row[2][position:position + 1] for row in bindings))
        for symbol in symbols:
            count = sum(1 for row in bindings if row[2][position:position + 1] == symbol)
            score = max(count, len(bindings) - count)
            if score < best:
                best = score
                selected = (position, symbol)
    if selected is None:
        middle = len(bindings) // 2
        groups = (bindings[:middle], bindings[middle:])
    else:
        position, symbol = selected
        groups = ([], [])
        for row in bindings:
            group = 0 if row[2][position:position + 1] == symbol else 1
            groups[group].append(row)
    for group in groups:
        child = assemble_router(group, rebuilt, original)
        for path, leaf, operation in group:
            edges[path] = {'target': child, 'next_key': path}
    return name

def rewrite_graph(graph, entry):
    bindings = []
    for path in sorted(graph[entry]['edges']):
        node, key = entry, path
        visited = set()
        while graph[node]['kind'] != 'service':
            if node in visited:
                raise ValueError('routing cycle')
            visited.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        bindings.append((path, node, graph[node]['operation']))
    rebuilt = {}
    root = assemble_router(bindings, rebuilt, graph)
    return rebuilt, root

def resolve(path):
    cursor, key = ENTRY, path
    visited, trace = set(), []
    while cursor not in visited:
        visited.add(cursor)
        trace.append(cursor)
        item = GRAPH[cursor]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        transition = item['edges'][key]
        cursor, key = transition['target'], transition['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
