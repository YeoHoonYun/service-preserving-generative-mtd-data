import {send} from './x4dc2eab3e85d80a27f8c47ef.js';
export async function x18e568ae29bbb7eafa574e43(data,csrf){const wire={"xb161bbb7a11b32f479e6714f":{}};const value=await send("/x039b4e9102c4ffbb0d49b558",wire,csrf);return value[0];}
export async function x01dc770b6da3a0e850c117ee(data,csrf){const wire={"xb149d1ef4f4df9e78ceea112":[]};const value=await send("/x36c02aae76982df6f7b0661a",wire,csrf);return value["x324f57cc011f7d5215c40b15"];}
