import {x8e634f5362e90a65211f9d97,x25836b454906da49247f9783} from './x68affb6a24ed70849e9c9d81.js';
import {x18e568ae29bbb7eafa574e43,x01dc770b6da3a0e850c117ee} from './xf076583b24cd5a4cb0ddc2d3.js';
import {x41fdb728d041e8e17dfe7fc3,x75ed0f944faa32f2f474626d} from './x60021dfa150e23fcff458c43.js';
import {xeb81fa3f61a62a63fc44108c} from './xc62e18ea36ee2735fa419f1b.js';

const endpoints = {
  login:x8e634f5362e90a65211f9d97,
  logout:x18e568ae29bbb7eafa574e43,
  catalog:x41fdb728d041e8e17dfe7fc3,
  create_order:xeb81fa3f61a62a63fc44108c,
  order:x25836b454906da49247f9783,
  orders:x01dc770b6da3a0e850c117ee,
  update_product:x75ed0f944faa32f2f474626d
};

const shop = {
  boot:JSON.parse(document.querySelector('meta[name=boot]').content),
  message:document.getElementById('x288b75b1f36e1f24a9473bb2'),
  async api(operation,data={}) {
    return endpoints[operation](data,this.boot.csrf);
  },
  identity() {
    document.getElementById('xc78b2eb0b6577479fc258712').textContent = this.boot.user ? this.boot.user.id : '방문자';
  },
  observe(promise) {
    promise.catch(error => this.message.textContent = error.message);
  },
  async catalog() {
    const list = document.getElementById('x70ad6551754acfba712c924c');
    list.replaceChildren();
    for (const p of await this.api('catalog')) {
      const li = document.createElement('li');
      li.textContent = p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock;
      list.append(li);
    }
    document.body.dataset.ready = 'yes';
  },
  async orders() {
    const list = document.getElementById('x58595b1c6f342cb9970c2f26');
    list.replaceChildren();
    for (const order of await this.api('orders')) {
      const li = document.createElement('li');
      li.textContent = order.id+' · '+order.total+'원';
      list.append(li);
    }
  },
  handleEvent(event) {
    event.preventDefault();
    this.observe(this.submit(event.target));
  },
  async submit(form) {
    const raw = Object.fromEntries(new FormData(form));
    const data = {
      username:raw['x09cba90301891366576a16de'],
      password:raw['x3dfcf42f58490a2ba52f4a31'],
      product_id:raw['x5e62518c4799d168de351575'],
      quantity:raw['x14655db7ea6fa2b0293b18e5'],
      price:raw['x74f595672b622ad5ccff37f4'],
      stock:raw['xeb223197451e2934f8224e11']
    };
    let position = 0;
    while (position < submissions.length) {
      const command = submissions[position++];
      if (form.dataset.action === command.action) {
        await command.perform(this,data);
      }
    }
  }
};

const submissions = [
  {
    action:'x41b75259cf07fd3692250bb0',
    async perform(controller,data) {
      controller.boot = await controller.api('login',data);
      controller.identity();
      controller.message.textContent = '로그인되었습니다.';
    }
  },
  {
    action:'xddd9222eab62d9bc8ac17aa0',
    async perform(controller,data) {
      const order = await controller.api('create_order',{
        product_id:data.product_id,
        quantity:Number(data.quantity),
        request_id:crypto.randomUUID()
      });
      controller.message.textContent = '주문 '+order.id+' · '+order.total+'원';
      await controller.catalog();
      await controller.orders();
    }
  },
  {
    action:'x18384352fb8b7306b886f744',
    async perform(controller,data) {
      await controller.api('update_product',{
        product_id:'p1',price:Number(data.price),stock:Number(data.stock)
      });
      controller.message.textContent = '상품을 수정했습니다.';
      await controller.catalog();
    }
  }
];

document.addEventListener('submit',shop);
document.getElementById('xfc97f9f999c219052189c462').onclick = () => shop.observe(shop.api('logout').then(() => location.reload()));
document.getElementById('x6bc97689e6b7fa5e62b674bc').onclick = () => shop.observe(shop.orders());
shop.identity();
shop.observe(shop.catalog());
