# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x76f37bdefafe01d2566b91db', 'fields': ['username', 'password'], 'aliases': {'username': 'x7270dffdc5c0e1b65bdc3883', 'password': 'x72a514c997be1b7bbb32a22e'}, 'request_shape': 'pairs', 'response_shape': 'wrapped', 'request_box': 'x9e9425ead3a60f9f09cc4b81', 'response_box': 'x47577493bc795fe456866624', 'result_key': 'x5c35bc50db361964db328fd3'}, 'logout': {'route': '/x039b4e9102c4ffbb0d49b558', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'xb161bbb7a11b32f479e6714f', 'response_box': 'xa000c7bc9947b0b1f53031e3', 'result_key': 'x8dbc24cca336e39e634ab97b'}, 'catalog': {'route': '/x0098b5cadbee9b5f5c2118c9', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'xd366107b18f058d6fe93072a', 'response_box': 'xa87c20aecb0439079308bf6c', 'result_key': 'x8485ee96ece2e179a9abaa78'}, 'create_order': {'route': '/x84cc8750b91f82116a5e033f', 'fields': ['product_id', 'request_id', 'quantity'], 'aliases': {'product_id': 'xd3e2315e42a856f2e28ca141', 'request_id': 'xfa6cb88b4c652a79b33ef00d', 'quantity': 'xc5166f0fccfb358358b9c4c1'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x59587b08fb990cb58473228c', 'response_box': 'x49cd08f9e0a58c57c4bd3645', 'result_key': 'x96ac90f8bafcd35ffd17a7c3'}, 'order': {'route': '/x42d855399a4e609a2e6f99fc', 'fields': ['order_id'], 'aliases': {'order_id': 'x4287127969d6653ba2340332'}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'x77e3462241eb9c9f30a4f0dc', 'response_box': 'x6fd60d8522e25d2183c43fa9', 'result_key': 'x8ce2a7a38bbf90284fc7ebf8'}, 'orders': {'route': '/x36c02aae76982df6f7b0661a', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'xb149d1ef4f4df9e78ceea112', 'response_box': 'x724b088e20d2599ed16ae85b', 'result_key': 'x324f57cc011f7d5215c40b15'}, 'update_product': {'route': '/x84302c6a1d9013fba8fdfd03', 'fields': ['price', 'stock', 'product_id'], 'aliases': {'price': 'xdcc4a88d65bcf2cff2ed2036', 'stock': 'x4c629603375def5e86c42266', 'product_id': 'x15d2de7c76130e761572e6e5'}, 'request_shape': 'positional', 'response_shape': 'object', 'request_box': 'x5a931dad099349edcc12c5d8', 'response_box': 'xe53720f712b6040da833853c', 'result_key': 'x9fe141aff62436470e0b1a74'}}
HANDLERS = {'login': 'xcbdbbca5286c531c98e43a3c', 'logout': 'xbc8ce65d8206fea6b2f39091', 'catalog': 'x1d1b53212b8316841af18332', 'create_order': 'x3ac2463a848e6edb1e2a5009', 'order': 'x776d6311f78b94005955139c', 'orders': 'xc6e90ddd498a38c9af088b2b', 'update_product': 'x8a4f96849281472b90df4a74'}
BACKEND_GRAPH = {'xcbdbbca5286c531c98e43a3c': {'operation': 'login', 'target': 'x624740776ad48f4020d1b047', 'kind': 'adapter'}, 'x624740776ad48f4020d1b047': {'operation': 'login', 'target': 'x23c5e83b31b7baf86c61513c', 'kind': 'adapter'}, 'x23c5e83b31b7baf86c61513c': {'operation': 'login', 'target': 'x18a7de71be8ceb02827e818f', 'kind': 'adapter'}, 'x18a7de71be8ceb02827e818f': {'operation': 'login', 'target': 'x7178c7b6643bfc78bd491f99', 'kind': 'adapter'}, 'x7178c7b6643bfc78bd491f99': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'xbc8ce65d8206fea6b2f39091': {'operation': 'logout', 'target': 'x5aee4a3d6b9e5dd40917e6c5', 'kind': 'adapter'}, 'x5aee4a3d6b9e5dd40917e6c5': {'operation': 'logout', 'target': 'x60943e40b294706e27ceb693', 'kind': 'adapter'}, 'x60943e40b294706e27ceb693': {'operation': 'logout', 'target': 'x5c04407a63587d3b65433136', 'kind': 'adapter'}, 'x5c04407a63587d3b65433136': {'operation': 'logout', 'target': 'x0de8c3f878273fa6f090b92e', 'kind': 'adapter'}, 'x0de8c3f878273fa6f090b92e': {'operation': 'logout', 'target': 'x23f48e764de1b22b3cd4bbcb', 'kind': 'adapter'}, 'x23f48e764de1b22b3cd4bbcb': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x1d1b53212b8316841af18332': {'operation': 'catalog', 'target': 'x6cdc6192e5c2e889bac6a69f', 'kind': 'adapter'}, 'x6cdc6192e5c2e889bac6a69f': {'operation': 'catalog', 'target': 'x04d26ffb002cb2fce426d2fe', 'kind': 'adapter'}, 'x04d26ffb002cb2fce426d2fe': {'operation': 'catalog', 'target': 'xa64e80a53a1b516a1aceebc1', 'kind': 'adapter'}, 'xa64e80a53a1b516a1aceebc1': {'operation': 'catalog', 'target': 'xbd477720de31f6090b7b2559', 'kind': 'adapter'}, 'xbd477720de31f6090b7b2559': {'operation': 'catalog', 'target': 'x415d85c0a492d6037db33415', 'kind': 'adapter'}, 'x415d85c0a492d6037db33415': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x3ac2463a848e6edb1e2a5009': {'operation': 'create_order', 'target': 'xc46a7c247a8f1ec57eb4d3f4', 'kind': 'adapter'}, 'xc46a7c247a8f1ec57eb4d3f4': {'operation': 'create_order', 'target': 'x7e56faf238a235a83ee864d5', 'kind': 'adapter'}, 'x7e56faf238a235a83ee864d5': {'operation': 'create_order', 'target': 'x814d52cff815b17b503f2ffe', 'kind': 'adapter'}, 'x814d52cff815b17b503f2ffe': {'operation': 'create_order', 'target': 'xed78226c9e00cfe69ca6bda3', 'kind': 'adapter'}, 'xed78226c9e00cfe69ca6bda3': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x776d6311f78b94005955139c': {'operation': 'order', 'target': 'x5039da5a36a4220a08560159', 'kind': 'adapter'}, 'x5039da5a36a4220a08560159': {'operation': 'order', 'target': 'x04936ce549e099abb7edd1d7', 'kind': 'adapter'}, 'x04936ce549e099abb7edd1d7': {'operation': 'order', 'target': 'x8481b52fee9b56e7feca85e9', 'kind': 'adapter'}, 'x8481b52fee9b56e7feca85e9': {'operation': 'order', 'target': 'x58e86a05b3d49a85569cac02', 'kind': 'adapter'}, 'x58e86a05b3d49a85569cac02': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'xc6e90ddd498a38c9af088b2b': {'operation': 'orders', 'target': 'x7cbbf503ab8ff4f5dc856b63', 'kind': 'adapter'}, 'x7cbbf503ab8ff4f5dc856b63': {'operation': 'orders', 'target': 'xa0f732f751a6bc444a5a2971', 'kind': 'adapter'}, 'xa0f732f751a6bc444a5a2971': {'operation': 'orders', 'target': 'xdde40e00fd3ae2c9286d95de', 'kind': 'adapter'}, 'xdde40e00fd3ae2c9286d95de': {'operation': 'orders', 'target': 'x3358002db9b42489ad1b72fa', 'kind': 'adapter'}, 'x3358002db9b42489ad1b72fa': {'operation': 'orders', 'target': 'x6ed4080fb26a225b3b3801a4', 'kind': 'adapter'}, 'x6ed4080fb26a225b3b3801a4': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x8a4f96849281472b90df4a74': {'operation': 'update_product', 'target': 'xbe6ad42cdaf28b23222153dc', 'kind': 'adapter'}, 'xbe6ad42cdaf28b23222153dc': {'operation': 'update_product', 'target': 'x7cbc5cc0551fbae47d4aeb1d', 'kind': 'adapter'}, 'x7cbc5cc0551fbae47d4aeb1d': {'operation': 'update_product', 'target': 'x632aceaf77d6c226a2964dfc', 'kind': 'adapter'}, 'x632aceaf77d6c226a2964dfc': {'operation': 'update_product', 'target': 'x3012507775cdcdaf4e215692', 'kind': 'adapter'}, 'x3012507775cdcdaf4e215692': {'operation': 'update_product', 'target': 'xb9c874a2d08f4d6fa71a4139', 'kind': 'adapter'}, 'xb9c874a2d08f4d6fa71a4139': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xcbdbbca5286c531c98e43a3c(core, operation, data, session, actor, trace):
    trace.append('xcbdbbca5286c531c98e43a3c')
    return x624740776ad48f4020d1b047(core, operation, data, session, actor, trace)

def x624740776ad48f4020d1b047(core, operation, data, session, actor, trace):
    trace.append('x624740776ad48f4020d1b047')
    return x23c5e83b31b7baf86c61513c(core, operation, data, session, actor, trace)

def x23c5e83b31b7baf86c61513c(core, operation, data, session, actor, trace):
    trace.append('x23c5e83b31b7baf86c61513c')
    return x18a7de71be8ceb02827e818f(core, operation, data, session, actor, trace)

def x18a7de71be8ceb02827e818f(core, operation, data, session, actor, trace):
    trace.append('x18a7de71be8ceb02827e818f')
    return x7178c7b6643bfc78bd491f99(core, operation, data, session, actor, trace)

def x7178c7b6643bfc78bd491f99(core, operation, data, session, actor, trace):
    trace.append('x7178c7b6643bfc78bd491f99')
    return core.execute(operation, data, session, actor)

def xbc8ce65d8206fea6b2f39091(core, operation, data, session, actor, trace):
    trace.append('xbc8ce65d8206fea6b2f39091')
    return x5aee4a3d6b9e5dd40917e6c5(core, operation, data, session, actor, trace)

def x5aee4a3d6b9e5dd40917e6c5(core, operation, data, session, actor, trace):
    trace.append('x5aee4a3d6b9e5dd40917e6c5')
    return x60943e40b294706e27ceb693(core, operation, data, session, actor, trace)

def x60943e40b294706e27ceb693(core, operation, data, session, actor, trace):
    trace.append('x60943e40b294706e27ceb693')
    return x5c04407a63587d3b65433136(core, operation, data, session, actor, trace)

def x5c04407a63587d3b65433136(core, operation, data, session, actor, trace):
    trace.append('x5c04407a63587d3b65433136')
    return x0de8c3f878273fa6f090b92e(core, operation, data, session, actor, trace)

def x0de8c3f878273fa6f090b92e(core, operation, data, session, actor, trace):
    trace.append('x0de8c3f878273fa6f090b92e')
    return x23f48e764de1b22b3cd4bbcb(core, operation, data, session, actor, trace)

def x23f48e764de1b22b3cd4bbcb(core, operation, data, session, actor, trace):
    trace.append('x23f48e764de1b22b3cd4bbcb')
    return core.execute(operation, data, session, actor)

def x1d1b53212b8316841af18332(core, operation, data, session, actor, trace):
    trace.append('x1d1b53212b8316841af18332')
    return x6cdc6192e5c2e889bac6a69f(core, operation, data, session, actor, trace)

def x6cdc6192e5c2e889bac6a69f(core, operation, data, session, actor, trace):
    trace.append('x6cdc6192e5c2e889bac6a69f')
    return x04d26ffb002cb2fce426d2fe(core, operation, data, session, actor, trace)

def x04d26ffb002cb2fce426d2fe(core, operation, data, session, actor, trace):
    trace.append('x04d26ffb002cb2fce426d2fe')
    return xa64e80a53a1b516a1aceebc1(core, operation, data, session, actor, trace)

def xa64e80a53a1b516a1aceebc1(core, operation, data, session, actor, trace):
    trace.append('xa64e80a53a1b516a1aceebc1')
    return xbd477720de31f6090b7b2559(core, operation, data, session, actor, trace)

def xbd477720de31f6090b7b2559(core, operation, data, session, actor, trace):
    trace.append('xbd477720de31f6090b7b2559')
    return x415d85c0a492d6037db33415(core, operation, data, session, actor, trace)

def x415d85c0a492d6037db33415(core, operation, data, session, actor, trace):
    trace.append('x415d85c0a492d6037db33415')
    return core.execute(operation, data, session, actor)

def x3ac2463a848e6edb1e2a5009(core, operation, data, session, actor, trace):
    trace.append('x3ac2463a848e6edb1e2a5009')
    return xc46a7c247a8f1ec57eb4d3f4(core, operation, data, session, actor, trace)

def xc46a7c247a8f1ec57eb4d3f4(core, operation, data, session, actor, trace):
    trace.append('xc46a7c247a8f1ec57eb4d3f4')
    return x7e56faf238a235a83ee864d5(core, operation, data, session, actor, trace)

def x7e56faf238a235a83ee864d5(core, operation, data, session, actor, trace):
    trace.append('x7e56faf238a235a83ee864d5')
    return x814d52cff815b17b503f2ffe(core, operation, data, session, actor, trace)

def x814d52cff815b17b503f2ffe(core, operation, data, session, actor, trace):
    trace.append('x814d52cff815b17b503f2ffe')
    return xed78226c9e00cfe69ca6bda3(core, operation, data, session, actor, trace)

def xed78226c9e00cfe69ca6bda3(core, operation, data, session, actor, trace):
    trace.append('xed78226c9e00cfe69ca6bda3')
    return core.execute(operation, data, session, actor)

def x776d6311f78b94005955139c(core, operation, data, session, actor, trace):
    trace.append('x776d6311f78b94005955139c')
    return x5039da5a36a4220a08560159(core, operation, data, session, actor, trace)

def x5039da5a36a4220a08560159(core, operation, data, session, actor, trace):
    trace.append('x5039da5a36a4220a08560159')
    return x04936ce549e099abb7edd1d7(core, operation, data, session, actor, trace)

def x04936ce549e099abb7edd1d7(core, operation, data, session, actor, trace):
    trace.append('x04936ce549e099abb7edd1d7')
    return x8481b52fee9b56e7feca85e9(core, operation, data, session, actor, trace)

def x8481b52fee9b56e7feca85e9(core, operation, data, session, actor, trace):
    trace.append('x8481b52fee9b56e7feca85e9')
    return x58e86a05b3d49a85569cac02(core, operation, data, session, actor, trace)

def x58e86a05b3d49a85569cac02(core, operation, data, session, actor, trace):
    trace.append('x58e86a05b3d49a85569cac02')
    return core.execute(operation, data, session, actor)

def xc6e90ddd498a38c9af088b2b(core, operation, data, session, actor, trace):
    trace.append('xc6e90ddd498a38c9af088b2b')
    return x7cbbf503ab8ff4f5dc856b63(core, operation, data, session, actor, trace)

def x7cbbf503ab8ff4f5dc856b63(core, operation, data, session, actor, trace):
    trace.append('x7cbbf503ab8ff4f5dc856b63')
    return xa0f732f751a6bc444a5a2971(core, operation, data, session, actor, trace)

def xa0f732f751a6bc444a5a2971(core, operation, data, session, actor, trace):
    trace.append('xa0f732f751a6bc444a5a2971')
    return xdde40e00fd3ae2c9286d95de(core, operation, data, session, actor, trace)

def xdde40e00fd3ae2c9286d95de(core, operation, data, session, actor, trace):
    trace.append('xdde40e00fd3ae2c9286d95de')
    return x3358002db9b42489ad1b72fa(core, operation, data, session, actor, trace)

def x3358002db9b42489ad1b72fa(core, operation, data, session, actor, trace):
    trace.append('x3358002db9b42489ad1b72fa')
    return x6ed4080fb26a225b3b3801a4(core, operation, data, session, actor, trace)

def x6ed4080fb26a225b3b3801a4(core, operation, data, session, actor, trace):
    trace.append('x6ed4080fb26a225b3b3801a4')
    return core.execute(operation, data, session, actor)

def x8a4f96849281472b90df4a74(core, operation, data, session, actor, trace):
    trace.append('x8a4f96849281472b90df4a74')
    return xbe6ad42cdaf28b23222153dc(core, operation, data, session, actor, trace)

def xbe6ad42cdaf28b23222153dc(core, operation, data, session, actor, trace):
    trace.append('xbe6ad42cdaf28b23222153dc')
    return x7cbc5cc0551fbae47d4aeb1d(core, operation, data, session, actor, trace)

def x7cbc5cc0551fbae47d4aeb1d(core, operation, data, session, actor, trace):
    trace.append('x7cbc5cc0551fbae47d4aeb1d')
    return x632aceaf77d6c226a2964dfc(core, operation, data, session, actor, trace)

def x632aceaf77d6c226a2964dfc(core, operation, data, session, actor, trace):
    trace.append('x632aceaf77d6c226a2964dfc')
    return x3012507775cdcdaf4e215692(core, operation, data, session, actor, trace)

def x3012507775cdcdaf4e215692(core, operation, data, session, actor, trace):
    trace.append('x3012507775cdcdaf4e215692')
    return xb9c874a2d08f4d6fa71a4139(core, operation, data, session, actor, trace)

def xb9c874a2d08f4d6fa71a4139(core, operation, data, session, actor, trace):
    trace.append('xb9c874a2d08f4d6fa71a4139')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def adapter_select(frame, pending):
    dispatch = {
        'login': xcbdbbca5286c531c98e43a3c,
        'logout': xbc8ce65d8206fea6b2f39091,
        'catalog': x1d1b53212b8316841af18332,
        'create_order': x3ac2463a848e6edb1e2a5009,
        'order': x776d6311f78b94005955139c,
        'orders': xc6e90ddd498a38c9af088b2b,
        'update_product': x8a4f96849281472b90df4a74
    }
    frame['call'] = dispatch[frame['arguments'][1]]
    pending.append(adapter_execute)

def adapter_execute(frame, pending):
    core, operation, data, session, actor = frame['arguments']
    frame['response'] = frame['call'](core, operation, data, session, actor, frame['trace'])
    pending.append(adapter_complete)

def adapter_complete(frame, pending):
    status, result, cookie = frame['response']
    frame['output'] = (status, result, cookie, frame['trace'])

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    frame = {'arguments': (core, operation, data, session, actor), 'trace': []}
    pending = [adapter_select]
    while pending:
        step = pending.pop(0)
        step(frame, pending)
    return frame['output']

