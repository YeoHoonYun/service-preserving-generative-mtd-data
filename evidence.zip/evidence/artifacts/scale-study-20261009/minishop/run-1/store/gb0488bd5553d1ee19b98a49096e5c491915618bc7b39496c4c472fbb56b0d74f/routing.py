GRAPH = {'xcae8d8bf4303c524c156a69a': {'kind': 'router', 'edges': {'/x76f37bdefafe01d2566b91db': {'target': 'x881f1383040961638878d73d', 'next_key': 'xc7ed5a3c22e4d4a7ff67edbc'}, '/x039b4e9102c4ffbb0d49b558': {'target': 'x3ab1e0a9c654cf3c9d8aa73a', 'next_key': 'xbd998f428a6c8fc4a36742f5'}, '/x0098b5cadbee9b5f5c2118c9': {'target': 'x881f1383040961638878d73d', 'next_key': 'xed346672a92037cbfcd296da'}, '/x84cc8750b91f82116a5e033f': {'target': 'x3ab1e0a9c654cf3c9d8aa73a', 'next_key': 'xfc3481afa8492c5910da34dd'}, '/x42d855399a4e609a2e6f99fc': {'target': 'x881f1383040961638878d73d', 'next_key': 'xacc0e6a244078501457f3a13'}, '/x36c02aae76982df6f7b0661a': {'target': 'x3ab1e0a9c654cf3c9d8aa73a', 'next_key': 'x7bf0b5471269ea110480be00'}, '/x84302c6a1d9013fba8fdfd03': {'target': 'x881f1383040961638878d73d', 'next_key': 'xa63c25e11c3f83530a9b93b2'}}}, 'x3ab1e0a9c654cf3c9d8aa73a': {'kind': 'router', 'edges': {'xbd998f428a6c8fc4a36742f5': {'target': 'x8267491ce89c1de411935aa3', 'next_key': 'x35f27253a438a90d31a6b644'}, 'xfc3481afa8492c5910da34dd': {'target': 'x8267491ce89c1de411935aa3', 'next_key': 'xc2f6127c2ed15b88c6490eaa'}, 'x7bf0b5471269ea110480be00': {'target': 'x8267491ce89c1de411935aa3', 'next_key': 'xcb942e5f32c18f3c0c8158dd'}}}, 'x881f1383040961638878d73d': {'kind': 'router', 'edges': {'xc7ed5a3c22e4d4a7ff67edbc': {'target': 'x8267491ce89c1de411935aa3', 'next_key': 'x0f8334273fd2cbd4737ef2dc'}, 'xed346672a92037cbfcd296da': {'target': 'x8267491ce89c1de411935aa3', 'next_key': 'x9cda86a955fb963d8fbd33f0'}, 'xacc0e6a244078501457f3a13': {'target': 'x8267491ce89c1de411935aa3', 'next_key': 'x58185ba7b7b87e29d68a494b'}, 'xa63c25e11c3f83530a9b93b2': {'target': 'x8267491ce89c1de411935aa3', 'next_key': 'x0030f14e6f18f729070530ba'}}}, 'x8267491ce89c1de411935aa3': {'kind': 'router', 'edges': {'x0f8334273fd2cbd4737ef2dc': {'target': 'x9cca9cf62014ab7747a2033e', 'next_key': 'xe294f4ad28ff7636d79b90d1'}, 'x35f27253a438a90d31a6b644': {'target': 'x9cca9cf62014ab7747a2033e', 'next_key': 'x3450fff06ac47cd78cdaea89'}, 'x9cda86a955fb963d8fbd33f0': {'target': 'x9cca9cf62014ab7747a2033e', 'next_key': 'x6867f3a48d9a08a756c21163'}, 'xc2f6127c2ed15b88c6490eaa': {'target': 'x9cca9cf62014ab7747a2033e', 'next_key': 'x351bfd3b74f40e36916e75f7'}, 'x58185ba7b7b87e29d68a494b': {'target': 'x9cca9cf62014ab7747a2033e', 'next_key': 'xd65f033783490b5909b92469'}, 'xcb942e5f32c18f3c0c8158dd': {'target': 'x9cca9cf62014ab7747a2033e', 'next_key': 'xc5a1575cfc19fca0d13d4bfd'}, 'x0030f14e6f18f729070530ba': {'target': 'x9cca9cf62014ab7747a2033e', 'next_key': 'x786de7c757a32750cec92af3'}}}, 'x9cca9cf62014ab7747a2033e': {'kind': 'router', 'edges': {'xe294f4ad28ff7636d79b90d1': {'target': 'x7037ed902f46cdfc200d4a30', 'next_key': 'x791d76242fccebc74f456b3b'}, 'x3450fff06ac47cd78cdaea89': {'target': 'x7037ed902f46cdfc200d4a30', 'next_key': 'xc489155557b69caf3d478f61'}, 'x6867f3a48d9a08a756c21163': {'target': 'x7037ed902f46cdfc200d4a30', 'next_key': 'x7b5702d88cdb7c923509acc3'}, 'x351bfd3b74f40e36916e75f7': {'target': 'x7037ed902f46cdfc200d4a30', 'next_key': 'x5a371d61c41e69c622ee8b1d'}, 'xd65f033783490b5909b92469': {'target': 'x7037ed902f46cdfc200d4a30', 'next_key': 'x6052b49e05ef3abd8ef6089a'}, 'xc5a1575cfc19fca0d13d4bfd': {'target': 'x7037ed902f46cdfc200d4a30', 'next_key': 'x1e3cdb71b117dcda591397ea'}, 'x786de7c757a32750cec92af3': {'target': 'x7037ed902f46cdfc200d4a30', 'next_key': 'xd27e0fc03c1519ca362b19ab'}}}, 'x7037ed902f46cdfc200d4a30': {'kind': 'router', 'edges': {'x791d76242fccebc74f456b3b': {'target': 'x21760272d1d74e645a587ff2', 'next_key': None}, 'xc489155557b69caf3d478f61': {'target': 'x6cb6e7c21bbb9799634e8e8b', 'next_key': None}, 'x7b5702d88cdb7c923509acc3': {'target': 'xfb841c079f7c3a3e4eea2db5', 'next_key': None}, 'x5a371d61c41e69c622ee8b1d': {'target': 'x13327e652bd160131f7bbde5', 'next_key': None}, 'x6052b49e05ef3abd8ef6089a': {'target': 'xcde84596efeba6e87ff1813b', 'next_key': None}, 'x1e3cdb71b117dcda591397ea': {'target': 'xe362e341fda4aa8b051b5e89', 'next_key': None}, 'xd27e0fc03c1519ca362b19ab': {'target': 'x204ae5a72ac7b7237624ddd0', 'next_key': None}}}, 'x21760272d1d74e645a587ff2': {'kind': 'service', 'operation': 'login', 'handler': 'xcbdbbca5286c531c98e43a3c'}, 'x6cb6e7c21bbb9799634e8e8b': {'kind': 'service', 'operation': 'logout', 'handler': 'xbc8ce65d8206fea6b2f39091'}, 'xfb841c079f7c3a3e4eea2db5': {'kind': 'service', 'operation': 'catalog', 'handler': 'x1d1b53212b8316841af18332'}, 'x13327e652bd160131f7bbde5': {'kind': 'service', 'operation': 'create_order', 'handler': 'x3ac2463a848e6edb1e2a5009'}, 'xcde84596efeba6e87ff1813b': {'kind': 'service', 'operation': 'order', 'handler': 'x776d6311f78b94005955139c'}, 'xe362e341fda4aa8b051b5e89': {'kind': 'service', 'operation': 'orders', 'handler': 'xc6e90ddd498a38c9af088b2b'}, 'x204ae5a72ac7b7237624ddd0': {'kind': 'service', 'operation': 'update_product', 'handler': 'x8a4f96849281472b90df4a74'}}
ENTRY = 'xcae8d8bf4303c524c156a69a'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    bindings = []
    for path in graph[entry]['edges']:
        node, key, seen = entry, path, set()
        while graph[node]['kind'] != 'service':
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        bindings.append((graph[node]['operation'], path, node))
    rebuilt = {'mesh_root': {'kind': 'router', 'edges': {}}}
    for index, binding in enumerate(sorted(bindings)):
        operation, path, source = binding
        band = 'mesh_band_' + str(index // 3)
        lane = 'mesh_lane_' + str(index % 3)
        leaf = 'mesh_leaf_' + str(index)
        token = 'turn_' + str(index)
        for router in (band, lane):
            if router not in rebuilt:
                rebuilt[router] = {'kind': 'router', 'edges': {}}
        rebuilt[leaf] = dict(graph[source])
        rebuilt['mesh_root']['edges'][path] = {'target': band, 'next_key': token}
        rebuilt[band]['edges'][token] = {'target': lane, 'next_key': path}
        rebuilt[lane]['edges'][path] = {'target': leaf, 'next_key': None}
    return rebuilt, 'mesh_root'

def resolve(path):
    current, key = ENTRY, path
    visited, trace = set(), []
    while current not in visited:
        visited.add(current)
        trace.append(current)
        item = GRAPH[current]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        current, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
