import {send} from './x4dc2eab3e85d80a27f8c47ef.js';
export async function xeb81fa3f61a62a63fc44108c(data,csrf){const wire={"xd3e2315e42a856f2e28ca141":data["product_id"],"xfa6cb88b4c652a79b33ef00d":data["request_id"],"xc5166f0fccfb358358b9c4c1":data["quantity"]};const value=await send("/x84cc8750b91f82116a5e033f",wire,csrf);return value["x96ac90f8bafcd35ffd17a7c3"];}
