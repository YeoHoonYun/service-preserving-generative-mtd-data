import {send} from './x4dc2eab3e85d80a27f8c47ef.js';
export async function x8e634f5362e90a65211f9d97(data,csrf){const wire={"x9e9425ead3a60f9f09cc4b81":[["x7270dffdc5c0e1b65bdc3883",data["username"]],["x72a514c997be1b7bbb32a22e",data["password"]]]};const value=await send("/x76f37bdefafe01d2566b91db",wire,csrf);return value["x47577493bc795fe456866624"]["x5c35bc50db361964db328fd3"];}
export async function x25836b454906da49247f9783(data,csrf){const wire=[data["order_id"]];const value=await send("/x42d855399a4e609a2e6f99fc",wire,csrf);return value["x8ce2a7a38bbf90284fc7ebf8"];}
