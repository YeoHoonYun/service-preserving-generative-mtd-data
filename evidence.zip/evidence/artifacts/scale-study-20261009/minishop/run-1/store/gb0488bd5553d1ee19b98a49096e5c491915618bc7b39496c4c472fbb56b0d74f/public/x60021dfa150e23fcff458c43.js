import {send} from './x4dc2eab3e85d80a27f8c47ef.js';
export async function x41fdb728d041e8e17dfe7fc3(data,csrf){const wire={};const value=await send("/x0098b5cadbee9b5f5c2118c9",wire,csrf);return value["xa87c20aecb0439079308bf6c"]["x8485ee96ece2e179a9abaa78"];}
export async function x75ed0f944faa32f2f474626d(data,csrf){const wire=[data["price"],data["stock"],data["product_id"]];const value=await send("/x84302c6a1d9013fba8fdfd03",wire,csrf);return value["x9fe141aff62436470e0b1a74"];}
