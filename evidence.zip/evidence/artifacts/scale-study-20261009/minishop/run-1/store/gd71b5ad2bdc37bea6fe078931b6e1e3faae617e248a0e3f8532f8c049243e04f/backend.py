# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x806d81587b2083fd36d8118c', 'fields': ['username', 'password'], 'aliases': {'username': 'xd0a0bf6df5ad98abbdf23b93', 'password': 'x0ad1f54aa926541be7d98a87'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x1dced00ef2f6e9e154d377db', 'response_box': 'x35220bd4e0f0749987fbe600', 'result_key': 'x34a1bde243a4a5d494d96993'}, 'logout': {'route': '/x30d9d163c0da707c33603a9c', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'xaf9c0bf86f5832a6741e9f26', 'response_box': 'x5739172a4d6aaeecb0a288bc', 'result_key': 'xe032c5178e0c53a9a2842681'}, 'catalog': {'route': '/xb30f0928cdca923c72140688', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x5c5e70878b64fb00414ccf88', 'response_box': 'x928675f77a924d3cc27a5ec6', 'result_key': 'xff5e14593b8aacc53fc053c2'}, 'create_order': {'route': '/x6463ffec7b7ab759aa14ef45', 'fields': ['request_id', 'quantity', 'product_id'], 'aliases': {'request_id': 'xf5d53ec138c360e2a0f3ff0f', 'quantity': 'x50ba9b62cb9b419075ab700d', 'product_id': 'xa1f6beb6ec9f4f03e84f208d'}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'xb6fff143141239ee489ad013', 'response_box': 'xa03569ce5409830b0701d7e1', 'result_key': 'x0e9626deee540076ba315bef'}, 'order': {'route': '/x4d94c998b4a9fbb4bff57433', 'fields': ['order_id'], 'aliases': {'order_id': 'x95d5366213dd699560bae3b0'}, 'request_shape': 'pairs', 'response_shape': 'wrapped', 'request_box': 'x1aa6ce081afee75b46f77cee', 'response_box': 'xaf5d4a966c4055622a98141f', 'result_key': 'x5399f9ac4e19ce52a92ab532'}, 'orders': {'route': '/x25634f4bc90dfe26fbdc4e67', 'fields': [], 'aliases': {}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x2b2b5a3729f6fd009c02abb8', 'response_box': 'x07a6aa380715b15d3adc7772', 'result_key': 'x04b5cef9636cb415e1191884'}, 'update_product': {'route': '/x8e85939687aa544f055a7ebc', 'fields': ['product_id', 'stock', 'price'], 'aliases': {'product_id': 'xae4b206dd0a1ea0248cc812a', 'stock': 'x3deab6bb9582a631f34abcde', 'price': 'xca37474cc62139842faf21f5'}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'x56b6e940fd3f87b7ab72636f', 'response_box': 'x710b614f31d4ab23748eb36c', 'result_key': 'x44525c0432b79b5cde3f552a'}}
HANDLERS = {'login': 'xf07f2edb7f5d1327552c97cb', 'logout': 'x9eb52e0421c90d7e2bb810ed', 'catalog': 'x471afb822bf61d0c16c84e53', 'create_order': 'x86ce620aba314d29939945e0', 'order': 'x3e424a702ce69c7b45dafe85', 'orders': 'x819d6ac7bd5ab05e4d2a7463', 'update_product': 'x52411521cd3aa22496ac0202'}
BACKEND_GRAPH = {'xf07f2edb7f5d1327552c97cb': {'operation': 'login', 'target': 'x1622ec9fa207e8b353db3641', 'kind': 'adapter'}, 'x1622ec9fa207e8b353db3641': {'operation': 'login', 'target': 'x304fc15ecf23f7c2ed8610b3', 'kind': 'adapter'}, 'x304fc15ecf23f7c2ed8610b3': {'operation': 'login', 'target': 'x9f8d6199bb28ad4ad897230e', 'kind': 'adapter'}, 'x9f8d6199bb28ad4ad897230e': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x9eb52e0421c90d7e2bb810ed': {'operation': 'logout', 'target': 'x759e6315002ca12718b40274', 'kind': 'adapter'}, 'x759e6315002ca12718b40274': {'operation': 'logout', 'target': 'x2ef07925a716fe179bf7a778', 'kind': 'adapter'}, 'x2ef07925a716fe179bf7a778': {'operation': 'logout', 'target': 'xee8257f3d0fa1bc416fb5677', 'kind': 'adapter'}, 'xee8257f3d0fa1bc416fb5677': {'operation': 'logout', 'target': 'x1318c2631cdfe8fab02d9a97', 'kind': 'adapter'}, 'x1318c2631cdfe8fab02d9a97': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'x471afb822bf61d0c16c84e53': {'operation': 'catalog', 'target': 'xf0e487bb04f5d35eff504ad2', 'kind': 'adapter'}, 'xf0e487bb04f5d35eff504ad2': {'operation': 'catalog', 'target': 'xc1c57ac72ad5cec2ea9c943f', 'kind': 'adapter'}, 'xc1c57ac72ad5cec2ea9c943f': {'operation': 'catalog', 'target': 'x8e91f07bd6accd8d4db937da', 'kind': 'adapter'}, 'x8e91f07bd6accd8d4db937da': {'operation': 'catalog', 'target': 'x6e353f0f741a6ea7e5699895', 'kind': 'adapter'}, 'x6e353f0f741a6ea7e5699895': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x86ce620aba314d29939945e0': {'operation': 'create_order', 'target': 'x811409ddcd975705cb2bc50b', 'kind': 'adapter'}, 'x811409ddcd975705cb2bc50b': {'operation': 'create_order', 'target': 'xcdc4a4498168238b9ad89d73', 'kind': 'adapter'}, 'xcdc4a4498168238b9ad89d73': {'operation': 'create_order', 'target': 'x0efc50b16d1318722555a501', 'kind': 'adapter'}, 'x0efc50b16d1318722555a501': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x3e424a702ce69c7b45dafe85': {'operation': 'order', 'target': 'x450b5fee30adac96a5072094', 'kind': 'adapter'}, 'x450b5fee30adac96a5072094': {'operation': 'order', 'target': 'x6906cdd843eb82438ab09774', 'kind': 'adapter'}, 'x6906cdd843eb82438ab09774': {'operation': 'order', 'target': 'x3287e637c5c092952734bdb2', 'kind': 'adapter'}, 'x3287e637c5c092952734bdb2': {'operation': 'order', 'target': 'x3e3f1ebbf2ba027f98552838', 'kind': 'adapter'}, 'x3e3f1ebbf2ba027f98552838': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x819d6ac7bd5ab05e4d2a7463': {'operation': 'orders', 'target': 'x0d9db9386ce62f7ee6ea6d8d', 'kind': 'adapter'}, 'x0d9db9386ce62f7ee6ea6d8d': {'operation': 'orders', 'target': 'xcb323f45ef9d0a3c78cc4e01', 'kind': 'adapter'}, 'xcb323f45ef9d0a3c78cc4e01': {'operation': 'orders', 'target': 'x70e6231c1f1dbf4f1489a611', 'kind': 'adapter'}, 'x70e6231c1f1dbf4f1489a611': {'operation': 'orders', 'target': 'x1c779b1f179c8082e6cae65c', 'kind': 'adapter'}, 'x1c779b1f179c8082e6cae65c': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x52411521cd3aa22496ac0202': {'operation': 'update_product', 'target': 'xfe18cc94e2615828fc1474bd', 'kind': 'adapter'}, 'xfe18cc94e2615828fc1474bd': {'operation': 'update_product', 'target': 'xe4c4ee6eea46552d51ec02cf', 'kind': 'adapter'}, 'xe4c4ee6eea46552d51ec02cf': {'operation': 'update_product', 'target': 'x23637a05b2cbeeb4f9e8d8da', 'kind': 'adapter'}, 'x23637a05b2cbeeb4f9e8d8da': {'operation': 'update_product', 'target': 'xb1eb9a7fbbfbb3374501d9ec', 'kind': 'adapter'}, 'xb1eb9a7fbbfbb3374501d9ec': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xf07f2edb7f5d1327552c97cb(core, operation, data, session, actor, trace):
    trace.append('xf07f2edb7f5d1327552c97cb')
    return x1622ec9fa207e8b353db3641(core, operation, data, session, actor, trace)

def x1622ec9fa207e8b353db3641(core, operation, data, session, actor, trace):
    trace.append('x1622ec9fa207e8b353db3641')
    return x304fc15ecf23f7c2ed8610b3(core, operation, data, session, actor, trace)

def x304fc15ecf23f7c2ed8610b3(core, operation, data, session, actor, trace):
    trace.append('x304fc15ecf23f7c2ed8610b3')
    return x9f8d6199bb28ad4ad897230e(core, operation, data, session, actor, trace)

def x9f8d6199bb28ad4ad897230e(core, operation, data, session, actor, trace):
    trace.append('x9f8d6199bb28ad4ad897230e')
    return core.execute(operation, data, session, actor)

def x9eb52e0421c90d7e2bb810ed(core, operation, data, session, actor, trace):
    trace.append('x9eb52e0421c90d7e2bb810ed')
    return x759e6315002ca12718b40274(core, operation, data, session, actor, trace)

def x759e6315002ca12718b40274(core, operation, data, session, actor, trace):
    trace.append('x759e6315002ca12718b40274')
    return x2ef07925a716fe179bf7a778(core, operation, data, session, actor, trace)

def x2ef07925a716fe179bf7a778(core, operation, data, session, actor, trace):
    trace.append('x2ef07925a716fe179bf7a778')
    return xee8257f3d0fa1bc416fb5677(core, operation, data, session, actor, trace)

def xee8257f3d0fa1bc416fb5677(core, operation, data, session, actor, trace):
    trace.append('xee8257f3d0fa1bc416fb5677')
    return x1318c2631cdfe8fab02d9a97(core, operation, data, session, actor, trace)

def x1318c2631cdfe8fab02d9a97(core, operation, data, session, actor, trace):
    trace.append('x1318c2631cdfe8fab02d9a97')
    return core.execute(operation, data, session, actor)

def x471afb822bf61d0c16c84e53(core, operation, data, session, actor, trace):
    trace.append('x471afb822bf61d0c16c84e53')
    return xf0e487bb04f5d35eff504ad2(core, operation, data, session, actor, trace)

def xf0e487bb04f5d35eff504ad2(core, operation, data, session, actor, trace):
    trace.append('xf0e487bb04f5d35eff504ad2')
    return xc1c57ac72ad5cec2ea9c943f(core, operation, data, session, actor, trace)

def xc1c57ac72ad5cec2ea9c943f(core, operation, data, session, actor, trace):
    trace.append('xc1c57ac72ad5cec2ea9c943f')
    return x8e91f07bd6accd8d4db937da(core, operation, data, session, actor, trace)

def x8e91f07bd6accd8d4db937da(core, operation, data, session, actor, trace):
    trace.append('x8e91f07bd6accd8d4db937da')
    return x6e353f0f741a6ea7e5699895(core, operation, data, session, actor, trace)

def x6e353f0f741a6ea7e5699895(core, operation, data, session, actor, trace):
    trace.append('x6e353f0f741a6ea7e5699895')
    return core.execute(operation, data, session, actor)

def x86ce620aba314d29939945e0(core, operation, data, session, actor, trace):
    trace.append('x86ce620aba314d29939945e0')
    return x811409ddcd975705cb2bc50b(core, operation, data, session, actor, trace)

def x811409ddcd975705cb2bc50b(core, operation, data, session, actor, trace):
    trace.append('x811409ddcd975705cb2bc50b')
    return xcdc4a4498168238b9ad89d73(core, operation, data, session, actor, trace)

def xcdc4a4498168238b9ad89d73(core, operation, data, session, actor, trace):
    trace.append('xcdc4a4498168238b9ad89d73')
    return x0efc50b16d1318722555a501(core, operation, data, session, actor, trace)

def x0efc50b16d1318722555a501(core, operation, data, session, actor, trace):
    trace.append('x0efc50b16d1318722555a501')
    return core.execute(operation, data, session, actor)

def x3e424a702ce69c7b45dafe85(core, operation, data, session, actor, trace):
    trace.append('x3e424a702ce69c7b45dafe85')
    return x450b5fee30adac96a5072094(core, operation, data, session, actor, trace)

def x450b5fee30adac96a5072094(core, operation, data, session, actor, trace):
    trace.append('x450b5fee30adac96a5072094')
    return x6906cdd843eb82438ab09774(core, operation, data, session, actor, trace)

def x6906cdd843eb82438ab09774(core, operation, data, session, actor, trace):
    trace.append('x6906cdd843eb82438ab09774')
    return x3287e637c5c092952734bdb2(core, operation, data, session, actor, trace)

def x3287e637c5c092952734bdb2(core, operation, data, session, actor, trace):
    trace.append('x3287e637c5c092952734bdb2')
    return x3e3f1ebbf2ba027f98552838(core, operation, data, session, actor, trace)

def x3e3f1ebbf2ba027f98552838(core, operation, data, session, actor, trace):
    trace.append('x3e3f1ebbf2ba027f98552838')
    return core.execute(operation, data, session, actor)

def x819d6ac7bd5ab05e4d2a7463(core, operation, data, session, actor, trace):
    trace.append('x819d6ac7bd5ab05e4d2a7463')
    return x0d9db9386ce62f7ee6ea6d8d(core, operation, data, session, actor, trace)

def x0d9db9386ce62f7ee6ea6d8d(core, operation, data, session, actor, trace):
    trace.append('x0d9db9386ce62f7ee6ea6d8d')
    return xcb323f45ef9d0a3c78cc4e01(core, operation, data, session, actor, trace)

def xcb323f45ef9d0a3c78cc4e01(core, operation, data, session, actor, trace):
    trace.append('xcb323f45ef9d0a3c78cc4e01')
    return x70e6231c1f1dbf4f1489a611(core, operation, data, session, actor, trace)

def x70e6231c1f1dbf4f1489a611(core, operation, data, session, actor, trace):
    trace.append('x70e6231c1f1dbf4f1489a611')
    return x1c779b1f179c8082e6cae65c(core, operation, data, session, actor, trace)

def x1c779b1f179c8082e6cae65c(core, operation, data, session, actor, trace):
    trace.append('x1c779b1f179c8082e6cae65c')
    return core.execute(operation, data, session, actor)

def x52411521cd3aa22496ac0202(core, operation, data, session, actor, trace):
    trace.append('x52411521cd3aa22496ac0202')
    return xfe18cc94e2615828fc1474bd(core, operation, data, session, actor, trace)

def xfe18cc94e2615828fc1474bd(core, operation, data, session, actor, trace):
    trace.append('xfe18cc94e2615828fc1474bd')
    return xe4c4ee6eea46552d51ec02cf(core, operation, data, session, actor, trace)

def xe4c4ee6eea46552d51ec02cf(core, operation, data, session, actor, trace):
    trace.append('xe4c4ee6eea46552d51ec02cf')
    return x23637a05b2cbeeb4f9e8d8da(core, operation, data, session, actor, trace)

def x23637a05b2cbeeb4f9e8d8da(core, operation, data, session, actor, trace):
    trace.append('x23637a05b2cbeeb4f9e8d8da')
    return xb1eb9a7fbbfbb3374501d9ec(core, operation, data, session, actor, trace)

def xb1eb9a7fbbfbb3374501d9ec(core, operation, data, session, actor, trace):
    trace.append('xb1eb9a7fbbfbb3374501d9ec')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

def check_invocation(arguments):
    handler_name, core, operation, data, session, actor = arguments
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    return arguments

def delegate_invocation(arguments):
    return ORIGINAL_INVOKE(*arguments)

def run_adapter_pipeline(value, stages):
    for stage in stages:
        value = stage(value)
    return value

def invoke(handler_name, core, operation, data, session, actor):
    arguments = (handler_name, core, operation, data, session, actor)
    return run_adapter_pipeline(arguments, (check_invocation, delegate_invocation))

def encode(operation, result):
    contract = CONTRACT[operation]
    shape = contract['response_shape']
    if shape == 'array':
        return [result]
    keys = [contract['result_key']]
    if shape != 'object':
        keys.append(contract['response_box'])
    for key in keys:
        result = {key: result}
    return result

