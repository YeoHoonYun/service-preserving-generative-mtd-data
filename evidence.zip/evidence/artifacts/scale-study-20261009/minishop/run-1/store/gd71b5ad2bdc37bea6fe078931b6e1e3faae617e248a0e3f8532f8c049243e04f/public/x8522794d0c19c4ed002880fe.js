import {send} from './x6adb10d13ccfbedff1c3bacb.js';
export async function x2855059d2b3f726fe3a0362f(data,csrf){const wire={};const value=await send("/xb30f0928cdca923c72140688",wire,csrf);return value["xff5e14593b8aacc53fc053c2"];}
export async function xfe28bac8e91e66bdd7d162ee(data,csrf){const wire={};const value=await send("/x25634f4bc90dfe26fbdc4e67",wire,csrf);return value["x04b5cef9636cb415e1191884"];}
