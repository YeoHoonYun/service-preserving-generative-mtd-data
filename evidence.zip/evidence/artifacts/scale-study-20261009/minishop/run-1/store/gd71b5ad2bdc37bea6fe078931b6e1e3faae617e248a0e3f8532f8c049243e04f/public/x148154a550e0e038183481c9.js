import {xb2dfd3621e60366021a6bbaf,xd4c416fe3bfe29e2d3945190,xb56540ceffedc7c0cd837764} from './xf94ccb5753856ec73357ddb5.js';
import {x6403bbc8106c5e20efb3775b,x65421ffdf81a8ed5988b5906} from './x0f426fb881abb6fad2532b4a.js';
import {x2855059d2b3f726fe3a0362f,xfe28bac8e91e66bdd7d162ee} from './x8522794d0c19c4ed002880fe.js';

function createShop(boot) {
  const message = document.getElementById('xd51297e8b637a1279c1bf857');
  const endpoints = {
    login: xb2dfd3621e60366021a6bbaf,
    logout: x6403bbc8106c5e20efb3775b,
    catalog: x2855059d2b3f726fe3a0362f,
    create_order: xd4c416fe3bfe29e2d3945190,
    order: x65421ffdf81a8ed5988b5906,
    orders: xfe28bac8e91e66bdd7d162ee,
    update_product: xb56540ceffedc7c0cd837764
  };
  async function api(operation, data = {}) {
    return endpoints[operation](data, boot.csrf);
  }
  function identity() {
    document.getElementById('xd376b00fe0c77fe797d9a0ef').textContent = boot.user ? boot.user.id : '방문자';
  }
  async function drive(flow) {
    let step = flow.next();
    while (!step.done) {
      step = flow.next(await step.value);
    }
    return step.value;
  }
  function run(promise) {
    promise.catch(error => message.textContent = error.message);
  }
  function* catalog() {
    const list = document.getElementById('xde6d47b689f23a9e75baab63');
    list.replaceChildren();
    const products = yield api('catalog');
    for (const p of products) {
      const li = document.createElement('li');
      li.textContent = p.id + ' · ' + p.name + ' · ' + p.price + '원 · 재고 ' + p.stock;
      list.append(li);
    }
    document.body.dataset.ready = 'yes';
  }
  function* orders() {
    const list = document.getElementById('xb741207a2a985b0a8bb105ea');
    list.replaceChildren();
    const results = yield api('orders');
    for (const order of results) {
      const li = document.createElement('li');
      li.textContent = order.id + ' · ' + order.total + '원';
      list.append(li);
    }
  }
  function* submit(form) {
    const raw = Object.fromEntries(new FormData(form));
    const data = {
      username: raw['x6dd30df664f886344badf0f9'],
      password: raw['x8ff39386285b2a34274ed389'],
      product_id: raw['xa3e0e97b6e265eb744017a75'],
      quantity: raw['x0a6ed7e02932541576927414'],
      price: raw['xbfaab855576423f64d822d13'],
      stock: raw['xea28e7de9650cd2b7103e5fb']
    };
    if (form.dataset.action === 'x3a1c29dbb66f119b3f903037') {
      boot = yield api('login', data);
      identity();
      message.textContent = '로그인되었습니다.';
    }
    if (form.dataset.action === 'x6d747646ff37af502d9dfef4') {
      const order = yield api('create_order', {
        product_id: data.product_id,
        quantity: Number(data.quantity),
        request_id: crypto.randomUUID()
      });
      message.textContent = '주문 ' + order.id + ' · ' + order.total + '원';
      yield drive(catalog());
      yield drive(orders());
    }
    if (form.dataset.action === 'xa323a98da3940132b7b1a739') {
      yield api('update_product', {
        product_id: 'p1', price: Number(data.price), stock: Number(data.stock)
      });
      message.textContent = '상품을 수정했습니다.';
      yield drive(catalog());
    }
  }
  return function start() {
    document.addEventListener('submit', event => {
      event.preventDefault();
      run(drive(submit(event.target)));
    });
    document.getElementById('xfebcd0a815457bbc47eb7c40').onclick = () => run(api('logout').then(() => location.reload()));
    document.getElementById('x231877c27560a0e6fd36236a').onclick = () => run(drive(orders()));
    identity();
    run(drive(catalog()));
  };
}
createShop(JSON.parse(document.querySelector('meta[name=boot]').content))();
