import {send} from './x6adb10d13ccfbedff1c3bacb.js';
export async function x6403bbc8106c5e20efb3775b(data,csrf){const wire={};const value=await send("/x30d9d163c0da707c33603a9c",wire,csrf);return value["xe032c5178e0c53a9a2842681"];}
export async function x65421ffdf81a8ed5988b5906(data,csrf){const wire={"x1aa6ce081afee75b46f77cee":[["x95d5366213dd699560bae3b0",data["order_id"]]]};const value=await send("/x4d94c998b4a9fbb4bff57433",wire,csrf);return value["xaf5d4a966c4055622a98141f"]["x5399f9ac4e19ce52a92ab532"];}
