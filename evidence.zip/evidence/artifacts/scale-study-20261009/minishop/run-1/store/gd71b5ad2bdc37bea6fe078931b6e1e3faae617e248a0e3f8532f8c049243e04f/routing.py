GRAPH = {'xaf98c16004fbfc0df5dc5f71': {'kind': 'router', 'edges': {'/x806d81587b2083fd36d8118c': {'target': 'xbece277d4c64cbd9f656136c', 'next_key': 'x91fa419f8f418b073e7f9842'}, '/x30d9d163c0da707c33603a9c': {'target': 'xbece277d4c64cbd9f656136c', 'next_key': 'x9037922b3be1844ad51fc6ab'}, '/xb30f0928cdca923c72140688': {'target': 'xbece277d4c64cbd9f656136c', 'next_key': 'xfd3dddcf445d54428082d052'}, '/x6463ffec7b7ab759aa14ef45': {'target': 'xbece277d4c64cbd9f656136c', 'next_key': 'x3c6d10b13f2b7cca4a5a3e6e'}, '/x4d94c998b4a9fbb4bff57433': {'target': 'xbece277d4c64cbd9f656136c', 'next_key': 'x0dcba7392c0fc651ed5f6563'}, '/x25634f4bc90dfe26fbdc4e67': {'target': 'xbece277d4c64cbd9f656136c', 'next_key': 'x295f77c68f6a248215ab5560'}, '/x8e85939687aa544f055a7ebc': {'target': 'xbece277d4c64cbd9f656136c', 'next_key': 'x18cd4466668253a90d55e4eb'}}}, 'xbece277d4c64cbd9f656136c': {'kind': 'router', 'edges': {'x91fa419f8f418b073e7f9842': {'target': 'x4b649742559b45c99c978078', 'next_key': 'xdc130b4f5c37431f0cffe77b'}, 'x9037922b3be1844ad51fc6ab': {'target': 'x50b66959198ca458b653c156', 'next_key': 'x529f216a7836769780edd64b'}, 'xfd3dddcf445d54428082d052': {'target': 'x4b649742559b45c99c978078', 'next_key': 'x23d94cfaa6a92d62ad0bafcb'}, 'x3c6d10b13f2b7cca4a5a3e6e': {'target': 'x50b66959198ca458b653c156', 'next_key': 'xc7eb488ec9587d57fc5bc670'}, 'x0dcba7392c0fc651ed5f6563': {'target': 'x4b649742559b45c99c978078', 'next_key': 'x1a30dcdbd17ab4522ec10afe'}, 'x295f77c68f6a248215ab5560': {'target': 'x50b66959198ca458b653c156', 'next_key': 'x67c0130cb7348fd8b0ad21e4'}, 'x18cd4466668253a90d55e4eb': {'target': 'x4b649742559b45c99c978078', 'next_key': 'x2d4ffe74cdb3c0fb54217b16'}}}, 'x4b649742559b45c99c978078': {'kind': 'router', 'edges': {'xdc130b4f5c37431f0cffe77b': {'target': 'x9889203a970d1eff1bbd92e2', 'next_key': 'xbf11ee682fa04278e3b8229a'}, 'x23d94cfaa6a92d62ad0bafcb': {'target': 'x9889203a970d1eff1bbd92e2', 'next_key': 'xfc4906ac7e77bc99868e4357'}, 'x1a30dcdbd17ab4522ec10afe': {'target': 'x9889203a970d1eff1bbd92e2', 'next_key': 'x847fb166267c106427f00fbb'}, 'x2d4ffe74cdb3c0fb54217b16': {'target': 'x9889203a970d1eff1bbd92e2', 'next_key': 'x7187e6af320d10a770783914'}}}, 'x50b66959198ca458b653c156': {'kind': 'router', 'edges': {'x529f216a7836769780edd64b': {'target': 'x9889203a970d1eff1bbd92e2', 'next_key': 'x12fd26e9b5133fd5ccf1054f'}, 'xc7eb488ec9587d57fc5bc670': {'target': 'x9889203a970d1eff1bbd92e2', 'next_key': 'x3b69a7868d0eaca26b720eb7'}, 'x67c0130cb7348fd8b0ad21e4': {'target': 'x9889203a970d1eff1bbd92e2', 'next_key': 'x3c3339deefe73d4dfdcb7320'}}}, 'x9889203a970d1eff1bbd92e2': {'kind': 'router', 'edges': {'xbf11ee682fa04278e3b8229a': {'target': 'x9e18ab148612c0903f6f6432', 'next_key': None}, 'x12fd26e9b5133fd5ccf1054f': {'target': 'x6910a760eff6215a60ac3c66', 'next_key': None}, 'xfc4906ac7e77bc99868e4357': {'target': 'x64912b89a9b532126835e125', 'next_key': None}, 'x3b69a7868d0eaca26b720eb7': {'target': 'xeaff9996111491efb1fca204', 'next_key': None}, 'x847fb166267c106427f00fbb': {'target': 'xe1d64fb158c9e11b9d238aee', 'next_key': None}, 'x3c3339deefe73d4dfdcb7320': {'target': 'x28baf9db95897fdddf0416a5', 'next_key': None}, 'x7187e6af320d10a770783914': {'target': 'xde748bea2f34a96555366405', 'next_key': None}}}, 'x9e18ab148612c0903f6f6432': {'kind': 'service', 'operation': 'login', 'handler': 'xf07f2edb7f5d1327552c97cb'}, 'x6910a760eff6215a60ac3c66': {'kind': 'service', 'operation': 'logout', 'handler': 'x9eb52e0421c90d7e2bb810ed'}, 'x64912b89a9b532126835e125': {'kind': 'service', 'operation': 'catalog', 'handler': 'x471afb822bf61d0c16c84e53'}, 'xeaff9996111491efb1fca204': {'kind': 'service', 'operation': 'create_order', 'handler': 'x86ce620aba314d29939945e0'}, 'xe1d64fb158c9e11b9d238aee': {'kind': 'service', 'operation': 'order', 'handler': 'x3e424a702ce69c7b45dafe85'}, 'x28baf9db95897fdddf0416a5': {'kind': 'service', 'operation': 'orders', 'handler': 'x819d6ac7bd5ab05e4d2a7463'}, 'xde748bea2f34a96555366405': {'kind': 'service', 'operation': 'update_product', 'handler': 'x52411521cd3aa22496ac0202'}}
ENTRY = 'xaf98c16004fbfc0df5dc5f71'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def rewrite_graph(graph, entry):
    families = {'login': 'identity', 'logout': 'identity', 'catalog': 'inventory', 'update_product': 'inventory', 'create_order': 'purchases', 'order': 'purchases', 'orders': 'purchases'}
    rebuilt = {'route.root': {'kind': 'router', 'edges': {}}}
    leaves = {}
    for path in graph[entry]['edges']:
        node, key = entry, path
        visited = set()
        while graph[node]['kind'] != 'service':
            if node in visited:
                raise ValueError('routing cycle')
            visited.add(node)
            edge = graph[node]['edges'][key]
            node, key = edge['target'], edge['next_key']
        service = graph[node]
        family = families.get(service['operation'], service['operation'])
        branch = 'route.domain.' + family
        if branch not in rebuilt:
            rebuilt[branch] = {'kind': 'router', 'edges': {}}
        if node not in leaves:
            slot = str(len(leaves))
            leaves[node] = slot
            leaf = 'route.service.' + slot
            gate = 'route.gate.' + slot
            rebuilt[leaf] = dict(service)
            rebuilt[gate] = {'kind': 'router', 'edges': {'deliver': {'target': leaf, 'next_key': None}}}
        slot = leaves[node]
        rebuilt[branch]['edges'][slot] = {'target': 'route.gate.' + slot, 'next_key': 'deliver'}
        rebuilt['route.root']['edges'][path] = {'target': branch, 'next_key': slot}
    return rebuilt, 'route.root'

def resolve(path):
    cursor = (ENTRY, path)
    visited, trace = set(), []
    while cursor[0] not in visited:
        node, key = cursor
        visited.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        cursor = (edge['target'], edge['next_key'])
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
