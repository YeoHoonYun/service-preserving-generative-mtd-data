import {x35257181f7548c22330c2afa,xa1d09836aa2f39256783986a,x02ca72bd2d439cc00d6c474b,x4ea42e6e8da90f6d30e3c1a3} from './xca593361cb8ac41ca7bdfab6.js';
import {x88fee5bdad78f7dead0f9450,x9f147d2738c8d72034b5c8db,xa2980887bf1c09d7ac91b8bc} from './xef239642426713db7427eb09.js';

let boot=JSON.parse(document.querySelector('meta[name=boot]').content);
const message=document.getElementById('x3a9b54e4de78e64fd6714e7b');
const endpoints={login:x35257181f7548c22330c2afa,logout:x88fee5bdad78f7dead0f9450,catalog:xa1d09836aa2f39256783986a,create_order:x9f147d2738c8d72034b5c8db,order:x02ca72bd2d439cc00d6c474b,orders:xa2980887bf1c09d7ac91b8bc,update_product:x4ea42e6e8da90f6d30e3c1a3};
async function api(operation,data={}){return endpoints[operation](data,boot.csrf);}
function identity(){document.getElementById('xfe20acbe9870b17c49226b3d').textContent=boot.user?boot.user.id:'방문자';}
function run(promise){promise.catch(error=>message.textContent=error.message);}

async function catalog(){
 const list=document.getElementById('x72a4940148664c2f83543897');
 list.replaceChildren();
 for(const p of await api('catalog')){
  const li=document.createElement('li');
  li.textContent=p.id+' · '+p.name+' · '+p.price+'원 · 재고 '+p.stock;
  list.append(li);
 }
 document.body.dataset.ready='yes';
}
async function orders(){
 const list=document.getElementById('x88466ce5569e678ed4868163');
 list.replaceChildren();
 for(const order of await api('orders')){
  const li=document.createElement('li');
  li.textContent=order.id+' · '+order.total+'원';
  list.append(li);
 }
}

const actions=new EventTarget();
function subscribe(action,task){
 actions.addEventListener(action,event=>{run(task(event.detail));});
}
function publish(action,data){actions.dispatchEvent(new CustomEvent(action,{detail:data}));}
subscribe('form:x531cc0e0e813bdac541d14af',async data=>{
 boot=await api('login',data);
 identity();
 message.textContent='로그인되었습니다.';
});
subscribe('form:x17c723bac5f6c96df24a3e6f',async data=>{
 const order=await api('create_order',{product_id:data.product_id,quantity:Number(data.quantity),request_id:crypto.randomUUID()});
 message.textContent='주문 '+order.id+' · '+order.total+'원';
 await catalog();
 await orders();
});
subscribe('form:xa23e0c2ae28fd01176451fee',async data=>{
 await api('update_product',{product_id:'p1',price:Number(data.price),stock:Number(data.stock)});
 message.textContent='상품을 수정했습니다.';
 await catalog();
});
subscribe('logout',async()=>{await api('logout');location.reload();});
subscribe('orders',orders);

async function submit(form){
 const raw=Object.fromEntries(new FormData(form));
 const data={username:raw['x4665c5c9c08dc99b32024747'],password:raw['x86f118379b805804ac2efc39'],product_id:raw['x69696caab19c3d474e6998f7'],quantity:raw['xfe89c6e720c0f0a5e1b65898'],price:raw['xfd3ece01cd306a8c83ee4eae'],stock:raw['xe689400aa005130add2147f2']};
 publish('form:'+form.dataset.action,data);
}
document.addEventListener('submit',event=>{event.preventDefault();run(submit(event.target));});
document.getElementById('xbd22d1cb81ce34c8c40b90f6').onclick=()=>{publish('logout');};
document.getElementById('x74aa5cb318a7720d028fc80c').onclick=()=>{publish('orders');};
identity();run(catalog());
