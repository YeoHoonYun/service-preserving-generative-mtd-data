# Generated adapters; business and security core remains shared.
CONTRACT = {'login': {'route': '/x025763823af6204019f73346', 'fields': ['password', 'username'], 'aliases': {'password': 'x471ec50cf3a9bd9244718e6c', 'username': 'x3485bffe489c970991204eef'}, 'request_shape': 'flat', 'response_shape': 'object', 'request_box': 'x7c8cc7c69993ce93af28c40a', 'response_box': 'x5b17adfadd9740f15da2b6dd', 'result_key': 'x4cb97b9828458e324abafd87'}, 'logout': {'route': '/x0b7adbd92bff85dc8d030ddd', 'fields': [], 'aliases': {}, 'request_shape': 'wrapped', 'response_shape': 'array', 'request_box': 'x58a4ddf360f0d448d24691e6', 'response_box': 'x4fe4be9e660a376b00eca1e1', 'result_key': 'x29c206ad42e58ba72b56161d'}, 'catalog': {'route': '/xd11a93d25f2e14dfed5d3370', 'fields': [], 'aliases': {}, 'request_shape': 'pairs', 'response_shape': 'object', 'request_box': 'xc91c23a66c307ec11a562b0c', 'response_box': 'x755bb73f6987affd64ed9ecc', 'result_key': 'x1dccdebc17b7c63c72fe891c'}, 'create_order': {'route': '/xadf17917ddbd22df7a33fd71', 'fields': ['quantity', 'product_id', 'request_id'], 'aliases': {'quantity': 'x49ac5ad2ab4c748c29e5485d', 'product_id': 'xbac6df68bf5deaeb0f405bb8', 'request_id': 'x7c23b853ad2d69c877ead819'}, 'request_shape': 'wrapped', 'response_shape': 'wrapped', 'request_box': 'x2e51960e8732fb9c4cb4f6fe', 'response_box': 'x2224f8e56ff4f73fd1a5ef81', 'result_key': 'x3a24515f7a8af089780733dc'}, 'order': {'route': '/x197c690e377a78558f3ac63f', 'fields': ['order_id'], 'aliases': {'order_id': 'x9f1454650b1fb1680e073c91'}, 'request_shape': 'flat', 'response_shape': 'array', 'request_box': 'x834f2353b5b15081e5b59020', 'response_box': 'x12563961036b46a7286d1363', 'result_key': 'xba5ab6f1b4a4cdb8c06d2ece'}, 'orders': {'route': '/x0c0d84896e68d52fb4664dbd', 'fields': [], 'aliases': {}, 'request_shape': 'positional', 'response_shape': 'wrapped', 'request_box': 'x6cb55ca2ad9eab7f05fa0fa2', 'response_box': 'xa654b992b721f73fcbf3e908', 'result_key': 'x9048290d73c14fd965432df4'}, 'update_product': {'route': '/x874bbbc5d0d2199504c1bde7', 'fields': ['price', 'stock', 'product_id'], 'aliases': {'price': 'xe43329712e99eede927c536b', 'stock': 'x0c5d2219907baa959b44d509', 'product_id': 'x4f7017afc698f14039121f00'}, 'request_shape': 'flat', 'response_shape': 'wrapped', 'request_box': 'xc1243d9000cc1277a9a4fdd5', 'response_box': 'x9f872eaca6252c0bdd9125eb', 'result_key': 'x1960f36c1e5feaec88c4695c'}}
HANDLERS = {'login': 'xf94c1f5737ff41ec222b2751', 'logout': 'x60cbc0c23d0b67a6256dd597', 'catalog': 'xd934b1caa809041263902698', 'create_order': 'x8d511066d78e4f9903af4ded', 'order': 'x7b22300ff2160689ded134a6', 'orders': 'x5cf0d66e69d59cbef72e65fd', 'update_product': 'x3813cf9ef0a1d19511bdb2f6'}
BACKEND_GRAPH = {'xf94c1f5737ff41ec222b2751': {'operation': 'login', 'target': 'x41671dbb02c9963e96723c84', 'kind': 'adapter'}, 'x41671dbb02c9963e96723c84': {'operation': 'login', 'target': 'xe9d5bfb5069035cdaa6f9a98', 'kind': 'adapter'}, 'xe9d5bfb5069035cdaa6f9a98': {'operation': 'login', 'target': 'core.execute', 'kind': 'service'}, 'x60cbc0c23d0b67a6256dd597': {'operation': 'logout', 'target': 'xa6dbf6f3d3c549482b52302e', 'kind': 'adapter'}, 'xa6dbf6f3d3c549482b52302e': {'operation': 'logout', 'target': 'xc3cd4fc0e73c187812814fa0', 'kind': 'adapter'}, 'xc3cd4fc0e73c187812814fa0': {'operation': 'logout', 'target': 'core.execute', 'kind': 'service'}, 'xd934b1caa809041263902698': {'operation': 'catalog', 'target': 'xd07a5cc52f42858701ed81e1', 'kind': 'adapter'}, 'xd07a5cc52f42858701ed81e1': {'operation': 'catalog', 'target': 'x7c4f4e65ca97f148512b8ec2', 'kind': 'adapter'}, 'x7c4f4e65ca97f148512b8ec2': {'operation': 'catalog', 'target': 'xb73361880e267131f6942dad', 'kind': 'adapter'}, 'xb73361880e267131f6942dad': {'operation': 'catalog', 'target': 'core.execute', 'kind': 'service'}, 'x8d511066d78e4f9903af4ded': {'operation': 'create_order', 'target': 'x79c8d89abdf2ac16f6f416b8', 'kind': 'adapter'}, 'x79c8d89abdf2ac16f6f416b8': {'operation': 'create_order', 'target': 'x629d64b2caae977842aba0e2', 'kind': 'adapter'}, 'x629d64b2caae977842aba0e2': {'operation': 'create_order', 'target': 'x9608b6ce750bd9f51a6c251f', 'kind': 'adapter'}, 'x9608b6ce750bd9f51a6c251f': {'operation': 'create_order', 'target': 'core.execute', 'kind': 'service'}, 'x7b22300ff2160689ded134a6': {'operation': 'order', 'target': 'x6402231510c6cb3570a72da7', 'kind': 'adapter'}, 'x6402231510c6cb3570a72da7': {'operation': 'order', 'target': 'xc5fa7e082d23a8374cac97d3', 'kind': 'adapter'}, 'xc5fa7e082d23a8374cac97d3': {'operation': 'order', 'target': 'core.execute', 'kind': 'service'}, 'x5cf0d66e69d59cbef72e65fd': {'operation': 'orders', 'target': 'xce5ffb4a5eec097ced96ddae', 'kind': 'adapter'}, 'xce5ffb4a5eec097ced96ddae': {'operation': 'orders', 'target': 'x558824c157b539d26d72d51e', 'kind': 'adapter'}, 'x558824c157b539d26d72d51e': {'operation': 'orders', 'target': 'core.execute', 'kind': 'service'}, 'x3813cf9ef0a1d19511bdb2f6': {'operation': 'update_product', 'target': 'x9a2d5541b223a186bffe98b2', 'kind': 'adapter'}, 'x9a2d5541b223a186bffe98b2': {'operation': 'update_product', 'target': 'xca2bb2184d604c141b0a6851', 'kind': 'adapter'}, 'xca2bb2184d604c141b0a6851': {'operation': 'update_product', 'target': 'core.execute', 'kind': 'service'}}

def decode(operation, wire):
    c = CONTRACT[operation]
    shape = c['request_shape']
    if shape in ('wrapped', 'pairs'):
        if type(wire) is not dict or set(wire) != {c['request_box']}:
            raise ValueError('box')
        wire = wire[c['request_box']]
    if shape == 'positional':
        if type(wire) is not list or len(wire) != len(c['fields']):
            raise ValueError('arity')
        return dict(zip(c['fields'], wire))
    if shape == 'pairs':
        if type(wire) is not list:
            raise ValueError('pairs')
        values = {}
        for pair in wire:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) is not str or pair[0] in values:
                raise ValueError('pair')
            values[pair[0]] = pair[1]
        wire = values
    if type(wire) is not dict or set(wire) != set(c['aliases'].values()):
        raise ValueError('fields')
    return {f: wire[c['aliases'][f]] for f in c['fields']}

def encode(operation, result):
    c = CONTRACT[operation]
    if c['response_shape'] == 'object':
        return {c['result_key']: result}
    if c['response_shape'] == 'array':
        return [result]
    return {c['response_box']: {c['result_key']: result}}

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    trace = []
    status, result, cookie = globals()[handler_name](core, operation, data, session, actor, trace)
    return status, result, cookie, trace
def xf94c1f5737ff41ec222b2751(core, operation, data, session, actor, trace):
    trace.append('xf94c1f5737ff41ec222b2751')
    return x41671dbb02c9963e96723c84(core, operation, data, session, actor, trace)

def x41671dbb02c9963e96723c84(core, operation, data, session, actor, trace):
    trace.append('x41671dbb02c9963e96723c84')
    return xe9d5bfb5069035cdaa6f9a98(core, operation, data, session, actor, trace)

def xe9d5bfb5069035cdaa6f9a98(core, operation, data, session, actor, trace):
    trace.append('xe9d5bfb5069035cdaa6f9a98')
    return core.execute(operation, data, session, actor)

def x60cbc0c23d0b67a6256dd597(core, operation, data, session, actor, trace):
    trace.append('x60cbc0c23d0b67a6256dd597')
    return xa6dbf6f3d3c549482b52302e(core, operation, data, session, actor, trace)

def xa6dbf6f3d3c549482b52302e(core, operation, data, session, actor, trace):
    trace.append('xa6dbf6f3d3c549482b52302e')
    return xc3cd4fc0e73c187812814fa0(core, operation, data, session, actor, trace)

def xc3cd4fc0e73c187812814fa0(core, operation, data, session, actor, trace):
    trace.append('xc3cd4fc0e73c187812814fa0')
    return core.execute(operation, data, session, actor)

def xd934b1caa809041263902698(core, operation, data, session, actor, trace):
    trace.append('xd934b1caa809041263902698')
    return xd07a5cc52f42858701ed81e1(core, operation, data, session, actor, trace)

def xd07a5cc52f42858701ed81e1(core, operation, data, session, actor, trace):
    trace.append('xd07a5cc52f42858701ed81e1')
    return x7c4f4e65ca97f148512b8ec2(core, operation, data, session, actor, trace)

def x7c4f4e65ca97f148512b8ec2(core, operation, data, session, actor, trace):
    trace.append('x7c4f4e65ca97f148512b8ec2')
    return xb73361880e267131f6942dad(core, operation, data, session, actor, trace)

def xb73361880e267131f6942dad(core, operation, data, session, actor, trace):
    trace.append('xb73361880e267131f6942dad')
    return core.execute(operation, data, session, actor)

def x8d511066d78e4f9903af4ded(core, operation, data, session, actor, trace):
    trace.append('x8d511066d78e4f9903af4ded')
    return x79c8d89abdf2ac16f6f416b8(core, operation, data, session, actor, trace)

def x79c8d89abdf2ac16f6f416b8(core, operation, data, session, actor, trace):
    trace.append('x79c8d89abdf2ac16f6f416b8')
    return x629d64b2caae977842aba0e2(core, operation, data, session, actor, trace)

def x629d64b2caae977842aba0e2(core, operation, data, session, actor, trace):
    trace.append('x629d64b2caae977842aba0e2')
    return x9608b6ce750bd9f51a6c251f(core, operation, data, session, actor, trace)

def x9608b6ce750bd9f51a6c251f(core, operation, data, session, actor, trace):
    trace.append('x9608b6ce750bd9f51a6c251f')
    return core.execute(operation, data, session, actor)

def x7b22300ff2160689ded134a6(core, operation, data, session, actor, trace):
    trace.append('x7b22300ff2160689ded134a6')
    return x6402231510c6cb3570a72da7(core, operation, data, session, actor, trace)

def x6402231510c6cb3570a72da7(core, operation, data, session, actor, trace):
    trace.append('x6402231510c6cb3570a72da7')
    return xc5fa7e082d23a8374cac97d3(core, operation, data, session, actor, trace)

def xc5fa7e082d23a8374cac97d3(core, operation, data, session, actor, trace):
    trace.append('xc5fa7e082d23a8374cac97d3')
    return core.execute(operation, data, session, actor)

def x5cf0d66e69d59cbef72e65fd(core, operation, data, session, actor, trace):
    trace.append('x5cf0d66e69d59cbef72e65fd')
    return xce5ffb4a5eec097ced96ddae(core, operation, data, session, actor, trace)

def xce5ffb4a5eec097ced96ddae(core, operation, data, session, actor, trace):
    trace.append('xce5ffb4a5eec097ced96ddae')
    return x558824c157b539d26d72d51e(core, operation, data, session, actor, trace)

def x558824c157b539d26d72d51e(core, operation, data, session, actor, trace):
    trace.append('x558824c157b539d26d72d51e')
    return core.execute(operation, data, session, actor)

def x3813cf9ef0a1d19511bdb2f6(core, operation, data, session, actor, trace):
    trace.append('x3813cf9ef0a1d19511bdb2f6')
    return x9a2d5541b223a186bffe98b2(core, operation, data, session, actor, trace)

def x9a2d5541b223a186bffe98b2(core, operation, data, session, actor, trace):
    trace.append('x9a2d5541b223a186bffe98b2')
    return xca2bb2184d604c141b0a6851(core, operation, data, session, actor, trace)

def xca2bb2184d604c141b0a6851(core, operation, data, session, actor, trace):
    trace.append('xca2bb2184d604c141b0a6851')
    return core.execute(operation, data, session, actor)

ORIGINAL_INVOKE = invoke

ADAPTER_INDEX = (
    ('x3813cf9ef0a1d19511bdb2f6', x3813cf9ef0a1d19511bdb2f6),
    ('x5cf0d66e69d59cbef72e65fd', x5cf0d66e69d59cbef72e65fd),
    ('x60cbc0c23d0b67a6256dd597', x60cbc0c23d0b67a6256dd597),
    ('x7b22300ff2160689ded134a6', x7b22300ff2160689ded134a6),
    ('x8d511066d78e4f9903af4ded', x8d511066d78e4f9903af4ded),
    ('xd934b1caa809041263902698', xd934b1caa809041263902698),
    ('xf94c1f5737ff41ec222b2751', xf94c1f5737ff41ec222b2751)
)

def adapter_lookup(handler_name):
    if not isinstance(handler_name, str):
        raise KeyError(handler_name)
    lower, upper = 0, len(ADAPTER_INDEX)
    while lower < upper:
        middle = (lower + upper) // 2
        name, function = ADAPTER_INDEX[middle]
        if name == handler_name:
            return function
        if name < handler_name:
            lower = middle + 1
        else:
            upper = middle
    raise KeyError(handler_name)

def adapter_execute(function, arguments):
    trace = []
    status, result, cookie = function(*arguments, trace)
    return status, result, cookie, trace

def invoke(handler_name, core, operation, data, session, actor):
    if HANDLERS.get(operation) != handler_name:
        raise ValueError('handler')
    function = adapter_lookup(handler_name)
    return adapter_execute(function, (core, operation, data, session, actor))

