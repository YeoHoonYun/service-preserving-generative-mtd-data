GRAPH = {'xef9ec0bb136a5e1df5a2d494': {'kind': 'router', 'edges': {'/x025763823af6204019f73346': {'target': 'xc4d72343263c526006040aa4', 'next_key': 'x100b09cbfd66b2d22d61477d'}, '/x0b7adbd92bff85dc8d030ddd': {'target': 'x56c3bf999ccd6ba25d15b540', 'next_key': 'x9cad26401af1ab5ab2d659e1'}, '/xd11a93d25f2e14dfed5d3370': {'target': 'xc4d72343263c526006040aa4', 'next_key': 'xe7bab4ba917ef909303f42ab'}, '/xadf17917ddbd22df7a33fd71': {'target': 'x56c3bf999ccd6ba25d15b540', 'next_key': 'x51e8752ba5960f6c4c076d45'}, '/x197c690e377a78558f3ac63f': {'target': 'xc4d72343263c526006040aa4', 'next_key': 'xf9113dd5d752b62d90fb3e46'}, '/x0c0d84896e68d52fb4664dbd': {'target': 'x56c3bf999ccd6ba25d15b540', 'next_key': 'x66df88c7abd47c47251e58fc'}, '/x874bbbc5d0d2199504c1bde7': {'target': 'xc4d72343263c526006040aa4', 'next_key': 'xa3ca144ab2dc19fbfb43e108'}}}, 'x56c3bf999ccd6ba25d15b540': {'kind': 'router', 'edges': {'x9cad26401af1ab5ab2d659e1': {'target': 'xa92c8066eb732e5133063559', 'next_key': 'xaa1ef2edc5d23583f1b0d250'}, 'x51e8752ba5960f6c4c076d45': {'target': 'xa92c8066eb732e5133063559', 'next_key': 'x72ecf118680278e03a6703f0'}, 'x66df88c7abd47c47251e58fc': {'target': 'xa92c8066eb732e5133063559', 'next_key': 'x400526a53f0aedc12b2aac56'}}}, 'xc4d72343263c526006040aa4': {'kind': 'router', 'edges': {'x100b09cbfd66b2d22d61477d': {'target': 'xa92c8066eb732e5133063559', 'next_key': 'x6bd6c1e14143586cb4c4c1f8'}, 'xe7bab4ba917ef909303f42ab': {'target': 'xa92c8066eb732e5133063559', 'next_key': 'x69b3135bc5bfa38d4f875be9'}, 'xf9113dd5d752b62d90fb3e46': {'target': 'xa92c8066eb732e5133063559', 'next_key': 'x38f54c8491f880d7e61ff661'}, 'xa3ca144ab2dc19fbfb43e108': {'target': 'xa92c8066eb732e5133063559', 'next_key': 'x40039f3bf7e58440f70674b7'}}}, 'xa92c8066eb732e5133063559': {'kind': 'router', 'edges': {'x6bd6c1e14143586cb4c4c1f8': {'target': 'x71d144cef0d3d21cd2ee3227', 'next_key': None}, 'xaa1ef2edc5d23583f1b0d250': {'target': 'x2884fcb5a0be72554ce0078b', 'next_key': None}, 'x69b3135bc5bfa38d4f875be9': {'target': 'x003f4a23e68d84dfeaef265a', 'next_key': None}, 'x72ecf118680278e03a6703f0': {'target': 'x8b87c26e78652580b21315f3', 'next_key': None}, 'x38f54c8491f880d7e61ff661': {'target': 'x2beb83068c3bf4aca6f168ac', 'next_key': None}, 'x400526a53f0aedc12b2aac56': {'target': 'xed972b9b8fe2edaa0d4445f3', 'next_key': None}, 'x40039f3bf7e58440f70674b7': {'target': 'xaa152daf7d3c8e1f6de04def', 'next_key': None}}}, 'x71d144cef0d3d21cd2ee3227': {'kind': 'service', 'operation': 'login', 'handler': 'xf94c1f5737ff41ec222b2751'}, 'x2884fcb5a0be72554ce0078b': {'kind': 'service', 'operation': 'logout', 'handler': 'x60cbc0c23d0b67a6256dd597'}, 'x003f4a23e68d84dfeaef265a': {'kind': 'service', 'operation': 'catalog', 'handler': 'xd934b1caa809041263902698'}, 'x8b87c26e78652580b21315f3': {'kind': 'service', 'operation': 'create_order', 'handler': 'x8d511066d78e4f9903af4ded'}, 'x2beb83068c3bf4aca6f168ac': {'kind': 'service', 'operation': 'order', 'handler': 'x7b22300ff2160689ded134a6'}, 'xed972b9b8fe2edaa0d4445f3': {'kind': 'service', 'operation': 'orders', 'handler': 'x5cf0d66e69d59cbef72e65fd'}, 'xaa152daf7d3c8e1f6de04def': {'kind': 'service', 'operation': 'update_product', 'handler': 'x3813cf9ef0a1d19511bdb2f6'}}
ENTRY = 'xef9ec0bb136a5e1df5a2d494'

def resolve(path):
    node, key, trace = ENTRY, path, []
    while True:
        if node in trace:
            raise ValueError('routing cycle')
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']

def routing_branch(result, records, width):
    name = 'router:' + str(len(result))
    edges = {}
    result[name] = {'kind': 'router', 'edges': edges}
    if len(records) == 1:
        path, leaf, service = records[0]
        target = 'service:' + leaf
        result[target] = dict(service)
        edges[path] = {'target': target, 'next_key': None}
        return name
    groups = {}
    while len(groups) < 2:
        groups = {}
        for record in records:
            prefix = record[0][:width]
            groups.setdefault(prefix, []).append(record)
        width += 1
    for group in groups.values():
        target = routing_branch(result, group, width)
        for path, leaf, service in group:
            edges[path] = {'target': target, 'next_key': path}
    return name

def rewrite_graph(graph, entry):
    groups = {}
    for path, initial in graph[entry]['edges'].items():
        node, key = initial['target'], initial['next_key']
        seen = {entry}
        while True:
            if node in seen:
                raise ValueError('routing cycle')
            seen.add(node)
            item = graph[node]
            if item['kind'] == 'service':
                groups.setdefault(path[:3], []).append((path, node, item))
                break
            edge = item['edges'][key]
            node, key = edge['target'], edge['next_key']
    root = 'routing:root'
    result = {root: {'kind': 'router', 'edges': {}}}
    for group in groups.values():
        target = routing_branch(result, group, 4)
        for path, leaf, service in group:
            result[root]['edges'][path] = {'target': target, 'next_key': path}
    return result, root

def resolve(path):
    node, key = ENTRY, path
    seen, trace = set(), []
    while node not in seen:
        seen.add(node)
        trace.append(node)
        item = GRAPH[node]
        if item['kind'] == 'service':
            return item['operation'], item['handler'], trace
        edge = item['edges'][key]
        node, key = edge['target'], edge['next_key']
    raise ValueError('routing cycle')

GRAPH, ENTRY = rewrite_graph(GRAPH, ENTRY)
