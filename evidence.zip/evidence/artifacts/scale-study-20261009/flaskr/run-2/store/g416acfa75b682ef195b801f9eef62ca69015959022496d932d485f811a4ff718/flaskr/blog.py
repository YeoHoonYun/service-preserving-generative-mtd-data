from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def post_query(suffix, parameters):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ' + suffix, parameters)

def submitted_fields():
    if request.method != 'POST':
        return None
    title = request.form['title']
    body = request.form['body']
    if title:
        return (title, body)
    flash('Title is required.')
    return None

def commit_and_return(statement, parameters):
    db = get_db()
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))

def index():
    posts = post_query('ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)

def get_post(id, check_author=True):
    post = post_query('WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post

def create():
    fields = submitted_fields()
    if fields is None:
        return render_template('blog/create.html')
    return commit_and_return('INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', fields + (g.user['id'],))

def update(id):
    post = get_post(id)
    fields = submitted_fields()
    if fields is None:
        return render_template('blog/update.html', post=post)
    return commit_and_return('UPDATE post SET title = ?, body = ? WHERE id = ?', fields + (id,))

def delete(id):
    get_post(id)
    return commit_and_return('DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    bp.add_url_rule('/', endpoint='index', view_func=views['index'])
    for endpoint, prefix in (('create', ''), ('update', '/<int:id>')):
        bp.add_url_rule(f'{prefix}/{endpoint}', endpoint=endpoint, view_func=views[endpoint], methods=['GET', 'POST'])
    bp.add_url_rule('/<int:id>/delete', endpoint='delete', view_func=views['delete'], methods=['POST'])

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
