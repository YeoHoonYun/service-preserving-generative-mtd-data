from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def load_posts():
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ORDER BY created DESC').fetchall()


def load_post(id):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id WHERE p.id = ?', (id,)).fetchone()


def posted_fields():
    if request.method != 'POST':
        return None
    title = request.form['title']
    body = request.form['body']
    if not title:
        flash('Title is required.')
        return None
    return title, body


def commit_change(statement, parameters):
    db = get_db()
    db.execute(statement, parameters)
    db.commit()


def index():
    return render_template('blog/index.html', posts=load_posts())


def get_post(id, check_author=True):
    post = load_post(id)
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    fields = posted_fields()
    if fields is None:
        return render_template('blog/create.html')
    title, body = fields
    commit_change('INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))
    return redirect(url_for('blog.index'))


def update(id):
    post = get_post(id)
    fields = posted_fields()
    if fields is None:
        return render_template('blog/update.html', post=post)
    title, body = fields
    commit_change('UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))
    return redirect(url_for('blog.index'))


def delete(id):
    get_post(id)
    commit_change('DELETE FROM post WHERE id = ?', (id,))
    return redirect(url_for('blog.index'))

def register_routes(bp, views):
    paths = {'index': '/', 'create': '/create', 'update': '/<int:id>/update', 'delete': '/<int:id>/delete'}
    methods = {'create': ['GET', 'POST'], 'update': ['GET', 'POST'], 'delete': ['POST']}
    for endpoint, path in paths.items():
        options = {'endpoint': endpoint, 'view_func': views[endpoint]}
        if endpoint in methods:
            options['methods'] = methods[endpoint]
        bp.add_url_rule(path, **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
