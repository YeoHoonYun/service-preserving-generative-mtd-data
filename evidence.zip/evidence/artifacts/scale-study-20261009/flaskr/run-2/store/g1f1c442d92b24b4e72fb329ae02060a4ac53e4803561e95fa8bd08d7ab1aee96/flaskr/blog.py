from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def read_posts():
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ORDER BY created DESC').fetchall()

def read_post(id):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id WHERE p.id = ?', (id,)).fetchone()

def index():
    return render_template('blog/index.html', posts=read_posts())

def get_post(id, check_author=True):
    post = read_post(id)
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post

def finish_write(db):
    db.commit()
    return redirect(url_for('blog.index'))

def write_post(title, body, id, creating):
    db = get_db()
    if creating:
        db.execute('INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))
    else:
        db.execute('UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))
    return finish_write(db)

def edit_post(post, id):
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        if title:
            return write_post(title, body, id, post is None)
        flash('Title is required.')
    if post is None:
        return render_template('blog/create.html')
    return render_template('blog/update.html', post=post)

def create():
    return edit_post(None, None)

def update(id):
    return edit_post(get_post(id), id)

def delete(id):
    get_post(id)
    db = get_db()
    db.execute('DELETE FROM post WHERE id = ?', (id,))
    return finish_write(db)

def register_routes(bp, views):
    def register_editors():
        bp.add_url_rule('/create', endpoint='create', view_func=views['create'], methods=['GET', 'POST'])
        bp.add_url_rule('/<int:id>/update', endpoint='update', view_func=views['update'], methods=['GET', 'POST'])

    bp.add_url_rule('/', endpoint='index', view_func=views['index'])
    register_editors()
    bp.add_url_rule('/<int:id>/delete', endpoint='delete', view_func=views['delete'], methods=['POST'])

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
