from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def query_posts(suffix, parameters):
    return get_db().execute(
        'SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id' + suffix,
        parameters,
    )


def read_post_form():
    title = request.form['title']
    body = request.form['body']
    if not title:
        flash('Title is required.')
    return title, body


def commit_change(db, statement, parameters):
    db.execute(statement, parameters)
    db.commit()


def return_to_index():
    return redirect(url_for('blog.index'))


def index():
    posts = query_posts(' ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = query_posts(' WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    if request.method == 'POST':
        title, body = read_post_form()
        if title:
            commit_change(get_db(), 'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))
            return return_to_index()
    return render_template('blog/create.html')


def update(id):
    post = get_post(id)
    if request.method == 'POST':
        title, body = read_post_form()
        if title:
            commit_change(get_db(), 'UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))
            return return_to_index()
    return render_template('blog/update.html', post=post)


def delete(id):
    get_post(id)
    commit_change(get_db(), 'DELETE FROM post WHERE id = ?', (id,))
    return return_to_index()

def register_routes(bp, views):
    routes = (
        ('/', 'index', {}),
        ('/create', 'create', {'methods': ['GET', 'POST']}),
        ('/<int:id>/update', 'update', {'methods': ['GET', 'POST']}),
        ('/<int:id>/delete', 'delete', {'methods': ['POST']}),
    )
    for path, endpoint, options in routes:
        bp.add_url_rule(path, endpoint=endpoint, view_func=views[endpoint], **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
