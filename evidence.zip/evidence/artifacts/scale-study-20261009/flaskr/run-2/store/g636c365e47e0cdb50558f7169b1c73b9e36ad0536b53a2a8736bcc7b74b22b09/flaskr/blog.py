from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def commit_and_return(statement, parameters):
    db = get_db()
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))


def editor_response(post, id):
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        if not title:
            flash('Title is required.')
        elif post is None:
            return commit_and_return(
                'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)',
                (title, body, g.user['id']),
            )
        else:
            return commit_and_return(
                'UPDATE post SET title = ?, body = ? WHERE id = ?',
                (title, body, id),
            )
    if post is None:
        return render_template('blog/create.html')
    return render_template('blog/update.html', post=post)


def index():
    posts = get_db().execute(
        'SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ORDER BY created DESC'
    ).fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = get_db().execute(
        'SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id WHERE p.id = ?',
        (id,),
    ).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    return editor_response(None, None)


def update(id):
    post = get_post(id)
    return editor_response(post, id)


def delete(id):
    get_post(id)
    return commit_and_return('DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    rules = [
        dict(rule='/', endpoint='index'),
        dict(rule='/create', endpoint='create', methods=['GET', 'POST']),
        dict(rule='/<int:id>/update', endpoint='update', methods=['GET', 'POST']),
        dict(rule='/<int:id>/delete', endpoint='delete', methods=['POST']),
    ]
    for options in rules:
        bp.add_url_rule(view_func=views[options['endpoint']], **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
