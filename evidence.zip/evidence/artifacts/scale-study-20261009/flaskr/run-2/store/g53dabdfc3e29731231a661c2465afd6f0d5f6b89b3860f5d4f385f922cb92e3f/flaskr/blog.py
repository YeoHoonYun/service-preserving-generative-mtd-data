from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def select_posts(clause, parameters):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ' + clause, parameters)

def submitted_fields():
    if request.method != 'POST':
        return None
    fields = {'title': request.form['title'], 'body': request.form['body']}
    if fields['title']:
        return fields
    flash('Title is required.')
    return None

def commit_and_index(db):
    db.commit()
    return redirect(url_for('blog.index'))

def save_post(id, fields):
    db = get_db()
    if id is None:
        db.execute('INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (fields['title'], fields['body'], g.user['id']))
    else:
        db.execute('UPDATE post SET title = ?, body = ? WHERE id = ?', (fields['title'], fields['body'], id))
    return commit_and_index(db)

def index():
    posts = select_posts('ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)

def get_post(id, check_author=True):
    post = select_posts('WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post

def create():
    fields = submitted_fields()
    if fields is None:
        return render_template('blog/create.html')
    return save_post(None, fields)

def update(id):
    post = get_post(id)
    fields = submitted_fields()
    if fields is None:
        return render_template('blog/update.html', post=post)
    return save_post(id, fields)

def delete(id):
    get_post(id)
    db = get_db()
    db.execute('DELETE FROM post WHERE id = ?', (id,))
    return commit_and_index(db)

def register_routes(bp, views):
    paths = {'index': '/', 'create': '/create', 'update': '/<int:id>/update', 'delete': '/<int:id>/delete'}
    for endpoint, path in paths.items():
        options = {'endpoint': endpoint, 'view_func': views[endpoint]}
        if endpoint != 'index':
            options['methods'] = ['POST'] if endpoint == 'delete' else ['GET', 'POST']
        bp.add_url_rule(path, **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
