from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def _commit_write(db, statement, parameters):
    db.execute(statement, parameters)
    db.commit()


def _insert_post(title, body):
    db = get_db()
    _commit_write(db, 'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))


def _replace_post(id, title, body):
    _commit_write(get_db(), 'UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))


def _editor(template, context, writer, arguments):
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        if title:
            writer(*arguments, title, body)
            return redirect(url_for('blog.index'))
        flash('Title is required.')
    return render_template(template, **context)


def index():
    posts = get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ORDER BY created DESC').fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    return _editor('blog/create.html', {}, _insert_post, ())


def update(id):
    post = get_post(id)
    return _editor('blog/update.html', {'post': post}, _replace_post, (id,))


def delete(id):
    get_post(id)
    _commit_write(get_db(), 'DELETE FROM post WHERE id = ?', (id,))
    return redirect(url_for('blog.index'))

def register_routes(bp, views):
    paths = ('/', '/create', '/<int:id>/update', '/<int:id>/delete')
    endpoints = ('index', 'create', 'update', 'delete')
    options = ({}, {'methods': ['GET', 'POST']}, {'methods': ['GET', 'POST']}, {'methods': ['POST']})
    for path, endpoint, settings in zip(paths, endpoints, options):
        bp.add_url_rule(path, endpoint=endpoint, view_func=views[endpoint], **settings)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
