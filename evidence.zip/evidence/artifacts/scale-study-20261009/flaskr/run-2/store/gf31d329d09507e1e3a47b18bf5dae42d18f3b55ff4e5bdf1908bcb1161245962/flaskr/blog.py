from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def _post_rows(suffix, parameters):
    return get_db().execute(
        'SELECT p.id, title, body, created, author_id, username '
        'FROM post p JOIN user u ON p.author_id = u.id ' + suffix,
        parameters,
    )


def _submitted_fields():
    if request.method != 'POST':
        return None
    title = request.form['title']
    body = request.form['body']
    if not title:
        flash('Title is required.')
        return None
    return title, body


def _commit_and_redirect(db, statement, parameters):
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))


def index():
    posts = _post_rows('ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = _post_rows('WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author:
        if post['author_id'] != g.user['id']:
            abort(403)
    return post


def create():
    fields = _submitted_fields()
    if fields is None:
        return render_template('blog/create.html')
    title, body = fields
    db = get_db()
    return _commit_and_redirect(
        db,
        'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)',
        (title, body, g.user['id']),
    )


def update(id):
    post = get_post(id)
    fields = _submitted_fields()
    if fields is None:
        return render_template('blog/update.html', post=post)
    title, body = fields
    db = get_db()
    return _commit_and_redirect(
        db,
        'UPDATE post SET title = ?, body = ? WHERE id = ?',
        (title, body, id),
    )


def delete(id):
    get_post(id)
    db = get_db()
    return _commit_and_redirect(db, 'DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    routes = {
        'index': {'rule': '/'},
        'create': {'rule': '/create', 'methods': ['GET', 'POST']},
        'update': {'rule': '/<int:id>/update', 'methods': ['GET', 'POST']},
        'delete': {'rule': '/<int:id>/delete', 'methods': ['POST']},
    }
    for endpoint, options in routes.items():
        bp.add_url_rule(endpoint=endpoint, view_func=views[endpoint], **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
