from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def query_posts(clause, parameters):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ' + clause, parameters)

def submitted_fields():
    if request.method != 'POST':
        return None
    title = request.form['title']
    body = request.form['body']
    if title:
        return title, body
    flash('Title is required.')
    return None

def commit_and_redirect(db, statement, parameters):
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))

def index():
    posts = query_posts('ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)

def get_post(id, check_author=True):
    post = query_posts('WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post

def create():
    fields = submitted_fields()
    if fields is None:
        return render_template('blog/create.html')
    title, body = fields
    return commit_and_redirect(get_db(), 'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))

def update(id):
    post = get_post(id)
    fields = submitted_fields()
    if fields is None:
        return render_template('blog/update.html', post=post)
    title, body = fields
    return commit_and_redirect(get_db(), 'UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))

def delete(id):
    get_post(id)
    return commit_and_redirect(get_db(), 'DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    paths = {'index': '/', 'create': '/create', 'update': '/<int:id>/update', 'delete': '/<int:id>/delete'}
    methods = {'create': ['GET', 'POST'], 'update': ['GET', 'POST'], 'delete': ['POST']}
    for endpoint, path in paths.items():
        options = dict(endpoint=endpoint, view_func=views[endpoint])
        if endpoint in methods:
            options['methods'] = methods[endpoint]
        bp.add_url_rule(path, **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
