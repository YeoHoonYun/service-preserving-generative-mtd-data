from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def post_rows():
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ORDER BY created DESC').fetchall()

def finish_write(db, statement, parameters):
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))

def edit_response(template, post, id):
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        if title:
            db = get_db()
            if post is None:
                return finish_write(db, 'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))
            return finish_write(db, 'UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))
        flash('Title is required.')
    if post is None:
        return render_template(template)
    return render_template(template, post=post)

def index():
    return render_template('blog/index.html', posts=post_rows())

def get_post(id, check_author=True):
    post = get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post

def create():
    return edit_response('blog/create.html', None, None)

def update(id):
    post = get_post(id)
    return edit_response('blog/update.html', post, id)

def delete(id):
    get_post(id)
    return finish_write(get_db(), 'DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    bp.add_url_rule('/', endpoint='index', view_func=views['index'])
    for endpoint in ('create', 'update', 'delete'):
        path = '/create' if endpoint == 'create' else '/<int:id>/' + endpoint
        methods = ['POST'] if endpoint == 'delete' else ['GET', 'POST']
        bp.add_url_rule(path, endpoint=endpoint, view_func=views[endpoint], methods=methods)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
