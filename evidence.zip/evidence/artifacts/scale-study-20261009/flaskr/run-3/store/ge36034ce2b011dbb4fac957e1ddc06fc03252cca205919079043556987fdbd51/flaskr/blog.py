from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def load_posts():
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ORDER BY created DESC').fetchall()


def load_post(id):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id WHERE p.id = ?', (id,)).fetchone()


def read_post_form():
    title = request.form['title']
    body = request.form['body']
    if not title:
        flash('Title is required.')
        return title, body, False
    return title, body, True


def insert_post(title, body):
    db = get_db()
    db.execute('INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))
    db.commit()


def commit_change(statement, parameters):
    db = get_db()
    db.execute(statement, parameters)
    db.commit()


def return_to_index():
    return redirect(url_for('blog.index'))


def index():
    return render_template('blog/index.html', posts=load_posts())


def get_post(id, check_author=True):
    post = load_post(id)
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    if request.method == 'POST':
        title, body, valid = read_post_form()
        if valid:
            insert_post(title, body)
            return return_to_index()
    return render_template('blog/create.html')


def update(id):
    post = get_post(id)
    if request.method == 'POST':
        title, body, valid = read_post_form()
        if valid:
            commit_change('UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))
            return return_to_index()
    return render_template('blog/update.html', post=post)


def delete(id):
    get_post(id)
    commit_change('DELETE FROM post WHERE id = ?', (id,))
    return return_to_index()

def register_routes(bp, views):
    routes = (
        ('/', 'index', None),
        ('/create', 'create', ['GET', 'POST']),
        ('/<int:id>/update', 'update', ['GET', 'POST']),
        ('/<int:id>/delete', 'delete', ['POST']),
    )
    for path, endpoint, methods in routes:
        options = dict(endpoint=endpoint, view_func=views[endpoint])
        if methods is not None:
            options['methods'] = methods
        bp.add_url_rule(path, **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
