from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def _post_query(suffix, parameters):
    return get_db().execute(
        'SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ' + suffix,
        parameters,
    )


def _submitted_fields():
    if request.method != 'POST':
        return None
    title = request.form['title']
    body = request.form['body']
    if title:
        return title, body
    flash('Title is required.')
    return None


def _commit_and_redirect(statement, parameters):
    db = get_db()
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))


def _save_editor(fields, id, creating):
    title, body = fields
    if creating:
        return _commit_and_redirect(
            'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)',
            (title, body, g.user['id']),
        )
    return _commit_and_redirect(
        'UPDATE post SET title = ?, body = ? WHERE id = ?',
        (title, body, id),
    )


def index():
    posts = _post_query('ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = _post_query('WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    fields = _submitted_fields()
    if fields is not None:
        return _save_editor(fields, None, True)
    return render_template('blog/create.html')


def update(id):
    post = get_post(id)
    fields = _submitted_fields()
    if fields is not None:
        return _save_editor(fields, id, False)
    return render_template('blog/update.html', post=post)


def delete(id):
    get_post(id)
    return _commit_and_redirect('DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    names = ('index', 'create', 'update', 'delete')
    paths = ('/', '/create', '/<int:id>/update', '/<int:id>/delete')
    methods = (None, ['GET', 'POST'], ['GET', 'POST'], ['POST'])
    for name, path, allowed in zip(names, paths, methods):
        options = {'endpoint': name, 'view_func': views[name]}
        if allowed is not None:
            options['methods'] = allowed
        bp.add_url_rule(path, **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
