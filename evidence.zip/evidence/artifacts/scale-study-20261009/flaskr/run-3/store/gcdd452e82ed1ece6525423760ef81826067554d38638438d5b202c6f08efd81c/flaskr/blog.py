from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def list_posts():
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ORDER BY created DESC').fetchall()

def find_post(id):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id WHERE p.id = ?', (id,)).fetchone()

def submitted_fields():
    title = request.form['title']
    body = request.form['body']
    if not title:
        flash('Title is required.')
        return None
    return title, body

def index_redirect():
    return redirect(url_for('blog.index'))

def save_post(title, body, id, creating):
    db = get_db()
    if creating:
        db.execute('INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))
    else:
        db.execute('UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))
    db.commit()
    return index_redirect()

def remove_post(id):
    db = get_db()
    db.execute('DELETE FROM post WHERE id = ?', (id,))
    db.commit()
    return index_redirect()

def index():
    return render_template('blog/index.html', posts=list_posts())

def get_post(id, check_author=True):
    post = find_post(id)
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post

def create():
    if request.method == 'POST':
        fields = submitted_fields()
        if fields is not None:
            return save_post(fields[0], fields[1], None, True)
    return render_template('blog/create.html')

def update(id):
    post = get_post(id)
    if request.method == 'POST':
        fields = submitted_fields()
        if fields is not None:
            return save_post(fields[0], fields[1], id, False)
    return render_template('blog/update.html', post=post)

def delete(id):
    get_post(id)
    return remove_post(id)

def register_routes(bp, views):
    groups = (
        (None, (('/', 'index'),)),
        (('GET', 'POST'), (('/create', 'create'), ('/<int:id>/update', 'update'))),
        (('POST',), (('/<int:id>/delete', 'delete'),)),
    )
    for methods, routes in groups:
        for path, endpoint in routes:
            options = {'endpoint': endpoint, 'view_func': views[endpoint]}
            if methods is not None:
                options['methods'] = list(methods)
            bp.add_url_rule(path, **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
