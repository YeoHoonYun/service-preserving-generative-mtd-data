from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def _post_query(suffix, parameters):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id' + suffix, parameters)


def _write(statement, parameters):
    db = get_db()
    db.execute(statement, parameters)
    db.commit()


def _index_redirect():
    return redirect(url_for('blog.index'))


def _editor(template, save, context):
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        if title:
            save(title, body)
            return _index_redirect()
        flash('Title is required.')
    return render_template(template, **context)


def _insert_post(title, body):
    _write('INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))


def index():
    posts = _post_query(' ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = _post_query(' WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    return _editor('blog/create.html', _insert_post, {})


def update(id):
    post = get_post(id)

    def save(title, body):
        _write('UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))

    return _editor('blog/update.html', save, {'post': post})


def delete(id):
    get_post(id)
    _write('DELETE FROM post WHERE id = ?', (id,))
    return _index_redirect()

def register_routes(bp, views):
    def bind_action(endpoint, methods):
        prefix = '' if endpoint == 'create' else '/<int:id>'
        bp.add_url_rule(prefix + '/' + endpoint, endpoint=endpoint, view_func=views[endpoint], methods=methods)

    bp.add_url_rule('/', endpoint='index', view_func=views['index'])
    for endpoint in ('create', 'update', 'delete'):
        methods = ['POST'] if endpoint == 'delete' else ['GET', 'POST']
        bind_action(endpoint, methods)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
