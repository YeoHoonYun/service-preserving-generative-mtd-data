from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def all_posts():
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ORDER BY created DESC').fetchall()

def post_by_id(id):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id WHERE p.id = ?', (id,)).fetchone()

def commit_post_change(db, statement, parameters):
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))

def insert_post(title, body):
    return commit_post_change(get_db(), 'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))

def editor_response(template, context, save):
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        if title:
            return save(title, body)
        flash('Title is required.')
    return render_template(template, **context)

def index():
    return render_template('blog/index.html', posts=all_posts())

def get_post(id, check_author=True):
    post = post_by_id(id)
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post

def create():
    return editor_response('blog/create.html', {}, insert_post)

def update(id):
    post = get_post(id)
    def save(title, body):
        return commit_post_change(get_db(), 'UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))
    return editor_response('blog/update.html', {'post': post}, save)

def delete(id):
    get_post(id)
    return commit_post_change(get_db(), 'DELETE FROM post WHERE id = ?', (id,))

def register_editor_routes(bp, views):
    methods = ['GET', 'POST']
    bp.add_url_rule('/create', endpoint='create', view_func=views['create'], methods=methods)
    bp.add_url_rule('/<int:id>/update', endpoint='update', view_func=views['update'], methods=methods)

def register_routes(bp, views):
    bp.add_url_rule('/', endpoint='index', view_func=views['index'])
    register_editor_routes(bp, views)
    bp.add_url_rule('/<int:id>/delete', endpoint='delete', view_func=views['delete'], methods=['POST'])

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
