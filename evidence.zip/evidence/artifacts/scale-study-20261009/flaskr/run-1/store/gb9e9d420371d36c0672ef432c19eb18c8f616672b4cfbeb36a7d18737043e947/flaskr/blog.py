from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def select_posts(clause, parameters):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ' + clause, parameters)


def index_redirect():
    return redirect(url_for('blog.index'))


def commit_change(statement, parameters):
    db = get_db()
    db.execute(statement, parameters)
    db.commit()
    return index_redirect()


def submitted_fields():
    if request.method != 'POST':
        return None
    title = request.form['title']
    body = request.form['body']
    if not title:
        flash('Title is required.')
        return None
    return title, body


def editor_response(template, post, id):
    fields = submitted_fields()
    if fields is not None:
        title, body = fields
        if post is None:
            return commit_change('INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))
        return commit_change('UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))
    context = {} if post is None else {'post': post}
    return render_template(template, **context)


def index():
    posts = select_posts('ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = select_posts('WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    return editor_response('blog/create.html', None, None)


def update(id):
    post = get_post(id)
    return editor_response('blog/update.html', post, id)


def delete(id):
    get_post(id)
    return commit_change('DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    for endpoint, path in (('index', '/'), ('create', '/create'), ('update', '/<int:id>/update'), ('delete', '/<int:id>/delete')):
        if endpoint == 'index':
            bp.add_url_rule(path, endpoint=endpoint, view_func=views[endpoint])
        else:
            methods = ['POST'] if endpoint == 'delete' else ['GET', 'POST']
            bp.add_url_rule(path, endpoint=endpoint, view_func=views[endpoint], methods=methods)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
