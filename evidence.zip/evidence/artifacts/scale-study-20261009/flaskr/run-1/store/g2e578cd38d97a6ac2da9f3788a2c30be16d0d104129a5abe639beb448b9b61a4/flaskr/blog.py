from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def select_posts(suffix, parameters):
    return get_db().execute(
        'SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ' + suffix,
        parameters,
    )


def submitted_fields():
    if request.method != 'POST':
        return None
    title = request.form['title']
    body = request.form['body']
    if title:
        return (title, body)
    flash('Title is required.')
    return None


def write_and_return(db, statement, parameters):
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))


def index():
    posts = select_posts('ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = select_posts('WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    fields = submitted_fields()
    if fields is None:
        return render_template('blog/create.html')
    return write_and_return(
        get_db(),
        'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)',
        (fields[0], fields[1], g.user['id']),
    )


def update(id):
    post = get_post(id)
    fields = submitted_fields()
    if fields is None:
        return render_template('blog/update.html', post=post)
    return write_and_return(
        get_db(),
        'UPDATE post SET title = ?, body = ? WHERE id = ?',
        (fields[0], fields[1], id),
    )


def delete(id):
    get_post(id)
    return write_and_return(get_db(), 'DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    routes = (
        ('/', 'index', ()),
        ('/create', 'create', ('GET', 'POST')),
        ('/<int:id>/update', 'update', ('GET', 'POST')),
        ('/<int:id>/delete', 'delete', ('POST',)),
    )
    for path, endpoint, methods in routes:
        options = dict(endpoint=endpoint, view_func=views[endpoint])
        if methods:
            options['methods'] = list(methods)
        bp.add_url_rule(path, **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
