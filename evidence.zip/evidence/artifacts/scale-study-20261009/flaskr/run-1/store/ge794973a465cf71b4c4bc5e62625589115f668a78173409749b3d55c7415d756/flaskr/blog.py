from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def _select_posts(suffix, parameters):
    return get_db().execute(
        'SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id' + suffix,
        parameters,
    )


def _submitted_fields():
    if request.method != 'POST':
        return None
    title = request.form['title']
    body = request.form['body']
    if title:
        return title, body
    flash('Title is required.')
    return None


def _finish_change(db):
    db.commit()
    return redirect(url_for('blog.index'))


def _save_submission(fields, id, creating):
    title, body = fields
    db = get_db()
    if creating:
        db.execute('INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))
    else:
        db.execute('UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))
    return _finish_change(db)


def index():
    posts = _select_posts(' ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = _select_posts(' WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    fields = _submitted_fields()
    if fields is None:
        return render_template('blog/create.html')
    return _save_submission(fields, None, True)


def update(id):
    post = get_post(id)
    fields = _submitted_fields()
    if fields is None:
        return render_template('blog/update.html', post=post)
    return _save_submission(fields, id, False)


def delete(id):
    get_post(id)
    db = get_db()
    db.execute('DELETE FROM post WHERE id = ?', (id,))
    return _finish_change(db)

def register_routes(bp, views):
    paths = ('/', '/create', '/<int:id>/update', '/<int:id>/delete')
    endpoints = ('index', 'create', 'update', 'delete')
    options = ({}, {'methods': ['GET', 'POST']}, {'methods': ['GET', 'POST']}, {'methods': ['POST']})
    for path, endpoint, kwargs in zip(paths, endpoints, options):
        bp.add_url_rule(path, endpoint=endpoint, view_func=views[endpoint], **kwargs)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
