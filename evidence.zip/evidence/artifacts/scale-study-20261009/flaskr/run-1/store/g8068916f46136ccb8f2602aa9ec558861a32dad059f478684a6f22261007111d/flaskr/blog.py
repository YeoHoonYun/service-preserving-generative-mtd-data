from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def _select_posts(suffix, parameters):
    return get_db().execute(
        'SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ' + suffix,
        parameters,
    )


def _submitted_fields():
    title = request.form['title']
    body = request.form['body']
    if not title:
        flash('Title is required.')
        return None
    return title, body


def _write_and_redirect(db, statement, parameters):
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))


def _render_editor(post):
    if post is None:
        return render_template('blog/create.html')
    return render_template('blog/update.html', post=post)


def _edit_post(post, id):
    if request.method == 'POST':
        fields = _submitted_fields()
        if fields is not None:
            title, body = fields
            db = get_db()
            if post is None:
                return _write_and_redirect(
                    db,
                    'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)',
                    (title, body, g.user['id']),
                )
            return _write_and_redirect(
                db,
                'UPDATE post SET title = ?, body = ? WHERE id = ?',
                (title, body, id),
            )
    return _render_editor(post)


def index():
    posts = _select_posts('ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = _select_posts('WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    return _edit_post(None, None)


def update(id):
    post = get_post(id)
    return _edit_post(post, id)


def delete(id):
    get_post(id)
    return _write_and_redirect(get_db(), 'DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    routes = {
        'index': ('/', None),
        'create': ('/create', ['GET', 'POST']),
        'update': ('/<int:id>/update', ['GET', 'POST']),
        'delete': ('/<int:id>/delete', ['POST']),
    }
    for endpoint in routes:
        path, methods = routes[endpoint]
        options = {'endpoint': endpoint, 'view_func': views[endpoint]}
        if methods is not None:
            options['methods'] = methods
        bp.add_url_rule(path, **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
