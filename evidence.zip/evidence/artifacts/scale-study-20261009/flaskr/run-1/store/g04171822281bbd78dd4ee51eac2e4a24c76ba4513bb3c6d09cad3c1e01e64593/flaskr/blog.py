from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def list_posts():
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ORDER BY created DESC').fetchall()

def find_post(id):
    return get_db().execute('SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id WHERE p.id = ?', (id,)).fetchone()

def read_post_form():
    title = request.form['title']
    body = request.form['body']
    if not title:
        flash('Title is required.')
    return title, body

def commit_and_redirect(statement, parameters):
    db = get_db()
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))

def index():
    return render_template('blog/index.html', posts=list_posts())

def get_post(id, check_author=True):
    post = find_post(id)
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post

def create():
    if request.method == 'POST':
        title, body = read_post_form()
        if title:
            return commit_and_redirect('INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)', (title, body, g.user['id']))
    return render_template('blog/create.html')

def update(id):
    post = get_post(id)
    if request.method == 'POST':
        title, body = read_post_form()
        if title:
            return commit_and_redirect('UPDATE post SET title = ?, body = ? WHERE id = ?', (title, body, id))
    return render_template('blog/update.html', post=post)

def delete(id):
    get_post(id)
    return commit_and_redirect('DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    routes = (
        ('/', 'index', {}),
        ('/create', 'create', {'methods': ['GET', 'POST']}),
        ('/<int:id>/update', 'update', {'methods': ['GET', 'POST']}),
        ('/<int:id>/delete', 'delete', {'methods': ['POST']}),
    )
    for path, endpoint, options in routes:
        bp.add_url_rule(path, endpoint=endpoint, view_func=views[endpoint], **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
