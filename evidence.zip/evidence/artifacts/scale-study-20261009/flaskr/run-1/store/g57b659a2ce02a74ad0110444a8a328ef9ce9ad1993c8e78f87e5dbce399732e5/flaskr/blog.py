from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def query_posts(suffix, parameters):
    return get_db().execute(
        'SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ' + suffix,
        parameters,
    )


def commit_post_change(statement, parameters):
    db = get_db()
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))


def edit_post(template, post, id):
    context = {} if post is None else {'post': post}
    if request.method != 'POST':
        return render_template(template, **context)
    title = request.form['title']
    body = request.form['body']
    if not title:
        flash('Title is required.')
        return render_template(template, **context)
    if post is None:
        return commit_post_change(
            'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)',
            (title, body, g.user['id']),
        )
    return commit_post_change(
        'UPDATE post SET title = ?, body = ? WHERE id = ?',
        (title, body, id),
    )


def index():
    posts = query_posts('ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)


def get_post(id, check_author=True):
    post = query_posts('WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post


def create():
    return edit_post('blog/create.html', None, None)


def update(id):
    return edit_post('blog/update.html', get_post(id), id)


def delete(id):
    get_post(id)
    return commit_post_change('DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    groups = (
        ({}, (('/', 'index'),)),
        ({'methods': ['GET', 'POST']}, (('/create', 'create'), ('/<int:id>/update', 'update'))),
        ({'methods': ['POST']}, (('/<int:id>/delete', 'delete'),)),
    )
    for options, routes in groups:
        for path, endpoint in routes:
            bp.add_url_rule(path, endpoint=endpoint, view_func=views[endpoint], **options)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
