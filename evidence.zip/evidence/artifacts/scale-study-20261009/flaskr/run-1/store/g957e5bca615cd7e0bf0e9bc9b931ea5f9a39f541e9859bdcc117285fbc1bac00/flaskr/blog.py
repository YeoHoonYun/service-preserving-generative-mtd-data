from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import abort
from .auth import login_required
from .db import get_db
bp = Blueprint("blog", __name__)
def post_query(clause, parameters):
    return get_db().execute(
        'SELECT p.id, title, body, created, author_id, username FROM post p JOIN user u ON p.author_id = u.id ' + clause,
        parameters,
    )

def write_and_return(statement, parameters):
    db = get_db()
    db.execute(statement, parameters)
    db.commit()
    return redirect(url_for('blog.index'))

def editor_response(template, context, save):
    if request.method == 'POST':
        fields = (request.form['title'], request.form['body'])
        if fields[0]:
            return save(fields)
        flash('Title is required.')
    return render_template(template, **context)

def insert_post(fields):
    return write_and_return(
        'INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)',
        fields + (g.user['id'],),
    )

def index():
    posts = post_query('ORDER BY created DESC', ()).fetchall()
    return render_template('blog/index.html', posts=posts)

def get_post(id, check_author=True):
    post = post_query('WHERE p.id = ?', (id,)).fetchone()
    if post is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    return post

def create():
    return editor_response('blog/create.html', {}, insert_post)

def update(id):
    post = get_post(id)
    def save(fields):
        return write_and_return(
            'UPDATE post SET title = ?, body = ? WHERE id = ?',
            fields + (id,),
        )
    return editor_response('blog/update.html', {'post': post}, save)

def delete(id):
    get_post(id)
    return write_and_return('DELETE FROM post WHERE id = ?', (id,))

def register_routes(bp, views):
    bp.add_url_rule('/', endpoint='index', view_func=views['index'])
    bp.add_url_rule('/create', endpoint='create', view_func=views['create'], methods=['GET', 'POST'])
    for action in ('update', 'delete'):
        methods = ['POST'] if action == 'delete' else ['GET', 'POST']
        bp.add_url_rule('/<int:id>/' + action, endpoint=action, view_func=views[action], methods=methods)

register_routes(bp, {"index": index, "create": login_required(create), "update": login_required(update), "delete": login_required(delete)})
