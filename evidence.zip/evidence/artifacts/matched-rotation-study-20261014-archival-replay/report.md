# B0/B1/P1 matched rotation pilot — evidence and limits

Date: 14 October 2026. Target: local MiniShop only. This report separates a fresh live-server replay from an earlier AI-assisted public-API rediscovery study. No production target was contacted.

## Question and protocol

B0 was the secured original static MiniShop; B1 served an accepted generated artifact without changing it; P1 served the same predecessor artifact and then activated its accepted successor on the **same running server**, before a fresh attacker session. Three independently generated adjacent pairs (scale-study runs 1–3) were used. The business data, access policy, fixture credentials, two negative authorization probes, and independent state oracle were the same in all arms. The attacker-visible material was the homepage and browser-loadable JavaScript; B0's original page publicly exposes its static transport plan. For B1/P1, the predecessor mapping was shared, so their paired difference isolates switching that mapping to its successor more closely than a cold-start comparison.

The bounded objective was to complete one authorized order and check whether an Alice session could read Bob's order or write an administrator-only product update. The mapping model (`gpt-6-astra`, high effort) produced declarative route/payload plans, which a trusted HTTP executor used for the bounded probes. This is AI-assisted API rediscovery **with fixed security probes**, not a free-form AI intrusion agent. A denied negative probe is not an attack success. State-change checks, not response codes alone, decided the probe outcome.

The earlier [public-wire protocol and raw results](../public-wire-study-20261012/results.json) gave informed fixed and informed successor conditions the same maximum of two attempts, two model calls, and 60,000 provider-reported tokens per phase. Its phases used fresh hosts. This report's [new replay protocol](protocol.json) tests actual live activation, but reuses those already produced AI mappings; the new replay has no model inference. The B0 mapping came from a separately completed model call under the later common prompt.

## Results

| Arm | Authorized order | Harmful state change | Prior mapping immediately works | HTTP requests to complete the post-learning workflow | Post-learning model tokens |
| --- | ---: | ---: | ---: | ---: | ---: |
| B0, static | 3/3 | 0/3 | 3/3 | 8 per block | 0 in replay |
| B1, generated but fixed | 3/3 | 0/3 | 3/3 | 8 per block | 0 in earlier AI study |
| P1, live rotation | 3/3 after applying successor map | 0/3 | 0/3 (HTTP 404 on predecessor route) | 15 per block: 2 stale attempt + 13 adapted attempt | 40,780 across three earlier AI study phases |

All 18 tested negative-authorization probes (two per arm per block) were denied without the prohibited business-state change. For P1, each stale attempt comprised a homepage GET and one rejected POST. Each adapted attempt fetched five public JavaScript modules before the authorized workflow. These observations yield **six structure-discovery requests per P1 block** (one stale POST and five JS GETs), versus zero after learning in B0/B1. The 15-versus-8 total HTTP request difference is seven per block because the extra attempt also loaded the homepage.

In the **earlier AI study**, B1's informed fixed phase succeeded in 3/3 blocks with 0 additional model tokens, 8 HTTP requests per block, and median elapsed time 0.487 s. P1's informed successor phase succeeded in 3/3 blocks after one replan each, using 39,199 input and 1,581 output tokens (40,780 total; mean 13,593 per block), 15 HTTP requests per block, and median elapsed time 13.187 s. By run, P1 used 13,707, 13,517, and 13,556 tokens. These times and tokens were measured on **separately hosted successor targets**, so they cannot be relabeled as the live-rotation run's model cost. The live replay's HTTP-only adapted attempt took a median 0.967 s, excluding the stale attempt and all AI inference.

One later B0 mapping call under a common cross-arm prompt completed with 10,952 input and 211 output tokens (11,163 total). Its plan was reused for B0 replay in all three blocks; these are not three independent B0 model calls. The earlier public-wire study recorded 157,144 total model tokens for all its learning, cold, fixed-informed, and rotated-informed phases; this is **not** the cost of the three-arm experiment alone.

The predecessor learning shared by B1 and P1 in that earlier study cost 37,125 input and 1,441 output tokens (38,566 total) across the three blocks. It is a common setup cost, not an incremental cost of rotation.

## Interrupted prospective attempt

A new single-prompt, three-arm AI run was attempted in [the matched study harness](../../lab/intrusion_pilot/matched_rotation_study.py). The initial [first block](../matched-rotation-study-20261014-final/results.json) was interrupted by a provider HTTP 429 during P1 replanning, after a stale-route rejection. A later [paced attempt](../matched-rotation-study-20261014-confirmatory/results.json) encountered HTTP 503 followed by 429 during predecessor learning. Their failed model calls have unknown usage and are **excluded** from the outcome and token estimates above. The archived records show what ran; provider failure is not counted as defense success. No fully prospective, same-prompt, live-rotation, three-block AI comparison was completed.

## Interpretation

The paired B1/P1 structural result is reproducible: rotation invalidated an exact API mapping in 3/3 local blocks while the fixed generated mapping remained usable in 3/3. The earlier model recovered the successor mapping within one additional inference in every block, so the effect was a **finite re-discovery cost**, not durable exclusion. Normal-user task completion stayed 3/3 after adaptation. The security probes found no authorization bypass in any arm; because harmful success was 0/3 everywhere, this pilot cannot estimate a reduction in intrusion probability or a statistically meaningful security benefit. It also cannot prove general security from 18 bounded probes.

The main unresolved experiment is a fully prospective agent-driven harmful goal with an independently verified, equally reachable vulnerability in B0/B1/P1, fixed information and wall/token/request budgets, fresh contexts, an actual live rotation during each campaign, and an independent harm oracle. A lab-only seeded flaw would need to be reported separately from the accepted security-preserving artifacts. Session pinning and semantic/browser-level automation should be measured as explicit counterconditions. The Flaskr blind attack findings and Juice Shop tests are separate security evidence and must not be pooled with this MiniShop rotation result.

Evidence: [live replay rows](results.json), [per-request traces](run-1-P1.json), [stale replay trace](run-1-P1-stale.json), [archived AI study](../public-wire-study-20261012/results.json), and [replay source](../../lab/intrusion_pilot/archival_rotation_replay.py). All times are local wall-clock observations; model tokens are provider-reported input plus output counts, not currency costs.
