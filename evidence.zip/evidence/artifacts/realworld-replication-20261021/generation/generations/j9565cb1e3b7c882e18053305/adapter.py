def upstream(operation):
    if operation == 'article_list':
        return '/api/articles'
    if operation == 'tags':
        return '/api/tags'
    if operation == 'signup':
        return '/api/users'
    if operation == 'login':
        return '/api/users/login'
    if operation == 'me':
        return '/api/user'
    if operation == 'article_create':
        return '/api/articles'
    return None