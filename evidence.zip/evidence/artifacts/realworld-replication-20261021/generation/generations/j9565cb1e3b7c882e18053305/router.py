def resolve(method, path):
    if method == 'GET' and path == '/api/articles':
        return 'article_list'
    if method == 'GET' and path == '/api/tags':
        return 'tags'
    if method == 'POST' and path == '/api/users':
        return 'signup'
    if method == 'POST' and path == '/api/users/login':
        return 'login'
    if method == 'GET' and path == '/api/user':
        return 'me'
    if method == 'POST' and path == '/api/articles':
        return 'article_create'
    return None