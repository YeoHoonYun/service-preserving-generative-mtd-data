def upstream(operation):
    paths = {
        ('article_list',): '/api/articles',
        ('tags',): '/api/tags',
        ('signup',): '/api/users',
        ('login',): '/api/users/login',
        ('me',): '/api/user',
        ('article_create',): '/api/articles'
    }
    key = (operation,)
    return paths[key] if key in paths else None
