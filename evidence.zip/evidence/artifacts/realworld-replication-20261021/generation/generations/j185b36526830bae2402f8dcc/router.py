def resolve(method, path):
    if method == 'GET':
        if path == '/api/articles':
            return 'article_list'
        if path == '/api/tags':
            return 'tags'
        if path == '/api/user':
            return 'me'
    if method == 'POST':
        if path == '/api/users':
            return 'signup'
        if path == '/api/users/login':
            return 'login'
        if path == '/api/articles':
            return 'article_create'
    return None