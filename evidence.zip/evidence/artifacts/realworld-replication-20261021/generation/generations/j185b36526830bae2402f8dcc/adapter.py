def upstream(operation):
    if operation in ('article_list', 'article_create'):
        if operation == 'article_list':
            return '/api/articles'
        if operation == 'article_create':
            return '/api/articles'
    if operation == 'tags':
        return '/api/tags'
    if operation == 'signup':
        return '/api/users'
    if operation == 'login':
        return '/api/users/login'
    if operation == 'me':
        return '/api/user'
    return None