def resolve(method, path):
    routes = {
        ('GET', '/api/articles'): 'article_list',
        ('GET', '/api/tags'): 'tags',
        ('POST', '/api/users'): 'signup',
        ('POST', '/api/users/login'): 'login',
        ('GET', '/api/user'): 'me',
        ('POST', '/api/articles'): 'article_create'
    }
    key = (method, path)
    return routes[key] if key in routes else None
